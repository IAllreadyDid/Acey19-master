This package contains three files

README.TXT	2480   bytes	01/06/97	this file
WIELDY.EXE	22016  bytes	31/05/97	the executable
WIELDY.HLP	21921  bytes      01/06/97	the help file



Installation

Copy everything into your windows directory



Features

Wieldy is a wee windows programme that allows the manipulation of 
Windows applications. It is intended for those who use interpreted 
languages of other packages and want to call batch files or other external
programmes to help them achieve certain effects, like run a programme in the background
or change its title. You can also use Wieldy to change the way programmes
are run from Program Manager, for example run Calculator always on top.

You just let Wieldy execute your programme and specify how the programme is
to be run.

Example
	WIELDY  SX  WINFILE`

This example shows how to start File Manager maXimized.
To run Calculator in Restored size and change its title to Abacus, just run

	WIELDY  SR  CALC , Abacus

Note that Wieldy is case sensitive only for the new title.

Wieldy can also be used to close applications.

Note that it is not possible to start an application minimized and change the 
topmost state or the caption at the same time. If you need an application to 
be run minimized topmost you use

	WIELDY  SI  application.exe
	WIELDY  WT  application

or

	WIELDY  ST  application.exe
	WIELDY  WI  application

Example

	(STARTAPP  "WIELDY  WT MS-DOS Prompt")

The above AutoLISP command keeps the DOS shell window on top of the window list. 
Here is another example:

When in File Manager click File|Run and enter

WIELDY  WD File Manager

This destroys File Manager.

When run without a programme name, Wieldy lets you point at a window, 
assuming that you want to turn it into a topmost window.

Wieldy is by no means perfect. It is in fact very simple and has a 
restricted usefulness. It can easily be beaten by any of the common
windows batch systems.

But, it is free and very small (22016 bytes), so for some purposes it is much faster
to use Wieldy to iconize a window or to make it topmost, as in the example above,
than to load a batch system and ask it to execute a one-line batch file.

That is certainly not much. Anyway, it might help you to achieve simple window manipulation.

STATUS
 freeware

AUTHOR
 Steffen Haugk

VERSION
 Wieldy 2.1

CONTACT
 wieldy@post1.com
 www.post1.com/~wieldy