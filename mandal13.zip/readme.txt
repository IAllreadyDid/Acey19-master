        Readme for MANDALA 1.3
        ~~~~~~~~~~~~~~~~~~~~~~
Description:
~~~~~~~~~~~~
    This Screen Saver draws colored Mandalas in thousands of
    variations. You can edit seven parameters and use 100
    userdefineable presets. The speed is variable.
    Some like the meditative effect!

Installation:
~~~~~~~~~~~~~
    Run Install.exe, it determinates whitch version of Windows (95 or
    3.11) you are currently using and switches automatically to the 
    right install - procedure.
    That's all.
    No systemfiles will be changed.
    To uninstall Mandala simply delete the Mandala.* - files in the
    Windows-directory.

Mandala Screensaver (Shareware) (freely distributable)
        Ver.: 1.3
    Program by: Rainald Schwenke
    e-mail: rainjieb@sp.zrz.tu-berlin.de

The registered version:
~~~~~~~~~~~~~~~~~~~~~~~
    The registered version starts up with the Settings-Dialog-Page
    and not at the Aboutbox.
    Additionally to the 16 factory presets you can create your own
    favorite parametersettings by editing each parameter, not only
    the speed and save it to other 84 userdefineable presets.

Also available:
~~~~~~~~~~~~~~~
    32Bit-Win95/Win NT - Version: Mandala 3.0

Berlin, January 1997