     DLSuperC Program Overview for 32 bit and 16 bit Versions

  DLSuperC is an different but exceptional compare program.  It features
speed, accuracy (doesn't get lost) and versatility.  It handles file sizes
greater than 64K even in the 16 bit Window's 3.x version.  Importantly,
DLSuperC allows a user to "filter out" or ignore changes that are
temporarily considered as unimportant (e.g., programming language comments,
reformatted lines and text upper/lower case changes).  It, also, detects
lines that have moved out of sequence.
  Need a validation program that detects changes to vital programs coders
fail to flag as changed? Track changes between versions? Document changes
for change boards review? Become the backbone for a Delta change control
system?
  DLSuperC produces reports that can display the file differences in
several ways - small size (deltas, changes, control) reports or large
complete listings. The program has been specially written for execution
under Microsoft Windows and the program's capabilities are more fully
detailed in the integrated DLSuperC Help (Overview) file.
  DLSuperC is modeled after the IBM main frame "Best of Breed" program
"SuperC". It has been specifically developed to bring the original SuperC's
unique change detection technology to the Windows environment.  Variations
of the IBM's "SuperC" program exists for MVS, VM, AS/400, and PC DOS
operating systems. This author's Win3.x and Win95 versions expands the
coverage to two additional systems.  The last two versions of the compare
program are completely new code based upon the published documents for the
IBM program.
   The 16 bit version of DLSuperC is a combination of a Delphi 1.0 written
front end user interface and a Borland 4.5 C++ compare engine. Both the
16 bit and 32 bit versions of DLSuperC have been developed to produce
identical results. The 16 bit version can, also, runs in a Win 95
environment.
   There are 7 files packaged as part of the SupC16 (272KB) zip file.
1. DLSupC16.exe  (Interactive Windows Delphi 1.0 Component)
2. CppSupc.exe   (C++ Back end compare component - not directly invokable).
3. DLSuperC.hlp  (Full WinHelp component)
4. DLSupC16.ini  (Pre-initialized file - set to execute compare of 4. and 5.)
5. TestNew.txt   (A text file example with edit changes from 5)
6. TestOld.txt   (An old text file examples)
7. Readme.txt    (You'r reading it)
  Please use DLSuperC and see if you are pleased with its results and agree
that it is the best compare program you have ever used.

   This is the Shareware version of the DLSuperC compare program for then
16 bit Windows 3.1x environment.  It is not meant to be free.  It is
submitted for your use for a trial period of 30 days.  Thereafter, you
should want to become a registered user.  As a registered user you will be
mailed your personally registered version (it will say registered to:) and
the most updated version of the program. Registered users may also send in
changes that they would want to see in future releases. You should also be
notified when future updates are available.
  Updated shareware versions will also be available by downloading the
program from my Personal Web Page :

        http://members.aol.com/superc02/index.html

  Any maintenance and future delivery enhancements will also be noted.

  If you have any problems running DLSuperC (registered or not), please
feel free to send me a note or call at the number listed below.  Some
problems require failing files to be forwarded in addition to a description
of a failure. I want to recreate user problems -- so be as helpful as you
can.

  The Shareware price is $29.95 for each copy in use.  Special site
license pricing may be secured for commercial IS usage.

  Special variations of the compare program may, also, be negotiated by
contacting the author (eg., special comment filters, full directory
compares, delta generator, or direct invocation -- bypassing a menu).

  A 32 bit version (for Windows 95) is also, separately, available.

 Program Contact:
Donald M. Ludlow
7829 Harbor Dr.
Raleigh, NC 27615
superc02@mindspring.com
(919) 846-7108
http://members.aol.com/SuperC02/index.html  (For downloading and program
                                             description only)
