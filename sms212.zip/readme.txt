SMSMaster runs under Windows 3.1 or above, Windows 95 and NT4
(may work under NT3.51, but this is untested).

To install, run the setup.exe program from file manager
or explorer. This is a self extracting installer, which provides
a standard uninstall program.

SMSMaster is shareware, with a range of very reasonable registration
options. The unregistered version is fully functional, with the exception
that messages are limited in length. 

Uploaded by the author, Matthew Haigh
matt@gcrsoft.com
http://www.gcrsoft.com

The unregistered version may be freely distributed, on the
understanding that no more than a reasonable disk copying fee is
charged.


SMSMaster will allow a PC user to send text messages to a GSM 
mobile phone connected to Vodafone, Cellnet,one2one and Orange
in the UK version, or Telstra Mobilnet and Vodafone in the 
Australian version (the version is selected during installation).

In the UK version, messages may also be sent to BT, Hutchison,
Vodapage, Zap! and PageOne text message pagers using the same package.
Messages may be sent to GSM phones connected to networks in another
country, by routing via a supported network.

SMS (Short Message Service) is part of the GSM and PCN standards
which allow up to 160 characters of text to be sent or received
by a mobile terminal (cellphone). This is similar to using the 
phone as a text pager.

Some examples of when SMS may be useful :-

* when the phone is not within a service area (the network will 
  send the message when the phone comes back within the 
  service area)
* when the phone is not turned on, and voice mail is disabled 
  (SMS is always enabled, as long as it is supported by the
  network operator)
* for sending detailed information to the phone user (addresses,
  specifications etc) without the user needing to write
  them down
* to send the same message to a large group of people (eg new
  prices to sales staff, notification of a meeting date)
* to send an unobtrusive message when a phone call would not be 
  acceptable (eg to someone in a meeting).

Not all digital phones are capable of transmitting SMS messages, 
but most current digital phones can receive them (as long as the 
network operator has the facility enabled).

Whilst roaming in another country using GSM, the SMS message may 
still be delivered if the network that you are roaming on has the 
facility enabled for roaming users.

When a message is received by the phone, it will be stored in the SIM
(subscriber identity module) smart card, and will be available to be 
read whenever needed. It will be saved until you delete it, allowing 
use as a simple notepad. Most phones can be configured to beep when
a message is received, or just light up an indicator on the display
if beeping would be unacceptable.

Given that not all phones can send the messages, and that it is not 
easy to type a message into those phones that can, this technology 
can best be exploited using a computer and a modem. The computer can 
maintain a set of standard messages together with a phone book, and 
provide an easy and intuitive user interface. The messages are uploaded
via a modem to the SMSC (Short Message Service Centre) of the network 
operator of the phone you want to page. The only charge for this is 
the call to the SMSC, which is usually charged as per a call to a mobile
on that network. The person receiving the message does not have to pay
anything, unlike the standard voice mailboxes provided by the networks.

SMSMaster incorporates the following features (amongst others):-

* A phone book to keep track of often used numbers
* Support for Cellnet, Vodafone,One2One and Orange networks
* Seamless operation between networks - you don't have to know which 
  network a phone is connected to in order to send a message
* Send the same message to phones connected to different networks
* Support for group sends
* Save frequently used messages to disk
* Cut and paste messages to/from other Windows applications
* Tested under Windows 3.1, 3.11, 95, NT4
* Datestamped logfile of messages that you have sent
* Needs only a standard modem and phoneline - no need for an expensive 
  mobile phone modem
* Send messages to GSM phones connected to overseas operators for the
  cost of a UK call
* The ability to forward email to your mobile phone/pager

