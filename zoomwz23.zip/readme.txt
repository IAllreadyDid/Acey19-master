The Zoom Wizard is a sizable, movable window that displays an
enlarged view of the area around your cursor.  This tool is useful
for precise drawing, or for viewing small objects on your screen.
Zoom Wizard works with any Windows, Windows 95, or Windows NT
application.  The zoom window is continuously updated, even while
working in other applications.  The Zoom Wizard can be resized or
moved anywhere on your screen.  Zoom factors of 2 to 16 are
supported.  For your convenience, the Zoom Wizard "remembers" its
size and location when you close it.  The Zoom Wizard combines the
best features of other zoom tools in one easy-to-use package, all
for only $25!

Purpose: Provides a zoomed view of an area around the mouse
How to install: Run the zoomsw.exe program and follow instructions
Status of program: Shareware
Distribution status: freely distributable
How to contact author via e-mail: mail@reichard.com
