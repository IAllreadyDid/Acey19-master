ADing FreeRAM3x 1.0 � 1999 Alexandru Dimitriev

   1.Features
   2.Installation
   3.More information
   4.Register your copy of the ADing FreeRAM3x NOW !


1.Features:

ADing FreeRAM3x increase your system performance on-demand or automatically by:

- Increasing the amount of RAM available 
- Recovering memory leaks 
- Defragmenting your physical RAM 

 Options: 

- Recover RAM automatically when Auto Recover Level is reached and increase RAM available to Target Free RAM 
- Recover RAM automatically every MIN'S minutes 
- Display Available RAM every moment
- Run Automatically at Windows Startup 
- Always on top 
- Start Minimized 


2.Installation:

Right now it's not a classic setup routine. You must only to unzip fr3x.zip archive on your favorite directory and run freeram.exe file.

The program can be at any time safe removed from your computer if you remove:
- freeram.exe program file
- freeram.ini file from Windows directory
- program link from windows, load section on win.ini file from Windows directory

A install/uninstall program will be provided soon as posible.


3.More information:

Please first read my www pages on the Internet for latest information:

http://ading.hypermart.net
or
http://members.xoom.com/AD_ing/

If you're on the Internet, write to AD_ing@usa.net (with Subject: ADing FreeRAM3x) for technical questions, bug reports and/or registration questions and you'll receive any information you desire.


4.How to register

The registered version costs $9,95 only and it does good job for you.

You can register by:

1. Register online (press below link) at (secure server):

https//www.Qwerks.com/order/buynow.asp?ProductID=1480

*Technical note*

If you get an error page when you click links in this help file, please try copying the entire link and then pasting it into your browser's URL field. There are a variety of browser clients in use  and because each client handles links differently, broken links sometimes occur. 


2. Send me a check:

Alexandru Dimitriev
str. Sibiel nr.2 bl.63 ap.37
2400 SIBIU
ROMANIA

It is VERY important that the bank papers reflect your identity:
1.	your email address;
2.	your name and/or company name;
3.	your address

To be sure, please also send me an email informing me about your transaction at: 
AD_ing@usa.net with Subject: REGISTER FreeRAM3x

Please don't forget to add the following amount to your registration fee:

$0.00 if you register online at Qwerks
$4.00 if you send me directly a check
$4.00 if you need the software on a floppy disk by regular mail

None of these additional fees are for me - they are just to cover my bank or post office expenses. Please understand that I can't send you a registered version if you don't add these few bucks.

If you have any suggestion or you want simply to say Hello! email me at AD_ing@usa.net with Subject: SUGGESTION FreeRAM3x

Registered version (personal licence)

The registered version may be installed on as many computers as desired, as long as it is ONLY running on one at any one time (i.e. one installation at home and one at the office used by the same person). The usage by multiple people at the same time (on multiple computers) requires additional licences.

Multiple licences (additional licences)

Multiple licences allow an institution, company or school to install the program on multiple computers or on a server. It must be guaranteed that the program does not run on more machines at the same time than purchased licences number. All licences are issued to the same (company) name. For additional licences cost please contact the author.
