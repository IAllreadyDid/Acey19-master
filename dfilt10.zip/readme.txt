1)	Purpose:

This program 'Filter.exe' allows the user interactively to specify and modify the frequency response of a filter, and then calculates the required coefficients to implement that filter digitally. 
The theoretical and practical response of this digital filter is displayed to check that the filter matches the required parameters.
Any of the standard filter type (high pass, low pass, band pass, and band stop) may be created, and also a user defined filter which allows any arbitrary response to be tailored.
Additionally, an existing audio file may be filtered using the designed filter.

2)	Installation:

Install the executeable file filtersw.exe into the directory of your choice. If the file bwcc.dll is not in the 'windows' or 'windows/system' directory, it should be moved to one of these directories.

3)	Status:

The program is shareware. It is a slightly restricted version of the registered copy: the filter generation is fully functional but the audio filtration is restricted in this shareware version.

4)	Distribution:

This program is freely distributable provided this information is included with it.

5)	Contact:

The author of this program is:
	Neil Barnes
	211b High Road
	East Finchley
	London N2 8AN

	email: nailed_barnacle@hotmail.com
	homepage: http://easyweb.easynet.co.uk/~nbarnes

6)	File list:

Filtersw.exe 	- the executable file, shareware version.
Manual.doc 		- how to use the software: MS Word V6 format
Bwcc.dll 		- may be required in Windows 3.1 windows\system 
			directory if not already present.

This program makes no changes to any .ini files or to the system 
registry. It can be installed in any directory.
