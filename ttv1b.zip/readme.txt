TIFF Tag Viewer (TTV) v1.0b

16-bit Windows program
Requires VBRUN300.DLL
   (available from  ftp://ftp.mcs.net/mcsnet.users/dschi/vbrun300.dll )

!!!This Program Is Not Public Domain!!!
Copyright �1996 Don Seeley/Daring Designs. All Rights Reserved.
It is distributed as freeware. 
Unaltered copies may be distributed without restriction.


This program was developed to address a couple of specific needs: how 
to examine the descriptive header of a TIFF file that fails to load in 
a viewer, and secondly, to have the ability to capture and compare or 
examine common header information from one source.

Some color related tags have been included when they overlap (or 
differentiate a file from) binary file information. The more arcane JPEG, 
CIEL, and YCbCr tags are not included but are rarely used and so should 
not impact most uses. The entire 6.0 specification tag list is included 
for reference in the "About" menu.



BUG REPORTS:

Fault: 
Directory box palette conflicts with 
Cornerstone Image Accel ia.drv drivers.

Correction: 
None identified.

Please e-mail bug definitions to dschi@mcs.net
