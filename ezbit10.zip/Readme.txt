EZBitmap is a make-your-own screen saver program for Windows.

ezbit10.zip is a self-extracting executable, see instructions below to install the program.

EZBitmap will allow you to put up to 20 of your own bitmaps into a screen saver.  You can use family pictures, business logos, or advertisements.  It's up to you.  There are many CD-ROM's available that contain hundreds of pictures in BMP format.  You can just pop them into EZBitmap and you've got your own personal screen saver.  The interface is simple to use, allows easy editing, and contains a viewer for your convenience.

This program will work on Windows 3.1 or higher, including Windows 95. 
Windows, Windows 3.1 and Windows 95 are trademarks of the Microsoft Corporation.EZBitmap is a make-your-own screen saver program for Windows.

***********************************************************

Installation instructions for EZBitmap Screen Saver


Activation under Windows 3.1

- Install the program by running Ezbit10.exe from the drive prompt.
- Double click on Main, then double click Control Panel, 
  then double click Desktop.
- In the screen saver section of Desktop, click on the down arrow
  to the right of the edit field.  Scroll through the choices 
  until you find EZBitmap Screen Saver OR EZBitmap.  Select it.
- Click on the Settings Button.  This will open the Configuration Screen
- Follow the instructions on the screen.  All the help you need is there.
- After exiting EZBitmap configuration, click the OK button at the top of Desktop. 
  This will save and exit the Desktop screen. 


Activation under Windows 95

- Install the program by running Ezbit10.exe from the drive prompt.
- Click on the Start Button, then click on Settings, 
  Then click on Control Panel.
- Double click on Display.  Then click on the Screensaver tab 
  of the notebook.
- In the screensaver section, click on the small down arrow 
  on the right side. 
- From the list of choices, scroll through the choices 
  until you find EZBitmap Screen Saver or EZBitmap.  Select it.
- Click on the Settings Button.  This will open the Configuration Screen
- Follow the instructions on the screen.  All the help you need is there.
- After exiting the configuration program, click the OK button at the bottom. 
  This will save and exit the Display screen.

************************************************************

This program is shareware uploaded by the Author, Bruce Schwab of Dakota Raven.  

It is freely distributable in its unregistered form.  The registered program license is not transferable.  

How to contact the Author

Dakota Raven
po box  6103
Minot, ND   58702-6103
onscreen@minot.ndak.net
http://members.aol.com/dakraven1/index.htm

Thank you.
