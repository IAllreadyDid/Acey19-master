ENHANCE23 README.TXT
====================

ENHANCE23 is an add-in for Release 4 and 5 of Lotus 123W. It provides:
New @functions :
	@soundex, @typex, @near
	@near, @moveleft, @moveright, @moveup, @movedown, @addressof, @rangebelow
	@equal
New macro: {REPLACE23..}

New class of helper @ functions that return information to the user of real and potential
errors in standard Lotus 123W @ functions, in particular the @D.. database series which are
difficult to use:

@sum?, @dsum?, @dcount?, @dget, ..................

RELEASE HISTORY
================
NOV 1998 - BETA 1
Jan 1999 - Release 1.01
Feb 1999 - Release 1.02, 1.03 corrections to @soundex, @left etc changed to @moveleft
July 1999 -Release 1.04 -added @SUM?

DETAILED INSTALLATION INSTRUCTIONS
==================================

1. If from a ZIP file extract the contents to a temporary directory and read this 
readme.txt file. If from the downloaded EN23*.exe self-installing file just execute.
The file will be named according to the release spec. E.g. EN23B1.exe for 
beta 1 or EN23R100.EXE for release 100.

2. Answer the questions regarding directory and program group. It is strongly 
recommended that you accept the recommended settings as they have been determined 
using your 123*.ini file.

3. Once installed, load 123 and select "Tools" menu item then "Add-ins". This 
will bring up a dialog. Select "Load" which brings up the "Load" where you should 
see "EN23.adw" which was placed in the default addin directory by the installation program.

If the installation program could not find the correct location for the default addin 
directory, files will be placed in the directory selected by you in the "Directory" 
installation dialog.

4. On selecting "EN23.adw" the ENHANCE23 addin will load. On first installation 
two message dialogs will come up reminding you to enter your Passcode before 
using the addin. Passcode is required for trial and registered versions. Your registered
Passcode is obtained automayically on payment at the LAPSOFT web site at http://www.lapsoft.com
Your trial passcode is obtained by clicking the "Generate trial passcode" button in the
"Register" dialog (see 5 below).

5. To enter your Passcode select "ENHANCE23" from the 123 menu bar which appears after loading
the "EN24.ADW" add-in (see 3 above). Then "Register". Enter the details exactly as per 
the web supplied receipt: Name, email address and Passcode. For the trial supply your name, 
email address then click the "Generate trial passcode" button to generate a 38 day trial 
passcode. Include case and spaces otherwise your Passcode will not match. Best done by copy/
paste directly from the web response page.

6. Select "Apply", if your details were exactly as you entered them exactly as per 
the web supplied receipt, the "Register" dialog will indicate success or failure. 
If failed, try to get the case and details correct including spaces.

7. Your ENHANCE23 addin should now be installed and working. To test the various features 
and learn how ENHANCE23 can be applied to typical problems you should load the supplied 
worksheet file "EN23.WK4" located in the \program\addin\ENHANC23\ directory. 

SMARTICON FOR ENHANCE23
=======================
The ENHANCE23 installation program has included in your '\sheetico\' directory the file
EN23.bmp. So by selecting Tools=>Smarticons from the 123 menu bar you can select the EN23 
smarticon. A EN23.mac macro file has also already been supplied. You just need to add 
the smarticon button to your toolbar. Clicking the ENHANCE23 smarticon will start the add-in.
To verify that the add-in is loaded, just look for the "ENHANCE23" menu item at the end of the 
main 123 toolbar (ie after "Help").

ENHANCE23 HELP FILE 
===================

A help file EN23.hlp has been included in the default application directory (e.g. 
"..\program\addins/ENHANCE23/EN23.hpl"). This file can be initiated from the "About ENHANCE23" 
submenu item in the "Help" 123 menu. It contains detailed descriptions of each ENHACE23 @ 
functions, included files, contact details etc.

KNOWN BUGS
==========

Nil at this time.
A FAQ section on the LAPSOFT web site as well as a bug report form.

REGISTERING/PURCHASING ENHANCE23
================================

Purchasing/Registering ENHANCE23 is by web at http://www.lapsoft.com.au or contacting
sales at sales@lapsoft.com

	* full license - provides one license (one license  Lotus123 license required)
	and access to the LAPSOFT members web site http://www.lapsoft.com/member for the life 
	of the product. This includes free upgrades and specials.
	* quantity licenses- 1 ENHANCE23 license required per Lotus123 license required.

ACKNOWLEDGEMENTS
================

ENHANCE23 is a trademark of LAPSOFT sales@lapsoft.com , http://www.lapsoft.com
Lotus123 is a trademark of LOTUS DEVELOPMENT CORP. http://www.lotus.com

DISCLAIMER
==========

LAPSOFT are not connected in any way to LOTUS DEVELOPMENT CORP.	 apart from developing addin
products for Lotus 123 and others. LAPSOFT warn that ENHANCE23 may produce wrong or 
misleading results and that users should use the evaluation period to assess its suitability. 
LAPSOFT in turn will attempt to provide timely support bug fixes and workarounds via its web 
site.
