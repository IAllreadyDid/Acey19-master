
To make it easier to read this file click the EDIT menue above and 
select Word Wrap.



		   Micro Century 2000. Inc, 
		
		Y2K DOCTOR V2.05 'Diagnostic Version'

-----------------------------------------------------------------

Contents:

	Section 1, Programme Information
	   "	2, Support
	   "	3, Installation
	   "	4, Upgrade Options and Prices
	   "	5, Registering/Upgrading Online
	   "	6, Testing Hardware For Y2K Compliance
	   "	7, Y2K Hardware Solution
	   "	8, Disclaimer

-----------------------------------------------------------------------
Section,1		Programme Information
------------------------------------------------------------------
Y2K Doctor 'Diagnostic Version' is compatible with Windows 3+,95 
and 98 as well as Windows based Workstations on NT, Unix & Novell 
Networks. The  programme can be used as part of a Y2K audit and will 
automatically scan for, detect and log, but not repair Y2K related 
2-Digit year date problems in Windows 3.+, 95, 98 and most associated 
Applications Software.  You can also print out an inventory of problems
found.  

Registered versions of Y2K Doctor can automatically REPAIR Year 2000 
problems in: DOS, Windows 3.+, 95, 98 and Windows based Workstations on
NT, Unix & Novell Networks.  There are also Upgrades to atomatically 
Scan for and Repair non-compliant User entered Dates in Spreadsheet, 
Data base and Wordprocessor Date Fields and User Data Files More 
information can be found in the Programme Help File and the Y2Kdr 
Inf.PDF file copied to the C:\Temp Directory during installation. 
NB: You will need a Coral PDF Reader to access this file.
 
Please refer to SECTION 4, 'UPGRADE OPTIONS and PRICES' to see 
which Upgrade path best suits your requirements.

The Y2K Doctor V2.05 'Diagnostic Version' Software is the property of 
Micro Century 2000 Inc, Millennium Solutions are authorised Agents of 
Micro Century 2000 Inc.  Y2K Doctor V2.05 'Diagnostic' is distributed 
FREE without charge and may be freely copied and/or distributed and/or 
used to diagnose any number of computers on the same basis.  The only 
proviso is That the Software and contents of the Programme Disk or 
Downloaded File including Text Files are not altered, changed or 
modified in any way.
 

------------------------------------------------------------------
Section 2,		SUPPORT
------------------------------------------------------------------
SUPPORT for Y2K Doctor 'Diagnostic Version' is provided free on a 
discretionary basis by email at http:\\www.micro-century.com.  
Registered versions and Upgrades qualify for unlimited FREE support.

------------------------------------------------------------------
Section 3,             INSTALLATION
------------------------------------------------------------------
From Download or Floppy Disk: 

1, Double click on the Y2KdrV25.exe Icon, the files will be atomatically 
extracted to the Windows\TEMP Directory, or a directory of your choice.

2, Switch to the Directory.

3, Double click the Setup.Exe Icon and follow the onscreen instructions.

4, After installation has completed re-start your computer.

4, Run the Y2K Doctor programme and read the help file thoroughly for 
instructions on usage.

For Magazine Cover Disks: Follow the instructions given by the Magazine.

------------------------------------------------------------------
Section 4,		UPGRADE OPTIONS and PRICES
------------------------------------------------------------------
UPGRADE OPTIONS:
In order to repair the problems found by the Y2K Doctor programme 
or to scan and repair files in DOS, NT4+ or Date fields and cells 
in User Data Files created by Spreadsheet, Database or Word 
processor Applications you will need to upgrade to one of the 
following versions of Y2K Doctor.  

DOS, Windows 3.+, Windows 95 and Windows 98. 
Operating System and Applications compliance: 

Upgrade Path: Y2K Doctor Standard.

Price: 	
By Phone or Fax......... 	  �39.95incl per PC
   Online...............	  �34.95incl per PC.
   Post.(Includes Disk).	  �39.95incl Per PC + �5.00 P&P


If you need to scan and fix user data files created by Spread
sheet, Database and Word Processor Applications as well as the 
above options: 

Upgrade Path:Y2K Doctor PRO.

Price:	
By Phone or Fax......... 	  �45.95inc per PC
   Online...............	  �40.95inc per PC.
   Post. Includes Disk..	  �45.95inc Per PC + �5.00 P&P


NOVELL & UNIX 
Y2K Doctor is not fully compliant with Novell or Unix at this 
time however Y2K Doctor IS compliant with Work Stations running 
Windows 95 or 98 on a Novell or Unix Network.

For Operating Systems and Applications compliance and/or to scan 
and fix date fields in Spreadsheet, Database and Word Processor 
user data files: 

Upgrade Path:Y2K Doctor Standard or Y2K Doctor PRO (See prices 
above).


WINDOWS NT4+
To Scan and Fix Operating Systems, Applications Software and date 
fields in Spreadsheet, Database, Word Processor user data files: 

Upgrade Path: Y2K Doctor PRO Deluxe.

Price:	
By Phone or Fax......... 	  �51.95.95incl per PC
   Online...............	  �46.95incl per PC.
   Post. Includes Disk..	  �51.95incl Per PC + �5.50 P&P

-----------------------------------------------------------------------
!!! SAVE MONEY !!! Register ONLINE !!! SAVE MONEY !!! Register ONLINE !!!
-----------------------------------------------------------------------
To Order your chosen upgrade run the Y2K Doctor programme click on 
Help and select 'Purchase Options' from the drop down menu. Follow 
the instructions to fill out the form, you can then upgrade either
Online, by phone, Fax or Post.

------------------------------------------------------------------
SECTION 5,	Registering/Upgrading Online
------------------------------------------------------------------
If you have a credit card and a PC with an internet connection you
can save money by registering/upgrading a single copy or multiple 
copies of this product using our Secure Online Order Site please 
follow the insructions set out below.

The Diagnostic/Demo version of Y2K Doctor generates a unique Serial 
Number for each machine it is installed on.  To register/upgrade 
your copy you will need the Serial Number from each machine you wish to
use Y2K Doctor on (you will receive a Keycode for each Serial No 
you register this Keycode will allow installation on the PC with 
that serial Number only), To purchase 1 Keycode you need 1 Serial Number, 
to purchase 2 Keycodes you need 2 etc;.To obtain the Serial Number for 
each PC carry out the following procedure. 

1, Start the Y2K Doctor programme on each machine you wish to 
register.

2, Click on help and select 'Purchase Options' from the drop down 
menu.

3, click and check the "To Purchase Hardware and Software Fix etc" box 
   at the top of the screen, then click 'NEXT'

4, click/Check the Internet Box then click 'NEXT'

5, In the "Internet Ordering" Screen make a note of the Serial 
   Number displayed in the top dialogue box of each machine you 
   are registering. 
   
6, you are now ready to register.

7, On a PC connected to the Internet Click on the CONNECT button 
   at the bottom of the Y2K Doctor Internet Ordering page.  This 
   will connect you direct to our Secure Online Order site. Once 
   connected follow the on screen instructions.

------------------------------------------------------------------
Section 6,	TESTING HARDWARE FOR Y2K COMPLIANCE
------------------------------------------------------------------
Making your Software Year 2000 Compliant is only part of the Year 
2000 issue to be fully Year 2000 compliant you should also test 
and fix (if necessary) your PC Hardware. Y2K Doctor contains a 
comprehensive Hardware Y2K Compliance Test Utility, yr2000.exe.  
yr2000.exe can be used to Test your Hardware Real Time Clock and 
BIOS for full Y2K Compliance. 

Follow the steps to test your hardware:

1, Copy the yr2000.exe file to a formatted floppy disk.  

2, Boot your system to the DOS prompt. To do this follow steps 3 &
   4.

3, Turn the PC on and wait until the message 'Starting Windows 95 
   (or 98) appears on screen then press the F8 key (top centre on 
   your key board)

4, A list of options will appear, select Safe Mode DOS Prompt (at 
   or near the bottom of the list) and press enter.  
   The C:\ Prompt will appear.

5, Place the disk containing yr2000.exe in the floppy drive and 
   type: a:\yr2000.exe, press enter.

6, the programme window will appear.  Follow the instructions on 
   screen. 

The Centurion Test Utility tests for CMOS/Real Time Clock Compliance, 
the BIOS ability to handle the Y2K rollover under all circumstances 
and post millennium leap years recognition. 

If your hardware fails on any of the tests you are at risk and 
should consider installing a Micro 2000 Centurion RTC Card to make
your hard ware fully Year 2000 Compliant. 

     For more information see below or call 44 (0)1279 306545.
     
------------------------------------------------------------------
Section 7,		Y2K Hardware Solution
------------------------------------------------------------------
Centurion. The Y2K Hardware Solution

The Micro 2000 Centurion RTC Card is a low profile 8 bit ISA card 
that fits into an ISA, EISA, or  VLB slot on any IBM Compatible 
computer equipment.  Can also be fitted in IBM PS\2 hardware using
the optional Micro Channell adaptor. The Card with it's on-board 
double-buffered fully Y2K Compliant Dallas Real Time Clock (RTC) 
attacks the root cause of the Millennium Bug in computer hardware,
the un-compliant 2 digit year RTC.  When installed the fully 
Compliant RTC on the Centurion Card takes over from and effectivly
replaces the computers existing RTC making the hardware fully year
2000 Compliant. Centurion corrects the systems RTC and BIOS 
compliance problems supplying 4-digit year code (ccyy) enabling 
the PC to correctly roll over to the Year 2000 as well as correctly 
identify all post millennium leap years. 
 
FEATURES:
Computers with Centurion fitted will correctly roll-over into the 
new millennium whether switched off or on.  

Any programmes by-passing the BIOS and going directly to the RTC 
will get a always get a correct date and time. 

All post Millennium Leap Years will be recognised. 

Centurion will also correct other common RTC problems ie: RTC runs
fast or slow, system loses date and time when switched off etc. 

Systems fitted with Centurion will all keep the same time even if 
they are different makes and models.

Centurion can be fitted by complete novice or professional alike 
and easily installs to any spare ISA, EISA or VLB slot automatically 
assuming the system date and time. 

Its compact size means Centurion can also be used in IBM AT based 
EPOS and Industrial process hardware etc.  

With the Centurion Card fitted you can ensure a safe, trouble free 
transition into the Year 2000 without having to switch your Hard
ware Off.

SPECIFICATION:
 
Dimensions: 4.25" Long X 2.5" High.

Slot Type:   8 Bit ISA.

RTC:        DALLAS RTC with 128 bytes CMOS Ram.

Battery:    On-board Lithium Battery designed to last 10 years without
            external power (in normal use this translates to about 
            30years).

Configuration: 3 Jumpers confgure I/O Address and Memory Address.

I/O Address: Can use 140/141 or 150/151.  

Memory:      Can use Upper Memory Addresses D0000-D1FFFF OR   
             D40000-D5FFF OR D80000-D9FFF OR DC000-DDFFF.  

------------------------------------------------------------------
PRICE: 	CENTURION CARD...   	�44.95 plus vat & �5.00 P&P.(UK)
	PS\2 Adaptor...		�29.95 plus vat
------------------------------------------------------------------

If you have any problems with installation or for Further Information 
Contact Millennium Solutions On:

Tel:  01279 306545
Fax:  01279 320620
email: info@millennium-solutions.co.UK

Or Check Out Our Web Site at
http:\\www.millennium-Solutions.co.uk


---------------------------------------------------------------------
Section 8, DISCLAIMER: THIS SOFTWARE IS OFFERED AS IS, WITH 
           ABSOLUTELY NO WARRANTY OF ANY KIND OFFERED OR IMPLIED.
---------------------------------------------------------------------

All Registered Trade Marks are acknowledged as the property of 
their respective owners.


END....