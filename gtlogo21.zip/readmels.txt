GALTWARE: LOGO-SAVER v2.1
README & SOFTWARE LICENSE AGREEMENT
 - SHAREWARE EDITION
=========================

Thank you for trying out LogoSaver. We're sure you'll
find it to be a great corporate screen saver, as has
Victoria's Secret, GE, EDS, Cordis Corp., 
Guinness Distillers, and many other companies.

Registration: 
-------------
Registration fee is $19 for individual users 
or $349 for an unlimited corporate site license.
You can register online at our web site:
http://www.galttech.com
Or call us at: 800-580-0742

*******
WARNING
*******
LogoSaver screen saver has a password option. 
If you select this option, you must remember the
password that you type in. You will be prompted
to enter your password to de-activate the screen
saver and return to your normal desktop. If you
forget your password, to regain control of your
computer you will have to turn off your computer 
and re-boot it, losing all data that
was unsaved at the time. 

Installation:
---------------
To install LOGOSAVER, unzip the 
LOGOSAVE.ZIP file you downloaded.
Then run the SETUP.EXE program. 
Follow the on-screen prompts.
This will load the program onto
your system. To keep file size small
this version does not include the file
========VBRUN300.DLL,==========
but it is *required* to run the program.
This file must be in your \WINDOWS\SYSTEM directory.
You can download it from Compuserve or AOL;
it is also available at our Internet site -
http://www.galttech.com


Description:
------------
Designed as a corporate screen saver,
LogoSaver is a screen saver that will display
any bitmap (.BMP) graphic file that you choose,
bouncing it around the screen. Ideally, the logo 
file should be less than a quarter of the size
of the screen display. A great way to standardize
the company screen saver using the corporate logo.
You can also choose the background color to
properly match your logo.


HINT: If you have a logo in a format other than
.BMP, there are many conversion utilities available
that can change it into a BMP file. You can also use
Microsoft Paintbrush to create or edit a BMP file.


Configuring Screen Saver:
==========================
(Windows 3.1)
To use the screen saver, double-click 
CONTROL PANEL, usually in the MAIN group 
on your desktop. When CONTROL PANEL opens, 
double-click on DESKTOP to go into the 
desktop configuration screen. About halfway 
down the window, select the Screen Saver Name 
drop-down box. You should find LOGOSAVER in the 
list. Select it. Now click on the SETUP button. 
In the screen saver setup, you can adjust the
settings to your preferences. Click the 
Select Logo button; then you can select 
any .BMP file on your hard drive, and see it in
the Preview Window. Click 'Use Selected File as
My Logo' near the bottom to make the selected logo 
appear when you run the screen saver. Click 
'Setup Complete' when you are finished. 
That's it. Click EXIT and try the TEST
button.
(Windows 95)
Right-click the desktop to bring up the 
display panel, or click the START button and
choose Settings/Control Panel; from there you 
can choose DISPLAY. With the Display Panel open,
click on the Screen Saver Tab. Select LOGOSAVER 
from the drop down list of screen savers, and click
Settings to setup. and Preview to test it.


Removing LOGOSAVER:
To remove LOGOSAVER from your system,
delete the file LOGOSAVE.SCR, GALTLOOGO.DAT,
and GALTLOGO.INI from your \WINDOWS directory. 
Also, delete the  directory you chose to 
install to (default C:\GALTWARE -- README & 
ORDER files are stored here).


License:
-----------
BY USING THIS SOFTWARE, YOU AGREE TO THE
FOLLOWING TERMS AND CONDITIONS:

This version of LogoSaver is shareware. 
You are granted a license to use LogoSaver 
for a period of up to 30 days. After
that time, you are required to purchase the
product(s) through registration or else 
discontinue its use.

You are allowed to make copies of this 
software and distribute it to your friends 
and co-workers, on electronic bulletin
boards, over networks, and so on, as long 
as the product is not distributed for
profit (handling fees up to $5.00 ok). 
If you distribute this software, you agree 
to distribute this installation executable 
which contains the associated files together 
as a group. You are not allowed to bundle 
this software with other products without 
prior written permission from Galt Technology.

*******
WARNING
*******
LogoSaver screen saver has a password option. 
If you select this option, you must remember the
password that you type in. You will be prompted
to enter your password to de-activate the screen
saver and return to your normal desktop. If you
forget your password, to regain control of your
computer you will have to turn off your computer 
and re-boot it, losing all data that
was unsaved at the time.

Ownership of software:
As licensee, you own the media upon which 
the software is recorded or distributed and 
are entitled to use the software, but Galt 
Technology retains title and ownership of 
the original software and all subsequent copies. 
This license is not a sale of the software or 
any copy. You are not allowed to make any 
modifications to, or to create derivative 
works from any of the files that are used 
in this software. This includes all the 
executable, help, installation, and readme 
files, as well as video files.

LIMITED WARRANTY:
THE SOFTWARE HEREIN ARE 
PROVIDED "AS IS" WITHOUT 
WARRANTY OF ANY KIND, EITHER 
EXPRESSED OR IMPLIED, BUT 
NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR 
PURPOSE. THE USER MUST ASSUME
THE ENTIRE RISK AS TO THE 
QUALITY AND PERFORMANCE OF 
THE SOFTWARE. SHOULD THE 
SOFTWARE PROVE DEFECTIVE, 
THE USER ASSUMES THE ENTIRE 
COST OF ALL NECESSARY 
SERVICING, REPAIR, OR 
CORRECTION. ANY LIABILITY 
OF THE SELLER WILL BE LIMITED 
EXCLUSIVELY TO PRODUCT 
REPLACEMENT OR REFUND OF 
PURCHASE PRICE. THIS WARRANTY 
GIVES YOU SPECIFIC LEGAL 
RIGHTS AND YOU MAY ALSO 
HAVE OTHER RIGHTS WHICH VARY 
FROM STATE TO STATE.

LIMITATION OF LIABILITY:
IN NO EVENT SHALL GALT 
TECHNOLOGY OR ANY OF IT'S 
AUTHORIZED DEALERS OR 
SUPPLIERS BE LIABLE TO YOU 
OR ANY OTHER PARTY FOR ANY 
DAMAGES WHATSOEVER (INCLUDING, 
WITHOUT LIMITATION, DAMAGES 
FOR LOSS OF BUSINESS PROFITS, 
LOSS OF SAVINGS, BUSINESS 
INTERRUPTION, LOSS OF BUSINESS 
INFORMATION, OR OTHER 
INCIDENTAL OR CONSEQUENTIAL 
DAMAGES) ARISING OUT OF THE 
USE OF OR INABILITY TO USE 
THIS SOFTWARE, EVEN IF GALT 
TECHNOLOGY HAS BEEN ADVISED 
OF THE POSSIBILITY OF SUCH 
DAMAGES. SOME STATES DO NOT ALLOW 
THE LIMITATION OR EXCLUSION OF 
LIABILITY FOR INCIDENTAL OR 
CONSEQUENTIAL DAMAGES SO THE 
ABOVE LIMITATION OR EXCLUSION MAY 
NOT APPLY TO YOU.

General:
You acknowledge that you have read this 
agreement, understand it, and that by opening
or using this software you agree to be bound 
by these terms and conditions. You further agree 
that this is the complete and exclusive 
statement of the agreement between you and 
Galt Technology, which supersedes any proposal 
or prior agreement. All rights in the software 
not specifically granted in this Agreement 
are reserved by Galt Technology.
If you have any questions about this agreement,
contact GALT TECHNOLOGY in writing or by fax.

Galt Technology
14510 Big Basin Way, Suite #195
Saratoga, CA  95070
http://www.galttech.com
e-mail: info@galttech.com

Thank you for using LogoSaver and for supporting
the shareware conecpt.
