         =======================================================
         View2 Plus (TM): Total Window Management for Word 6 & 7
         =======================================================
         Copyright � Michael M. Ross, 1997. All rights reserved.

Dear User,

Congratulations on you decision to download View2 Plus (Version 3)!

Installation is as easy as 1, 2, 3:

1. Extract all the files in this zip archive.
2. Double-click VEW2PLUS.DOC or open the file from Word.
3. Read about and install View2 Plus.

********************************INSTALLATION NOTES*************************************
SYSTEM REQUIREMENTS:
Microsoft Windows 3.1, 3.11, 95, NT 3.51, NT 4.
Microsoft Word 6 or Word 95 (7)
Note: This program is not compatible with Word 97 (8).

SUPPLIED FILES:
Readme.txt		This text file
Vew2Plus.doc	Word6/7 Installation template containing 6 macros
V2PwrPls.dot	Word6/7 Startup template containing 15 macros
Vew2Plus.hlp	Winhelp32 help file
Vew2Plus.cnt	Winhelp32 support help file

RECOMMENDATION:
Before you do anything else, close Word and make a backup copy of your NORMAL.DOT file
(in the WINWORD\TEMPLATE or MSOFFICE\TEMPLATE folder).

ATTENTION:
Virus protection users: VEW2PLUS.DOC is a template containing macro code.
This may trigger software you have installed to protect yourself from Word viruses,
You can do three things:
	1. Ignore the warnings.
	2. Change the filename to VEW2PLUS.DOT.
	3. Delete the AutoOpen macro with Word's Organizer dialog box (File/Templates)
	   before opening the file.
DO NOT disable any other macros, or the installation will not work.

INSTALLING
Just double-click VEW2PLUS.DOC or open the file from Word. Then double-click the Install
button in Word. 

UNINSTALLING:
Follow these simple steps:
1. Delete V2PWRPLS.DOT from your WINWORD\STARTUP folder.
2. Delete VEW2PLUS.HLP and VEW2PLUS.CNT from the WINWORD or MSOFFICE folder.
3. Restore your old version of NORMAL.DOT if you backed it up or do the following:
   --Hold down the ALT key and drag the View2 Plus button off your toolbar.
   --Choose Macro from the Tool menu, select View2Plus and View2Plus16 or View2Plus32
     and delete them.
   --Choose Customize from the Tool menu, and the Window and Help category from the
     Menus tab. From the Position on Menu drop-down, delete the View2 Plus command.   	 
***************************************************************************************

You'll find everything you need to know about using and registering View2 Plus in
online help.

Thank you for your support.

						--Michael M. Ross
						  Wordwise Solutions
						  wordwise@geocities.com

LEGAL NOTICE: Distribution of this archive by third parties is permitted providing that
the files it contains are not altered in any way and that the software is used for the
purpose it was intended.


