
DIAMOND SCHEDULER ... a sports league scheduling program for creating round-robin and elimination style pairings.

A MESSAGE FROM THE AUTHOR
Thanks for taking the time to evaluate Diamond Scheduler, the Windows-based program designed to help you schedule sports leagues. I hope you find the program to be as useful as I've found it to be in our league. The help file embedded within the program and the sample schedule file should answer questions you have about its use. If you have any problems, please feel free to contact me at jhall@cactusware.com.

MINIMUM SYSTEM REQUIREMENTS
Diamond Scheduler is a Windows-based program. While the program will benefit from any speed available to you, I regularly run the program on an x-486 system with adequate results. Regardless of the computer, you should have at least 16mb or more RAM available.

EVALUATING THE PROGRAM
Before registering your copy of Diamond Scheduler, I ask that you thoroughly evaluate the program to make sure it meets your needs. Refunding your shareware registration fee is a pain!

INSTALLING THE PROGRAM
To install the program, navigate to File Manager (for Windows 3.1 machines) or Windows Explorer (for Win95 and Win98) and doubleclick on one of the following files: diamond.exe (if you downloaded the EZ Download file, 16-bit version), diamond32.exe (if you downloaded the EZ Download file, 32-bit version), diamond.zip (if you downloaded the entire program with documentation, 16-bit), diamond32.zip (if you downloaded the entire program with documentation, 32-bit).

TO UNINSTALL THE PROGRAM
For Windows 3.1 users, you will find an uninstall icon in the program group created by Diamond Scheduler. 

For Windows95 and 98 users, go to the Control Panel and choose Add/Remove Programs. You will find Diamond Scheduler listed. Doubleclick on the program name and the program will be uninstalled from your computer.

BUG REPORTS OR SUGGESTED ENHANCEMENTS
If you find any bugs in the program or if you have any enhancements you would like to see in the next version, please feel free to email me at jhall@cactusware.com

REDISTRIBUTION
You are free to redistribute the diamond.zip file to any location as long as the readme.txt file has not been removed.

Diamond Scheduler Copyright 1998 by John R. Hall. 

Thanks again for trying out the program. Please take the time to read the Conditions of Use listed below before installing the program.

Regards,

John Hall

=============================================================================

CONDITIONS OF USE (The legal stuff)

COPYRIGHT.  The Software is owned by John R. Hall and is protected by United States copyright laws and international treaty provisions.  You must treat the Software like any other copyrighted material.

REDISTRIBUTION.  You are welcome to redistribute the original shareware version of the program as long as both the installation program and readme file are included. You may not share registration passwords provided to you upon payment of your registration fee.

LIMITED WARRANTY. John R. Hall warrants that, for 30 days after date of delivery of the Software to you, the disks or CD-ROM will be free from defects in materials and workmanship. Your exclusive remedy for breach of warranty is to request a refund within 30 days of registration. YOU are responsible for the selection of the Software and for the installation of, use of, and verification of results obtained from, the Software.  

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, JOHN R. HALL DISCLAIMS ALL OTHER WARRANTIES AND CONDITIONS, WHETHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION WARRANTIES AND CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT, AS WELL AS ANY WARRANTIES THAT THE OPERATION OF THE PRODUCTS WILL BE INTERRUPTION OR ERROR FREE.  EXCEPT AS EXPRESSLY SET FORTH HEREIN, THE SOFTWARE IS PROVIDED "AS-IS."  ALL WARRANTIES AND CONDITIONS SHALL TERMINATE 30 DAYS FROM DATE OF DELIVERY 
OF THE REGISTRATION PASSWORD FOR SOFTWARE TO THE ORIGINAL LICENSEE.  

LIMITATIONS OF LIABILITY.  IN NO EVENT WILL JOHN R. HALL BE LIABLE FOR ANY INDIRECT, INCIDENTAL, CONSEQUENTIAL, SPECIAL OR EXEMPLARY DAMAGES, ARISING OUT OF OR IN CONNECTION WITH YOUR USE OR INABILITY TO USE THIS SOFTWARE, THE BREACH OF ANY EXPRESS OR IMPLIED WARRANTY OR CONDITION, OR OTHERWISE IN CONNECTION WITH THE SOFTWARE, THE MANUALS, AND/OR THIS LICENSE EVEN IF JOHN R. HALL HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.   IN NO EVENT SHALL JOHN R. HALL'S TOTAL LIABILITY FOR ANY DAMAGES, DIRECT OR INDIRECT, IN CONNECTION WITH THE SOFTWARE, THE MANUALS, AND/OR THIS LICENSE EXCEED THE REGISTRATION FEES PAID FOR YOUR RIGHT TO USE THIS COPY OF THE SOFTWARE. 


