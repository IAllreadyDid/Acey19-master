Help Maker Plus(tm)--The award
winning windows help creation
tool!

To install Help Maker Plus:
Unzip all files and then Run HELPMAKE.EXE