GALTWARE: AlarmMaster v1.2  README and
SOFTWARE LICENSE AGREEMENT - SHAREWARE EDITION
===============================================

Installation:
-------------
Unzip the file you downloaded, then run the 
SETUP.EXE file for the automated installation.

Registration:
-------------
There are 2 different registration options.
The first is for $29, which gets you the
full version of AlarmMaster with no 
shareware nag screens. You also get our Full
Motion video screen saver CD-ROM with 600MB
of incredible video clips. You also get our 
Galt UtilityPack which features 10
additional utilities, including the Video
Launch Pad, SLideShow Pro, and PowerStrip.

The second option is the MEGA-CD for $39. The
MEGA-CD includes all the above, plus 400 color
pictures on CD, our award-winning suite of 15
screen savers, and the Galt GamePack with 6 
challenging games. You get the entire library 
of GALT products -- 32 programs in all, plus 
all the video clips and photos. An incredible 
value.

TO REGISTER---
Compuserve members can register via SWREG using
the ID#8750 for option #1 and ID#9291 for option
#2.
You can also register online at our web site:
http://www.galttech.com
You can call us directly at (408)730-2467
You can fax us directly at (408)730-2467
You can e-mail orders to: order@galttech.com
You can mail orders to:
Galt Technology
14510 Big Basin Way, Suite #195
Saratoga, CA  95070


Instructions:
---------------
Alarm Master is the quick, easy way to set up 
alarms for your PC. Remind yourself to put out 
the dog at 11:30 each night, or to call for a 
pizza in 35 minutes. You can configure daily
alarms as well as regularly occurring alarms.
Even choose your own alarm sounds. Very easy 
to setup and use. See the HELP menu for specific 
instructions on using the program.


===========
License:
===========
BY USING THIS SOFTWARE, YOU AGREE TO THE
FOLLOWING TERMS AND CONDITIONS:

This version of AlarmMaster is shareware. 
You are granted a license to use AlarmMaster 
for a period of up to 30 days. After
that time, you are required to purchase the
product(s) through registration or else 
discontinue its use.

You are allowed to make copies of this 
software and distribute it to your friends 
and co-workers, on electronic bulletin
boards, over networks, and so on, as long 
as the product is not distributed for
profit (handling fees up to $5.00 ok). 
If you distribute this software, you agree 
to distribute this installation executable 
which contains the associated files together 
as a group. You are not allowed to bundle 
this software with other products without 
prior written permission from Galt Technology.

Ownership of software:
As licensee, you own the media upon which 
the software is recorded or distributed and 
are entitled to use the software, but Galt 
Technology retains title and ownership of 
the original software and all subsequent copies. 
This license is not a sale of the software or 
any copy. You are not allowed to make any 
modifications to, or to create derivative 
works from any of the files that are used 
in this software. This includes all the 
executable, help, installation, and readme 
files, as well as video files.

LIMITED WARRANTY:
THE SOFTWARE HEREIN ARE 
PROVIDED "AS IS" WITHOUT 
WARRANTY OF ANY KIND, EITHER 
EXPRESSED OR IMPLIED, BUT 
NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR 
PURPOSE. THE USER MUST ASSUME
THE ENTIRE RISK AS TO THE 
QUALITY AND PERFORMANCE OF 
THE SOFTWARE. SHOULD THE 
SOFTWARE PROVE DEFECTIVE, 
THE USER ASSUMES THE ENTIRE 
COST OF ALL NECESSARY 
SERVICING, REPAIR, OR 
CORRECTION. ANY LIABILITY 
OF THE SELLER WILL BE LIMITED 
EXCLUSIVELY TO PRODUCT 
REPLACEMENT OR REFUND OF 
PURCHASE PRICE. THIS WARRANTY 
GIVES YOU SPECIFIC LEGAL 
RIGHTS AND YOU MAY ALSO 
HAVE OTHER RIGHTS WHICH VARY 
FROM STATE TO STATE.

LIMITATION OF LIABILITY:
IN NO EVENT SHALL GALT 
TECHNOLOGY OR ANY OF IT'S 
AUTHORIZED DEALERS OR 
SUPPLIERS BE LIABLE TO YOU 
OR ANY OTHER PARTY FOR ANY 
DAMAGES WHATSOEVER (INCLUDING, 
WITHOUT LIMITATION, DAMAGES 
FOR LOSS OF BUSINESS PROFITS, 
LOSS OF SAVINGS, BUSINESS 
INTERRUPTION, LOSS OF BUSINESS 
INFORMATION, OR OTHER 
INCIDENTAL OR CONSEQUENTIAL 
DAMAGES) ARISING OUT OF THE 
USE OF OR INABILITY TO USE 
THIS SOFTWARE, EVEN IF GALT 
TECHNOLOGY HAS BEEN ADVISED 
OF THE POSSIBILITY OF SUCH 
DAMAGES. SOME STATES DO NOT ALLOW 
THE LIMITATION OR EXCLUSION OF 
LIABILITY FOR INCIDENTAL OR 
CONSEQUENTIAL DAMAGES SO THE 
ABOVE LIMITATION OR EXCLUSION MAY 
NOT APPLY TO YOU.

General:
You acknowledge that you have read this 
agreement, understand it, and that by opening
or using this software you agree to be bound 
by these terms and conditions. You further agree 
that this is the complete and exclusive 
statement of the agreement between you and 
Galt Technology, which supersedes any proposal 
or prior agreement. All rights in the software 
not specifically granted in this Agreement 
are reserved by Galt Technology.
If you have any questions about this agreement,
contact GALT TECHNOLOGY in writing or by fax.

Galt Technology
14510 Big Basin Way, Suite #195
Saratoga, CA  95070
Phone:  (408)730-2467
FAX: (408)730-2467
e-mail: info@galttech.com

Thank you for using AlarmMaster
and for supporting the shareware conecpt.
