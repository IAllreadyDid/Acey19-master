
              Choose Edit - Wordwrap to wrap text to window.



BY INSTALLING AND USING THIS SOFTWARE YOU UNDERSTAND THAT YOU ARE ASSUMING ALL RISKS TO YOUR EQUIPMENT AND/OR PERSON ASSOCIATED WITH SAME WHETHER THROUGH THE INSTALLATION PROCESS OR THROUGH USE OF THE PROGRAM ITSELF.  YOU FURTHER UNDERSTAND THAT IT IS A CRIMINAL OFFENCE TO REPRODUCE, ALTER OR OTHERWISE TAMPER WITH THIS SOFTWARE IN ANY WAY WITHOUT WRITTEN AUTHORIZATION. PLEASE CONTACT IMAGINE SOFTWARE BY EMAIL WITH ANY QUESTIONS YOU MAY HAVE.  


                             IMAGINE SOFTWARE 
                          srvaughn@oncomdis.on.ca



                             *** SUBLIME ***
                               Version 2.00



FOR YOUR PROTECTION
A general downloading rule:

Unless you know exactly what you are doing, you may be risking system errors by playing with files you are not familiar with.  Please read and follow the directions as they are given to you in any package you download.


RELEASE NOTES:

This program runs under Windows 3.1 or later.
You may encounter an error with Install if your Windows directory has been named something other than C:\Windows.  Examples:  C:\WIN  C:\WIN95  C:\WINNT  If this is the case, please follow the Manual Installation Instructions.  


_________________________________________________________________________

INSTALLATION:  

1. - Create a new folder and extract all of the files from Sublime2.zip into it.

2. - Double-click INSTALL from within this folder.  The initialization files for Sublime will be copied to the appropriate directory, then you will be taken through a quick setup procedure.  Setup simply creates a directory for the program and builds a Program Manager group.  Note: In the event that you encounter a problem with Install, follow the manual installation instructions below.

3. - Run Sublime2.exe

________________________________________________________________________


MANUAL INSTALLATION INSTRUCTIONS:


There is really only one thing that is imperative for a successful manual installation, and that is to make sure that certain files are copied to your ...\System directory.


WHAT TO DO:

Find out what your ...\System directory is named.  Normally, it is C:\Windows\System.  Other scenarios might include C:\WIN95\SYSTEM, C:\WIN\SYSTEM, C:\WINNT\SYSTEM.  The files noted below need to be in that directory.

WHAT DO I PUT IN MY ...\SYSTEM DIRECTORY?
All of the files in Sublime2.zip should be copied to your ...\System directory EXCEPT for the ones noted below.  Do NOT copy these there, but DO copy all of the others to that location.


Files that DO NOT belong in your ...\System directory:

Sublime2.exe
Readme.txt
Install
set.exe


The files that DO belong are simply all of the others included in the .zip package.

You may create a directory for Sublime2.exe and give it any name you wish.

The manual installation will be complete at that point.

Double-Click Sublime2.exe to run the program.

________________________________________________________________________


INFORMATION:

Sublime is a very easy to use program.  You will need to choose Setup when first running the program to create the messages you wish displayed and set your desired preferences for this display.  The Setup options are quite straightforward; however, if you need assistance simply choose Help from the menu for an explanation of the settings.

Sublime can be used in many ways:  As a subliminal message generator, for self-hypnosis techniques, as a tool to improve your memory or for any other purpose you dream up.  

Use as a subliminal message generator to boost self-confidence or to assist in breaking those unwanted vices.  For example you might enter messages like: I FEEL TERRIFIC; I HAVE ENORMOUS SELF-CONFIDENCE; I HAVE NO FEAR OF HEIGHTS; I HAVE NO DESIRE TO EAT SNACKS; I HAVE NO DESIRE TO SMOKE etc., then simply let Sublime run while you continue other work on your computer.

The same things apply when using Sublime for Self-Hypnosis techniques, the difference being that you would probably use Sublime on its own for total concentration.  Enter messages that will lead you to a relaxed state before the rest appear, and let them stay on the screen for a longer period of time.

Do you have something you would like to remember or memorize?  Enter it as a message in Sublime and let it run over and over while you perform other tasks on your computer.  This works extremely well for most people.  

Dream up your own uses for Sublime.  You may be amazed at the results.



ADDITIONAL NOTES:

You can access Sublime's setup options, pause, or exit the program by selecting the minimized icon.

Sublime is not truly subliminal in the strictest sense of the word, and was not intended to be.  This is so that the person at the computer will always know it is running.  This prevents others from using negative messages in an attempt to influence someone unfairly.

As the author of this program, and witness to its successes, I am satisfied that wonderful results can be obtained with Sublime.  However, this is a personal view and you are to understand that there are no guarantees of any kind given or implied. Subliminal messages/Self-Hypnosis etc. are techniques that work very well for some people, but not all.  I make no claim that this program will produce any given result(s) and waive all responsiblity for any effect on the user of this program or to any others who may encounter it either unintentionally or otherwise.


**  Sublime is Shareware.  You may try it free for 10 days.  After that, we ask that you respect the shareware concept and register your copy.  Sublime is being offered for a very considerate price of $5.00   When you register you will also receive FREE, a screensaver than can display your Sublime messages if desired and 5 unique, Windows Wallpaper designs.  Details of registering your copy will appear in the program after your ten day trial.  If you wish information before that period, please contact us at the email address below.  We thank you for your support.

This program is freely distributable provided that it is not altered in any way.  Any violation of international copyright law will result in prosecution without exception.

Imagine Software - Sublime Copyright �1997

Imagine Software can be reached by email at either of these addresses:
srvaughn@oncomdis.on.ca
imagine@lycosemail.com

