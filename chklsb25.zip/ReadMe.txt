CheckListBox ActiveX/VBX V2.5 Build 11
Copyright (c) 1996-2001 Hai Li, Zeal SoftStudio.
E-mail: haili@public.bta.net.cn
Homepage: http://www.zealsoftstudio.com/ (English)
          http://zealsoft.yeah.net (Chinese)

Last Modified Date: June 24, 2001

Description
-----------
CheckListBox ActiveX/VBX Control provides support for listbox containing checkboxes, which is like the control that is built into Microsoft Word and Excel. In this control, each item's font, color, enabled and checked state can be individually modified. The control also supports 3D look, picture items and custom checkmark. This package includes samples written in Visual Basic 3.0, 4.0, 5.0 and 6.0. CheckListBox is also called Check List. 

What's New
----------
Read History section for details.

Add CheckedCount property(ActiveX only, Build 9)
Add KeyFind property(ActiveX only, Build 7)
Add Grayed property
Add ItemFont property
Add ItemForeColor property
Add ItemBackColor property
Add MultiSelect property(ActiveX only, Build 9)
Add Redraw property(ActiveX only, Build 7)
Add SelCount property(ActiveX only, Build 8)
Add Selected property
Add ShowFocusRect property(ActiveX only, Build 6)
Add ToggleMode property(ActiveX only, Build 5)
Add AddCheckedItem method
Add AddPicItem method
Add CheckAll and UnCheckAll method
ItemImage property now support .ICO and .WMF format
Support Apartment Threaded (Build 2)
Support LB_SETHORIZONTALEXTENT message by which 
	a list box can be scrolled horizontally.
Support Tab (ASCII 9) character (Build 2)
Add DragList sample (Build 10)
Add DragSort sample (Build 10)
Add Product sample (Build 2)
Allow users to turn on/off checkmark.(Build 3)

Upgrade Information
-------------------
Following properties are replaced by Font property in ActiveX version:   
    FontName FontBold FontItalic FontUnderline FontSize
    FontStrikethru

Following properties are replaced by ItemFont property in ActiveX version:   
    ItemFontName ItemFontBold ItemFontItalic
    ItemFontUnderline ItemFontSize ItemFontStrikethru

Folowing properties are not implemented in ActiveX version:
    Align

Folowing properties are not implemented in VBX version:
    CheckedCount, KeyFind, MultiSelect, SelCount, 
    ShowFocusRect, Redraw, ToggleMode

History
-------
2.5 Build 11
	Fix some bugs.
	Improve Products sample.
2.5 Build 10
	Add CHKLSB25.DEP for Visual Basic Setup Wizard.
	Fix the bug of drag and drop.
	Fix the bug of incorrect item height when place more listboxes on a form.
	Add DragList sample.
	Add DragSort sample.
2.5 Build 9
	Add CheckedCount Property property(ActiveX version only).
	Add MultiSelect Property property(ActiveX version only).
	Fix the bug that ListIndex will be set to -1 when 
		Font or ItemFont property is changed.
2.5 Build 8
	Add SelCount property(ActiveX version only).
	Improve the property page(ActiveX version only).
2.5 Build 7
	Add KeyFind property(ActiveX version only).
	Add Redraw property(ActiveX version only).
	Support LB_SETHORIZONTALEXTENT message by which 
		a list box can be scrolled horizontally.
	Fix the bug of flash when set BackColor to black.
	Fix the display problem in small fonts setting.
	Rewrite the Products sample.
2.5 Build 6
	Add ShowFocusRect property(ActiveX version only).
	Fix the bug that moving selection using keyboard 
		won't fire Click event.
	Fix the bug that ListIndex property can't be set to -1.
2.5 Build 5
	Add ToggleMode property(ActiveX version only).
2.5 Build 4
	Set the Text property as the default property.
	Fix the focus rectangle bug when turning of checkmark.
	Improve the display when turning off checkmark.
2.5 Build 3
	Allow users to turn on/off checkmark.
	Fix some help document errors.
2.5 Build 2
	Support Apartment Threaded
	Support the Tab (ASCII 9) character
	Add a new Product sample
	Fix display problem with font size greater than 10 points
2.5
	Add ActiveX Control version.
	Add ItemFont property.
	Add ItemForeColor property.
	Add ItemBackColor property.
	Add Grayed property.
	Add Selected property.
	Add AddCheckedItem method.
	Add AddPicItem method.
	Add CheckAll and UnCheckAll method.
	ItemImage property now supports .ICO and .WMF format.
	Add Visual Basic 5.0 sample.
2.1
	Rewrite documentation.
	Add version information into VBX file.
	Fix compatible problems with Visual Basic 4.0.
	Add a Visual Basic 4.0 sample.
	Improve Visual Basic 3.0 sample.
2.0
	Add Appearance property.
	Add ItemImage property.
1.0
	Optimize display speed.
	Add a Visual Basic 3.0 sample.
1.0Beta
	Initial Version.