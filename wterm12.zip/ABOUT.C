/* about.c */

#include "windows.h"
#include "about.h"

BOOL FAR PASCAL AboutDlgProc(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
 switch (message)
    {
     case WM_INITDIALOG:
         return (TRUE);

     case WM_COMMAND:
         if (wParam == IDOK || wParam == IDCANCEL)
           {EndDialog(hDlg, TRUE);
            return (TRUE);
           }
         break;
    }
    return (FALSE);
} /* end AboutDlgProc */
