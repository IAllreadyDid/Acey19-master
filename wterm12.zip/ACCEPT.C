/* about.c */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "windows.h"
#include "accept.h"

#define TEXT_SIZE 32

static int  GotTextFlag = FALSE;
static char TextEditBuf[TEXT_SIZE] = {""};

int GetAcceptText(char *Ptr)
{if(GotTextFlag)
   {strncpy(Ptr,TextEditBuf,TEXT_SIZE-1);
    GotTextFlag = FALSE;
    return TRUE;
   }
 return FALSE;
}

BOOL FAR PASCAL AcceptDlgProc(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
 switch (message)
    {
     case WM_INITDIALOG:
         /*SetDlgItemText(hDlg,IDD_EDIT,TextEditBuf);*/
         return (TRUE);

     case WM_COMMAND:
         switch (wParam)
           {case IDD_EDIT:
              GetDlgItemText(hDlg,IDD_EDIT,TextEditBuf,TEXT_SIZE);
              return TRUE;
            case IDOK:
              GotTextFlag = TRUE;
              EndDialog(hDlg, TRUE);
              return TRUE;
           }
         break;
    }
    return (FALSE);
} /* end AcceptDlgProc */
