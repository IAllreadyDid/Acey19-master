/* file_io.c */

#include "windows.h"
#include "file_io.h"

long FileLength(int Handle)
{long lCurrentPos = _llseek(Handle,0L,1);
 long lFileLength = _llseek(Handle,0L,2);
 _llseek(Handle,lCurrentPos,0);
 return lFileLength;
} /* end FileLength */

void ComputeSize(long FileSize,int OneKflag,int *Nbr1024Ptr,int *Nbr128Ptr)
{/* compute # 1K & 128 byte blocks */
 if(OneKflag) *Nbr1024Ptr = (int) (FileSize / 1024L);
 else *Nbr1024Ptr = 0;
 *Nbr128Ptr = (int) ((FileSize-1024L*(long)(*Nbr1024Ptr)) / 128L);
 if(128L*(*Nbr128Ptr)+1024*(*Nbr1024Ptr)<FileSize) (*Nbr128Ptr)++;
} /* end ComputeSize */