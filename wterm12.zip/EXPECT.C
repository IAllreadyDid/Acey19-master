/*** expect.c ***/

#include "windows.h"
#include "expect.h"

/* globals */

extern HWND hMainWnd;
extern int  OnLineFlag;
extern char XferState;

int ExpectOnLine(void)
{if(!OnLineFlag)
   {ErrorMessage("Must be ONLINE");
    return FALSE;
   }
 return TRUE;
} /* end ExpectOnline */

int ExpectOffLine(void)
{if(OnLineFlag)
   {ErrorMessage("Must be OFFLINE");
    return FALSE;
   }
 return TRUE;
} /* end ExpectOffline */

int ExpectNoXfer(void)
{if(XferState!=' ')
   {ErrorMessage("File xfer in progress");
    return FALSE;
   }
 return TRUE;
} /* end ExpectNoXfer */

void ErrorMessage(char *MsgPtr)
{
 MessageBox(hMainWnd,MsgPtr,"ERROR",MB_TASKMODAL | MB_ICONEXCLAMATION | MB_OK);
}
