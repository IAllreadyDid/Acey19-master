David Aylott's Utilities for Windows 3.x

WINUTILS16

Version 4.0


Introduction:
 
This collection of 16-bit utilities performs some useful tasks for users of
Windows 3.x

For users of Windows 9x and Windows NT, 32-bit versions of these utilities
(WINUTILS32) are available from the software page at our web site:
http://www.bigfoot.com/~daylott/software.htm

The utilities have been released as Shareware - you are welcome to try
them out free of charge for a period of 30 days. If you find them useful
please pay the author as detailed below otherwise you are required to
delete them from your PC. Your support will make it possible to produce
updates and additional Windows applications.
 
You are encouraged to pass these utilities on to friends and colleagues
but please keep them in their original format and with all files included
in the package. 

 
Installation:

IMPORTANT: If you are upgrading from a previous registered version of
WINUTILS, you should make a copy of WINUTILS.INI before following these
instructions. You can then restore your WINUTILS.INI after installing the
upgrade.

Copy all of the files into any folder (eg C:\WINUTILS). To make life
easier for you, the folder should be included in your PATH (refer to
the WINUTILS.HLP file for instructions).

You may also need to install the VB3 run-time file (VBRUN300.DLL). You
can download this file from http://www.bigfoot.com/~daylott/software.htm
This file should be installed in your WINDOWS\SYSTEM directory.

You can then create Program Items for each of the utilities as described in
WINUTILS.HLP.


The Utilities:

BOOTWIN  - reboots the PC from Windows
CLOSEALL - closes all (or selected) applications and windows
DELAYRUN - Runs a program after a specified delay
ENDWIN   - exits from Windows
INIEDIT  - Opens the WINUTILS.INI file in notepad for editing
INIPAD   - Front-end GUI for changing NPAD & WRITE3X
MINALL   - minimises all applications and windows
NPAD     - allows the notepad defaults (eg margins and
           filetype) to be changed
PLAYSND  - plays a single .WAV file
QRYEXIT  - Prompts with an optional message before closing
           down Windows
REGISTER - registers the Windows Utilities
RESTWIN  - restarts windows without rebooting
RUNQUIT  - runs a program and then exits from Windows
RUNSND   - allows a different sound to be associated with
           each and every application
STARTSND - plays a different sound at user specified times
           (eg at startup)
TIMEPROG - runs a program for a specified time (eg to limit
	   the use of games)
WINTIME  - windows scheduler that runs programs or send
           messages at specified times
WRITE3x  - allows the write default fonts and margins to be
           changed


For more information, please refer to the WINUTILS.HLP file.


Payment:

To receive the registration code to run ALL of the WINUTILS on a single PC,
please send US$25 to:

David Aylott
2/35 Bertram Street
ELSTERNWICK VIC 3185
Australia

This one small fee gives you access to the full power of this application
and any future updates or bug fixes. If you wish to negotiate multiple or
site licences, please contact us.

Print out and complete the ORDER.TXT file to make this process easier.

For registration of individual utilities, please refer to the WINUTILS.HLP
file.

Please e-mail daylott@bigfoot.com first if you are in the US, Australia or
the UK as other payment options are available (eg deposit to bank accounts).


Do remember to include the following:

�	The version of WINUTILS you are using
�	Where you discovered WINUTILS
�	Your Email (or street) address or a fax number for the registration
        code
�	A self addressed envelope if you wish to receive the registration
        details by post
�	Any comments or suggestions for improvements you may have


Credit Card Payment:

You can pay by credit card via the following secure link:

https://www.regnow.com/softsell/nph-softsell.cgi?item=1893-2


History

v2.1	- Initial Release as Shareware 12/6/97

v2.2	- Addition of SHUTDOWN & SHUTOPTN utilities 7/9/97

v2.3	- Released 10/10/97
	  Many utilities rewritten
	  Addition of DEFPRINT, ENDSHARE & STARTSND
	  PLAYSND and RUNSND now use SNDREC32 if running Win95
	  New Max entry for NPAD & WPAD to open maximised
	  Performance increased when using SHUTOPTN utility
	  Ability to hide SHUTOPTN, ENDSHARE & WINTIME whilst running
	  Option to register several individual utilities introduced
	  CLOSEALL enhanced to allow closing of nominated windows
	  All utilitites can now be run from the DOS command line
          (eg in a batch file)
	  2.3b added the optional parameter to RESTWIN to delay the
	  restart process
	  2.3c ability to register RUNQUIT utility

v2.4	- Released 9/3/98
	  Updated WPAD for NT 4
	  Several minor changes to routines to enable operation with NT
	  Addition of INIEDIT and CLOSEWIN routines
	  2.4a ability to register NPAD & WPAD separately

v3.0	- Addition of BOOTWIN, WINTITLE, WRITE3X, FINDMAX, WLOGOFF,
          INIPAD, VOLREC, SHUTOPTN32
	- TIMEPROG & RUNQUIT rewritten for additional reliability
        - NPAD & WPAD rewritten
	- ability to register TIMEPROG separately
        - Released 12/01/99

v4.0    - Separated into two version (16-bit and 32-bit)
	- Addition of QRYEXIT and DELAYRUN
	- Several utilities rewritten in VB3


Other Applications from Aylott Computing:

*	WINUTILS. A handy collection of Windows utilities to close down
        and restart Windows at the click of a button, schedule programs,
        close all open windows, close programs after a specified time,
        change notepad and wordpad defaults etc)

*       Microsoft Access Version Checker (ACCVER). This is an essential
        utility if you run more than one version of MS�Access on your PC.
        ACCVER detects the version of Access used to create your MDB or
        MDA file and either reports the version number or starts the
        appropriate version of MS�Access

*	User Logging and Tracking Utility (USERLOG). Stores a record of
        when users log on and off from Windows. As an option, it also
        tracks the applications and windows used in each session together
        with times spent in each
		
*	LISTFONT. MS Word Font Listing Macro to produce a sorted list of
        all your fonts with multiple fonts to a page. Allows multiple or
        single line listings or the entire character set to be displayed
        in any font size.

*	FONTFILE. View and Print a sorted list of your font names and
        filenames. Allows a compact printed list of all your TTF, ATM
        and Screen fonts to be kept for reference. Can also be used to
        compare saved lists of fonts with those currently installed to
        find added or deleted fonts.

*	LISTCLIP. MS Word Clipart Listing Macro to produce thumbnails
        of all your graphics files with multiple pictures to a page.

*	PFONT. Font Printing Program that prints a sorted list of all
        your fonts in a range of font sizes. Multiple font samples are
        listed on each page allowing a compact record of all your fonts
        to be kept for reference.

*	MS Access Country Database (over 250 countries incl. capitals,
        2 letter country codes, currency, flags, maps etc)

*	Biorhythms (decide when to stay in bed and when to get up)

*	English to French Translation (actually, it's Franglais just for
        fun!)

*	DMUSIC. A Music Player to play all your .WAV, .MID and .RMI
        files in order, randomly etc. - lots of options.

*	Guessing Game. Ask me 10 questions and see if you can guess the
        object - just a bit of fun.

*	Banquet Auction Database for schools and other organisations
        (takes all the hard work out of fund raising)

*	Mailing Databases (keep track of your contacts by various
        categories - print reports, labels and mail merge letters etc)

*	Help Desk Database (log problems and resolutions - print reports
        of outstanding and completed requests etc)

*	Donor Database for schools and other organisations to store
        information on students, past students etc (campus, qualifications,
        notes, donations etc)



Email: daylott@bigfoot.com
 
http://www.bigfoot.com/~daylott/


If you have requirements for any Windows Applications or Utilities please
contact us.

We welcome any comments and suggestions for improvement.
