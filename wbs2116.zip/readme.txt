wbStego 2.1 is a steganography tool. It "hides" any data in bitmaps or text files.
These carrier files are not obviously modified. So anyone viewing these files will
not even be aware of the fact that they contain other data - an important advantage
in comparison to cryptography software. Ideal for exchanging sensitive data - 
especially online. Simply transfer a harmless and uninteresting bitmap or text -
containing anything you want: texts, graphics, photos, executable files ...
wbStego 2 offer two user interfaces: The wbStego Wizard and the Flowchart Mode.
The wbStego Wizard is an easy to use step by step guide through encoding and 
decoding and extensive online help for each step. Ideal for user who haven't worked 
before with any kind of privacy software. The Flowhart Mode is for advanced users.
You make all settings in an overview graphic - fast & efficient.
Don't take the risk that anyone can read your online communication any longer!

Shareware. Freely distributable. Uploaded by the author.

Updates wbStego 2

Changes: Bugs corrected, installation routine added

Werner Bailer
wbstego@mustbuy.com
http://members.xoom.com/wbailer/wbstego