Retirement Countdown Screen Saver
README & SOFTWARE LICENSE AGREEMENT
 - SHAREWARE EDITION
=========================

This screen saver is FREE for you to 
use and distribute. It may not be sold as
a stand alone program, but may be included
on CD-ROM collections and sold as a package.

You can find over 600 screen savers for download
at our site, The Galt Shareware Zone:
http://www.galttech.com

Please drop by.


License:
-----------
BY USING THIS SOFTWARE, YOU AGREE TO THE
FOLLOWING TERMS AND CONDITIONS:


You are allowed to make copies of this 
software and distribute it to your friends 
and co-workers, on electronic bulletin
boards, over networks, and so on, as long 
as the product is not distributed for
profit (handling fees up to $5.00 ok).
Inclusion on shareware CD-ROMs is also allowed
as long as the CD clearly explains the 
shareware concept.
 
If you distribute this software, you agree 
to distribute this installation executable 
which contains the associated files together 
as a group. You are not allowed to bundle 
this software with other products without 
prior written permission from Galt Technology.

Ownership of software:
As licensee, you own the media upon which 
the software is recorded or distributed and 
are entitled to use the software, but Galt 
Technology retains title and ownership of 
the original software and all subsequent copies. 
This license is not a sale of the software or 
any copy. You are not allowed to make any 
modifications to, or to create derivative 
works from any of the files that are used 
in this software.

LIMITED WARRANTY:
THE SOFTWARE HEREIN ARE 
PROVIDED "AS IS" WITHOUT 
WARRANTY OF ANY KIND, EITHER 
EXPRESSED OR IMPLIED, BUT 
NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR 
PURPOSE. THE USER MUST ASSUME
THE ENTIRE RISK AS TO THE 
QUALITY AND PERFORMANCE OF 
THE SOFTWARE. SHOULD THE 
SOFTWARE PROVE DEFECTIVE, 
THE USER ASSUMES THE ENTIRE 
COST OF ALL NECESSARY 
SERVICING, REPAIR, OR 
CORRECTION. ANY LIABILITY 
OF THE SELLER WILL BE LIMITED 
EXCLUSIVELY TO PRODUCT 
REPLACEMENT OR REFUND OF 
PURCHASE PRICE. THIS WARRANTY 
GIVES YOU SPECIFIC LEGAL 
RIGHTS AND YOU MAY ALSO 
HAVE OTHER RIGHTS WHICH VARY 
FROM STATE TO STATE.

LIMITATION OF LIABILITY:
IN NO EVENT SHALL GALT 
TECHNOLOGY OR ANY OF IT'S 
AUTHORIZED DEALERS OR 
SUPPLIERS BE LIABLE TO YOU 
OR ANY OTHER PARTY FOR ANY 
DAMAGES WHATSOEVER (INCLUDING, 
WITHOUT LIMITATION, DAMAGES 
FOR LOSS OF BUSINESS PROFITS, 
LOSS OF SAVINGS, BUSINESS 
INTERRUPTION, LOSS OF BUSINESS 
INFORMATION, OR OTHER 
INCIDENTAL OR CONSEQUENTIAL 
DAMAGES) ARISING OUT OF THE 
USE OF OR INABILITY TO USE 
THIS SOFTWARE, EVEN IF GALT 
TECHNOLOGY HAS BEEN ADVISED 
OF THE POSSIBILITY OF SUCH 
DAMAGES. SOME STATES DO NOT ALLOW 
THE LIMITATION OR EXCLUSION OF 
LIABILITY FOR INCIDENTAL OR 
CONSEQUENTIAL DAMAGES SO THE 
ABOVE LIMITATION OR EXCLUSION MAY 
NOT APPLY TO YOU.

General:
You acknowledge that you have read this 
agreement, understand it, and that by opening
or using this software you agree to be bound 
by these terms and conditions. You further agree 
that this is the complete and exclusive 
statement of the agreement between you and 
Galt Technology, which supersedes any proposal 
or prior agreement. All rights in the software 
not specifically granted in this Agreement 
are reserved by Galt Technology.
If you have any questions about this agreement,
contact GALT TECHNOLOGY in writing.

Galt Technology
14510 Big Basin Way, Suite #195
Saratoga, CA  95070
e-mail: info@galttech.com

