ywoop10.zip
Your Weight on Other Planets
written by Eugene Osmera, Copyright (c) 1999.

Your weight on other planets is a FREEWARE program that computes your weight in pounds or kilograms on the planets of our solar system, plus the Sun and Moon.

FILES:
ywoop10.exe ...... the program
readme.txt ..... this file

INSTALLATION:
Just unzip.

TO RUN:
Click on the program, ywoop.exe, to start the program.
Step 1, asks you to pick pounds or kilograms.
In Step 2, you enter your weight in number form, example: 100.
Then click the enter button.
The results are shown to the right.

UNINSTALLING:
Just delete the files.

NEED TO RUN:
You need a Windows Operating system and vbrun300.dll, which can be found at:
ftp://ftp.simtel.net/pub/simtelnet/win3/dll/vbrun300.zip

TESTED ON:
This program was tested on a pentitum computer with win95.

EASTER EGG:
In the about box.

CONTACT:
eood51@hotmail.com

WARRANTY:
No warranties.

Freely distributable.



