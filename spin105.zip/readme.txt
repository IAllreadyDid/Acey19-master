
Read this before you get started with version 1.05

1.  Spinnaker Tools is a suite of excel add-ins particularly suited for analyzing and maintaining lists and databases in Excel. Features easy advanced filters, easy moving/deleting/hiding/displaying columns, field joining with concatenation, merging workbooks, printing multiple ranges on one page, printing multiple sections of one or more columns on one page.
 

2. There is no installation required. You copy the files in a directory you will remember and simply double-click on the filename in filemanager. Excel will start up and open the add-in.

3. The status of the program is Shareware.

4. There are no limitations on the distribution of this software.

5. You can contact us at 978-887-0863 or 603-436-0052 or you can e-mail us at getinfo@spinnaker.org

Thank you

Hessel Flach & David Parise