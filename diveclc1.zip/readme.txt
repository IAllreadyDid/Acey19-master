DIVE CALC 1.0 - readme.txt

PURPOSE:
  Dive Calc 1.0 is to be used as a check of one's dive planning 
  calculations.  The program should NOT be used in place of 
  proper training or full understanding of safe dive practices.

INSTALLATION:  *NOTE* This program will not run on Windows 3.1
  1. Unzip the file to its own subdirectory.  For example - c:\divecalc
  2. The file vbrun300.dll must be in the c:\windows\system 
      subdirectory. It is available through this same download service.
      Download it and unzip it to the c:\windows\system directory.
  3. 'Run' the setup.exe program 
  
STATUS:
  Dive Calc 1.0 is Freeware but it is also copyrighted.  That means you
  are free to use it without cost but all other rights are reserved.   

DISTRIBUTION:
  Distribute Dive Calc 1.0 freely.

AUTHOR:
  In the event of questions or problems the author may be contacted at:
    	
	Clyde Mighells
	739 Cleveland Drive
	Cheektowaga, NY 14225
	716-834-3759
	pastorclyde@netscape.net

  CONSTRUCTIVE ideas toward improving the software are also welcome.
