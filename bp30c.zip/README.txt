BikePro Installation from Zip File

There's just a few more steps to install BikePro

After being unzipped, BikePro installs like a standard Windows application.    Before you can install BikePro, please check to insure that you have the file VBRUN300.DLL.  This file should be in the \WINDOWS\SYSTEM directory of your computer.  If you don't have this file, it can be down loaded from a variety of locations, including:

CompuServe: 	GO WINSHARE  -- Search library using keyword VBRUN300.DLL

AOL:		GO SOFTWARE  -- Search library using keyword VBRUN300.DLL	

Internet:	a. BikePro home page at http://www.he.net/~bikepro

		b. FTP:  oak.oakland.edu/pub3/simtel-win3/dll/vbrun300.zip

Once VBRUN300.DLL is installed, do the following to install BikePro:

For Windows 95 Users:

1.  Open the folder in which BikePro was unzipped.

2.  Double click on the SETUP.EXE icon.

3.  Follow the instructions in the BikePro Setup procedure.

For Other Windows Users:

1.  Select RUN from the File Menu or the Program Manager.

2.  Enter c:\[bpzipdir]\setup.exe for the program to run.

3.  Follow the instructions in the BikePro Setup procedure.


At this point, BikePro is installed in the directory BPRO30, or other directory that you specified during the installation.  To save disk space, delete the unzipped BikePro files in the [bpzipdir] directory.  Be sure not to delete the BP30a.ZIP archive file.  You may need it to reinstall BikePro, or to pass on to a friend. 

Attention Windows 3.1 Users:

After you install BikePro, and try to run it, you may receive a message indicating that one or more files are missing.
If you receive this message, you must copy the following support files from the directory in which you unzipped the
BikePro files, to the \WINDOWS\SYSTEM directory.  Do not use these files if
you are using Windows 95.

Compobj.dll, ole2.dll, ole2disp.dll, ole2nls.dll, storage.dll

