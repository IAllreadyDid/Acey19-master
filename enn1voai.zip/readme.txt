DOCUMENTATION FOR EDITING OF AI MEMORY AND VOCABULARY
-----------------------------------------------------

!!THIS PRODUCT IS DISTRIBUTED AS FREEWARE!!!.. and as such may be freely distributed.


SUPPORT:
-------
Support is available by using the contact listed below.

X&A Digital _Toronto, Canada
URL: WWW.GEOCITIES.COM/ENN_1
Email: enn_1@yahoo.com
Fax: (905) 791-3897
Voice: (905) 791-0710



REQUIREMENTS:
------------
IBM COMPATIBILITY
WINDOWS 3.0 plus
SOUND CARD (this is beta. Try em all!!  Lemme know!!)
2 MEG STORAGE


OVERVIEW
--------
The term AI is short for artificial intelligence.  This product
is an artificial intelligence in that it can be "taught" new things
and will retain in memory and retrieve from memory any information
entered in plain text.

The unique thing and most exciting thing about "eNn" is its ability
to output information stored in its memory using voice output.

eNn can also read (voice output) any plain text document after certain
conditions have been met.

This is the first beta release of eNn and as such there are no guarantees,
in particular where sound card compatibility is concerned.  We will be
able to answer questions in this regard after some amount of testing.



SETUP:
-----
The issue of M_SETUP.EXE included on this disk will do the following
when involked;

-create "C:\ENN" and copy program files to that directory
-create "C:\ENN\VOCAB" (DOWNLOAD "ENN1-VOC.ZIP" FROM OUR WEBSITE AND UNZIP TO THIS FOLDER) 

To run eNn, execute "C:\ENN\ENNBETA.EXE" from your file manager.

***WARNING****
Do not execute "ENNBETA.EXE" until you have run M_SETUP.EXE as the
program will not run correctly.


LIST OF TOPICS:
--------------
1_ Voice Outputting Documents
2_ Adding To AI Vocabulary
3_ Adding Timed Events
4_ Adding Data
5_ Removing Timed Events and Data
6_ Notes



Voice Outputting Documents:
--------------------------
eNn can read any plain text document as long as the following conditions
are met;

	1. The document to be voice outputted by eNn must
	   be plain text and must bear the DOS file extension
	    ".txt"

	2. Any files to be read must be placed in the directory
	   "c:\enn\".  When you run eNn, files that have met the
	   above requirements will appear in the list labelled;
	   "Read Files" when you select the read option.
NOTE:
By clicking any filename in this list eNn will voice output the text
contained in the file.

***IMPORTANT:
Only words already in eNn's vocabulary will be heard as eNn reads
the document.  Words that are not in eNn's vocabulary will be silent.

The next section explains how words can be added to eNn's vocabulary.
The more developed eNn's vocabulary is, the less ristricted its
abilities will be.  (Just like raising a child!! :)


Adding To AI Vocabulary:
-----------------------
In the directory "c:\enn\vocab\" are about 100 ".wav" files.  Each
of these files represents a word eNn already knows.

To improve eNn's vocabulary you simply record new ".wav" files and
place them in this directory.  The name of your ".wav" file must be
the same as the word you recorded.

	eg;

	If you want eNn to be able to say "sugar" you record
	the word sugar using a microphone and your ".wav"
	editing program. and save the file as "sugar.wav"

There is the obvious limitation of the fact that DOS files can only be
8 - characters maximum.  eNn is restricted to words 8 - characters or less.
MY ADVICE; "Use synonyms"

SPECIAL NOTE:
The current voice output files are (8-bit mono) ".wav" files.  You may
record better quality ".wav" files if you see fit.
****THE PROGRAM WILL ONLY RUN ON ".WAV" FILES.


A VERY SPECIAL NOTE:
If you've actually read this far into this file then you probably have
an interest in this kind of stuff.  Therefore.  When you have developed
a bit of a vocabulary for eNn, feel free to create a ".zip" file of
the ."wav" files and attach it to email to "m3dmedia@nu.net"
A collaborative effort in this respect will mean eventually a library
of eNn vocabulary in every concievable language.


Adding Timed Events:
-------------------
When you click the "EDIT DATA" button in the program eNn, you are
presented with the "Edit Data Plate".

You may select either the "Timer Heading" or "Data Heading" option.

The timer heading option allows you to enter events you want
eNn to output as well as the exact time of day you want eNn to
output this info.

When you select the "Timer Heading" option, you are presented with an
"Hour" and a "Minute" entry.

Type the exact hour and minute you
want the event outputted (13:00 - 24:00 if creating events
between 1 pm and 12 midnight).

In the "Events and Data" entry you then type the event you want
eNn to output.

Click the save button.

	
Adding Data:
-----------
When you click the "EDIT DATA" button in the program eNn, you are
presented with the "Edit Data Plate".

You may select either the "Timer Heading" or "Data Heading" option.

The "Data Heading" option allows you to enter data you want
eNn store in its database.

When you select the "Data Heading" option, you are presented with a 
"Data Heading" and a "Reference" entry.

Type a heading for the new data.
If you want a link (or "reference") to be established to a related
heading, type the related heading in the reference entry.

In the "Events and Data" entry,type the information you want added
to eNn's database under the heading you have appointed.

Click the save button.



Removing Timed Events and Data:
------------------------------
When you click the "EDIT DATA" button in the program eNn, you are
presented with the "Edit Data Plate".

if you enter an existing timer heading or data heading in the
appropriate entry, the events or data associated with that heading
appear in the Events and Data entry.

To remove all of this data and its heading from eNn's memory, simply
click the remove button.


***NOTES***

Appending to Events and Data;
----------------------------
If there are events already programmed at the time period you have
selected, or data already under the heading you have used, they will
appear in the "Events and Data" entry.

Append your new event or data to any existing events and save it.

eNn will output all events associated with an appointed time, or all
data associated with a heading.

On eNn's Vocabulary;
-------------------
eNn will only repeat words that are in its vocabulary.


On Punctuation;
--------------
USE PROPER PUNCTUATION.  Especially at the end of each sentence
and line in your text files, you must use a (".", "!" and "?")
