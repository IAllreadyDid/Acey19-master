
WELCOME TO A.V.E'S PERSONAL SCREEN SAVER <http://www.avent.com>
******************************************************************

General
*********
"NapSnap" your Personal ScreenSaver is a Windows 3.1 & Windows 95
customizable screen saver which will enable you to personalize 
your PC's "nap time" display, using your own photos or graphics
in either GIF,BMP,PCX or JPG format, as well as sounds in WAV 
format. Your idling computer will come alive with sights and 
sounds of your own selection. You may elect to send us photos to 
be scanned, or of course you could easily download images from any 
internet site.

The endless combinations of images, sounds, titles and reminders, 
will let you customize your computer idle time, making it a 
showcase of your family album, memories and fantasies.

"Snap2it" is a built-in event reminder which will pop up during 
a pre-set day, with image, sound and caption. This alert option is 
very simple to use, an excellent feature that will help you avoid 
conflicts with family and friends. 

Installation
*************
To install the Personal ScreenSaver, simply run the "install.exe" 
file and answer the options to your liking. The Personal ScreenSaver 
is now installed as part of your Windows' Control Panel. 

To set it up in Windows 95, go to the "Control Panel", 
choose "Display"/"Screen Saver"/"Personal Screen Saver/"Settings". 

To set it up in Windows 3.1, go to the "Control Panel" choose 
"Desktop"/"Screen Saver"/"Personal Screen Saver"/"Settings".

Follow the on-screen instructions which will appear on a yellow 
background as you point to each of the features in the "Settings"
menu.  

Registration
**************
This Shareware program you've downloaded, is a free evaluation copy 
and is fully functional, feel free to distribute it to anyone. This 
version will let you replace 3 of our demo pictures with 3 of your 
own. In order to display unlimited number of images, you'll need a 
registration code which could be obtained by accessing our web site 
at: http://www.avent.com  and clicking on the "Register/Order" 
button. Fill out the order form, a registration code will be 
e-mailed to you as soon as your credit card is approved.


Questions? Problems?
**********************
Please e-mail us at ave@orausa.com

