***********************************************************************

                           Dynamics Solver 1.00
                             16-bit edition
          for Windows 3.1+, Windows for Workgroups 3.11 and 
                Windows 95, Windows 98, WIndows NT 4.+
 
             Copyright (C) 1992-1998 Juan M. Aguirregabiria
                          All rights reserved
                                                 
***********************************************************************

(Let us assume that you have inserted the distribution disk in unit A:)

-----------------------------------
To install Dynamics Solver from DOS
-----------------------------------
type at the command line prompt:
        WIN A:INSTALL
and press <Enter>.

---------------------------------------
To install Dynamics Solver from Windows 
---------------------------------------
select the "File/Execute" entry of Program Manager, 
write in the "Command line" edit box 
        A:INSTALL 
and press <Enter> (or click on the OK button). 
You might also use the Program Manager to start the INSTALL program. 


----------------------------------------
To install the documentation file DS.PDF
----------------------------------------

Copy it to the program directory. It is in Adobe PDF  format and can be
seen on the screen (and sent to ANY correctly installed printer) by
means of the free Adobe Acrobat Reader that you probably have installed
in your system. If this is not the case, just visit Acrobat page:
http://www.adobe.com/acrobat (The documentation is also available in
Postscript format from the Author's home page: see below.)


----------------------------
To uninstall Dynamics Solver
----------------------------

use the the "Uninstall" icon from the Dynamics Solver group 
in Program Manager


----------------------------------------------
Copyright (C) Juan M. Aguirregabiria 1992-1998
All rights reserved
----------------------------------------------

Dynamics Solver is FreeWare; there is no charge for using it and it may
be distributed freely so long as the files are  kept together and
unaltered. You may neither sell nor profit from distribution of Dynamics
Solver  in any way without the written permission of the Author.

We hope you will mention Dynamics Solver when results obtained by means
of this program are published in any form. You should treat Dynamics
Solver in this respect as any other reference you use in your work.


-------------------
Program Description
-------------------

Dynamics Solver is intended to solve initial and boundary-value problems
for continuous and discrete dynamical systems:
- single ordinary differential equations of arbitrary order, including
stiff problems,
- systems of any number of first-order ordinary differential equations,
- a rather large class of functional-differential equations and systems,
- Iterated maps and recurrences in arbitrary dimensions,
- any problem that can be written in one of the aforementioned forms.

No programming is necessary: everything can be entered in user-friendly
dialog boxes and complex graphics (and numerical) results can be easily
and quickly obtained. The program has a powerful built-in compiler that
automatically translates a large class of mathematical expressions
written in a standard format into an internal code that can be executed
very fast.  Apart from the dynamical system solution, one can compute
any quantity involving the solution and its derivatives (for one or more
values of the independent variables), the problem parameters and the
initial conditions. For example, it is possible to draw phase-space
portraits (including an optional direction field), Poincar� maps,
Liapunov exponents, cobweb diagrams, histograms and bifurcation
diagrams. The results can be projected (in perspective or not) along any
direction and particular subspaces of the phase space (or the space of
initial conditions) may be analyzed easily. 

Very different kinds of results may be obtained in different graphics
and text formats displayed in one or more windows. They can be sent to
any Windows compatible printer or plotter and advanced output formats
are available, including Encapsulated Postscript and user-defined
formats. The results can be easily collected in a file in order to
process them by means of other programs, such as Mathematica.  There are
many programs to draw geometrical figures, but most of them are not
appropriate to draw the figures that physicists often need when
preparing lectures or research papers. One would not want to have to
learn to use a very complex CAD program only to draw some figures in a
collection of exercises. Simpler programs exist, but they are not able
to draw mathematically defined curves (say a semi-cubic parabola) or to
place elements at arbitrary points (often they can only be placed at
some grid points), or to include data points. Dynamics Solver can be
used to draw segments, arcs of circles and ellipses, arrows, arbitrary
parametric curves in two and three dimensions, a large class of
fractals, and points and lines from external data files (which can be
generated by Dynamics Solver itself or any other program). The main goal
is to have completely correct figures (not only artistic approximations)
in a device-independent format that can be translated to standard
formats (HPGL or Postscript, for instance) that, in turn, can be easily
combined with output files from powerful text processors and formatters
(we have TeX in mind, of course).

Each problem can be saved to and retrieved from a disk file. This
"problem file" can also be edited and used as a template for related
problems. One can extend the program by providing more integration
methods or additional mathematical functions. A complete,
context-sensitive, cross-referenced help system is available and each
error message and dialog box has a help button that can be used to get
the corresponding information. Furthermore, the program is highly
configurable to better suit your needs and tastes.


---------------------------
Who May Use Dynamics Solver
---------------------------

Dynamics Solver is both a powerful professional tool to be used by
physicists, mathematicians and engineers in their everyday work, and
also a pedagogical tool to help learning and teaching about differential
equations, continuous and discrete nonlinear dynamical systems,
deterministic chaos, etc. Topics that were traditionally omitted in
introductory courses because of their mathematical complexity can now be
analyzed easily. Even when exact solutions are known, it is often given
by means of complex mathematical expressions that are not easily
understood without explanatory graphics. Students can gain a more
intuitive comprehension of many problems by analyzing them in a
numerical laboratory, and Dynamics Solver is flexible enough to be an
effective numerical laboratory in which many problems from physics and
engineering can be easily tested. Note also that many examples discussed
in books on computational physics and in papers published in journals
like American Journal of Physics, European Journal of Physics, etc. can
be analyzed, without programming, by means of Dynamics Solver. For
instance, when teaching differential equations you can use Dynamics
Solver in many different ways. Plenty of useful examples can be found in
the excellent textbook of Borelli [1991], which can also be used to
teach a full laboratory course on differential equations. 


----------------
Program Versions
----------------

There are two versions of Dynamics Solver: 

- a 16-bit edition which will run under Windows 3.1 (or compatible
environments, including Windows for Workgroups 3.1+, Windows 95, Windows
98 and Windows NT 3.5 for Intel processors). Though it may run under
Windows 3.1, it includes many interface enhancements of Windows
95/98/NT4, such as tabbed dialogs, toolbars, tooltips, status bar, spin
controls and popup menus invoked with the right mouse button.

- a 32-bit edition which will run only under Windows 95, Windows 98 and
Windows NT 4.0 and takes advantage of the enhanced possibilities of this
environment, such as:
- long file names,
- use of the registry instead of .INI files,
- bigger integers for repeated integration,
- problem files automatically added to the Documents entry of the Start
  menu,
- context help for dialog controls,
- creation of new problem files from the New menu entry that opens when
  right-clicking in an Explorer or My PC folder (or even on the Desktop),
- any problem that was open when the system is shut down will be
  reopened in the next Windows session,
- more memory,
- QuickView compatibility,
- and more...


------
Author
------

Juan M. Aguirregabiria 
Department of Theoretical Physics
The University of the Basque Country
P.O. Box 644, 48080 Bilbao (Spain) 
E-mail: wtpagagj@lg.ehu.es 
WWW: http://tp.lc.ehu.es/jma.html
