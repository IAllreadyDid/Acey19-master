LOGTIME 2.0c for Windows 95 and 3.1
Copyright (c) 1998 by Christopher S L Heng. All rights reserved.
----------------------------------------------------------------

$Id: readme.txt 2.15 1998/07/11 07:33:59 chris Exp $


**UPGRADERS**
Please read one of the following sections of this file before
installing (depending on which version you currently use):
- UPGRADING LOGTIME FROM VERSION 2.0x
- UPGRADING LOGTIME FROM VERSION 1.21 OR BELOW.



CONTENTS

1.  WHAT IS LOGTIME?
2.  WHAT'S NEW IN VERSION 2.0c?
3.  SYSTEM REQUIREMENTS
4.  PACKING LIST
5.  INSTALLING LOGTIME FOR THE FIRST TIME
6.  UPGRADING LOGTIME FROM VERSION 2.0x
7.  UPGRADING LOGTIME FROM VERSION 1.21 OR BELOW
8.  UNINSTALLING LOGTIME
9.  GETTING MORE INFORMATION ABOUT LOGTIME
10. LICENSING AND COPYRIGHT
11. CONTACTING THE AUTHOR
12. BUG REPORT CHECKLIST



1.  WHAT IS LOGTIME?

LOGTIME is a utility that assists users in tracking the amount of
time they spend and cost they incur while connected to their
Internet Service Providers ("ISP"). It is useful for people who
use ISPs that charge according to the amount of time you spend
connected to them.

LOGTIME supports a plethora of charging schemes used by ISPs and
phone companies all over the world. It has support for ISPs that
charge different rates depending on the period of the day you
connect. It has support for ISPs that give you a certain amount
of "free" connection time each month or day. It has support for
users who connect to more than one ISP.

For users who connect to their ISPs using multiple operating
systems on their PCs, the same log and configuration files that
are used by LOGTIME for Linux can be used by LOGTIME for Windows
95, and LOGTIME for Windows 3.1. Now you can connect in any
system you happen to be working in, and not have to worry that
you have forgotten to keep track of your connection time.



2.  WHAT'S NEW IN VERSION 2.0c?

Please see the file whatsnew.txt for more information on this.
A copy of this file was installed into the same directory as
the LOGTIME program when you ran SETUP.EXE.



3.  SYSTEM REQUIREMENTS

LOGTIME for Windows 95 has the following minimum system
requirements:

	Windows 95 and above
	A dialer like the Dial-Up Networking that comes with Windows 95

LOGTIME for Windows 3.1 has the following minimum system
requirements:

	Windows 3.1, 3.11, Windows for Workgroups 3.11
	A Winsock package and dialer

If you do not have the above, you probably will not need Logtime
anyway!



4.  PACKING LIST

For a list of items in this package, please see filelist.txt.
A copy of this file was installed into the same directory as
the LOGTIME program when you ran SETUP.EXE.



5.  INSTALLING LOGTIME FOR THE FIRST TIME

If you are upgrading from a previous version of LOGTIME, please
see the appropriate section on upgrading in this file. This
section is applicable only to new users of LOGTIME.

a. Run SETUP.EXE and follow the instructions given to install
LOGTIME on your computer.

b. Configuring LOGTIME. Start up LOGTIME and hit the Help button.
Read through the Getting Started and Configuring Logtime sections
of the online manual (just press the "Getting Started" button on
the button bar at the top of the window). Then configure Logtime
for your system and ISP as indicated in the manual.

e. Testing LOGTIME. You should not test until you have read the
online help. If you did not properly configure the program, do
not expect the program to yield any meaningful results. You also
need to know how to get LOGTIME to log your calls. So read the
online help! Then test run your setup of LOGTIME by making a call
into your ISP, running LOGTIME accordingly, and then checking the
results by clicking the "Current" button on the main dialog
window.

NOTE: If you want to install both the Windows 95 *and* the
Windows 3.1 versions, repeat the SETUP procedure for both
versions in their respective operating system/environment.
That is, install the Windows 95 version from Windows 95,
and the Windows 3.1 version from Windows 3.1. You may
install both versions into the same directory. The version
numbers of LOGTIME for both platforms should be identical.



6.  UPGRADING LOGTIME FROM VERSION 2.0x

If you are upgrading LOGTIME from version 2.0, 2.0a, or 2.0b,
please uninstall the older version first.

Uninstalling LOGTIME will not remove the log and configuration
files you originally installed, so if you install this new
version into that same directory, the new version of LOGTIME will
continue to use those log and configuration files.

To uninstall, see the instructions on UNINSTALLING LOGTIME
below.

Then proceed to install LOGTIME by running the SETUP program.

NOTE: If you installed both the Windows 95 *and* the
Windows 3.1 versions, please uninstall *both* versions before
continuing. You should run the uninstaller from the
respective operating system/environment for each version.

If you want to install both the Windows 95 *and* the
Windows 3.1 versions, repeat the SETUP procedure for both
versions in their respective operating system/environment.
That is, install the Windows 95 version from Windows 95,
and the Windows 3.1 version from Windows 3.1. You may
install both versions into the same directory. The version
numbers of LOGTIME for both platforms should be identical.



7.  UPGRADING LOGTIME FROM VERSION 1.21 OR BELOW

This section applies only to users who are upgrading from
LOGTIME 1.21 or earlier. If you are a new user, you need to
read the section on INSTALLING LOGTIME FOR THE FIRST TIME
instead.

a. Before upgrading, make sure that no version of LOGTIME is
currently running. If a LOGTIME window is open, close it before
upgrading. This is important because the version of SETUP.EXE
used to install LOGTIME at this time is not able to correctly
update a program that is currently running.

b. Run SETUP.EXE and follow the instructions to install LOGTIME
on your computer. You may, if you choose, install the new version
of LOGTIME over your existing version. The instructions that
follow assume that you have installed over your existing version.
Your configuration and data files will not be overwritten, and
can be converted for use by the new version of LOGTIME.

c. LOGTIME 2.0 and above does not use the same log (or data) file
as version 1.21 and below. Likewise, although the same
configuration file (logtime.ini) is used, the various options in
that file have been re-organised and renamed. This is to support
the host of new features introduced in version 2.0.

To ease the pain of upgrading, LOGTIME comes with an upgrade
utility called LTCONV.EXE for the Windows 95 version of LOGTIME
and LTCONVD.EXE for the Windows 3.1 version of LOGTIME.
LTCONV.EXE (or LTCONVD.EXE) will convert the old
log files and the old configuration files to the new format.

In the paragraphs that follow, substitute ltconvd (LTCONVD.EXE)
for ltconv (LTCONV.EXE) if you are using Windows 3.1. Reference
to ltconv only applies to the Windows 95 version of LOGTIME.

To upgrade your old configuration files, open a MS-DOS Prompt
window (Start Menu | Programs | MS-DOS Prompt). Change to the
directory where LOGTIME was installed, where your old data and
configuration files are kept as well. Then run the ltconv
utility to upgrade the files.

For example, if you installed LOGTIME to C:\LOGTIME over your old
LOGTIME files, you might do the following:

	c:
	cd \logtime
	ltconv

The upgrading utility will create two new files: logtime.log and
logtime.ini. The old log (data) file, logtime.dat, will not be
removed. The old configuration file will be saved as logtime.bki.
Both logtime.dat and logtime.bki may be removed if you do not
envisage going back to version 1.21 of LOGTIME. They are not used
by version 2.0 and upwards.

If you did not previously set the time zone in your logtime.ini
file, you should use the -t option on the ltconv command line to
add the TZ option.If you are unsure whether your old logtime.ini
file had a TZ option, assume it does not, and follow the
instructions below. Setting the time zone will ensure that the
log and ini files have the same time zone in their entries.
Otherwise your results will be inaccurate.

Find out what your time zone is, then use the following command
lines instead of the above:

	c:
	cd \logtime
	ltconv -t <time_zone_string>

where <time_zone_string> should be replaced by your time zone.
For example, if your time zone is SST-8, your ltconv command line
would be

	ltconv -t SST-8

The log file entries would then be configured according to a time
zone of SST-8 and your new logtime.ini will have an entry
TZ=SST-8 as well. The two must be in sync, or your results will
be inaccurate.

If you have no idea what a time zone is, and you never have to
adjust your clock for different seasons of the year, and you do
not have a time zone setting in your old logtime.ini, you might
be able to get away with the following command line:

	ltconv -t GMT0

The above command line makes LOGTIME think that your local time
zone is identical with the Greenwich Mean Time.

d. Read the online help and try out the new LOGTIME. You might
want to take advantage of some of the new features available with
LOGTIME. It is now able to automatically detect modem
connections. It can track your telephone charges as well as the
usual tracking of ISP charges. It supports more ISP methods of
calculating cost. And so on.

NOTE: If you want to install both the Windows 95 *and* the
Windows 3.1 versions, run SETUP for both versions in their
respective operating system/environment. That is, install
the Windows 95 version from Windows 95, and the Windows 3.1
version from Windows 3.1. You may install both versions into
the same directory. The version numbers of LOGTIME for both
platforms should be identical.



8.  UNINSTALLING LOGTIME

a. If you configured LOGTIME to automatically start up everytime
Windows 95 or 3.1 runs, simply go to the Monitor options and
uncheck the box that says "Automatically run LOGTIME everytime
Windows starts up".

b. Next, run the Uninstall program which can be found in the
Logtime group. In Windows 95, if you followed the default
installation procedure, the Uninstall option is in Start |
Programs | Logtime | Uninstall. Or you can go to the Control
Panel's Add/Remove Programs and select the Logtime entry to
uninstall. In Windows 3.1, the Uninstall icon can be found
in the Logtime program group.

c. The Uninstall program will not delete the logtime.log and the
logtime.ini files. To completely uninstall LOGTIME, remove those
files and the directory in which they reside. Remember not to
delete the log and configuration files if you are still using
LOGTIME on other platforms.



9.  GETTING MORE INFORMATION ABOUT LOGTIME

For information on how to configure and use LOGTIME, install the
package, run LOGTIME, and click the Help button.



10. LICENSING AND COPYRIGHT

Please see the file licence.txt for more information on this.
A copy of this file was installed into the same directory as
the LOGTIME program when you ran SETUP.EXE.


11. CONTACTING THE AUTHOR

If you wish to contact me about LOGTIME, you may email me on the
Internet via one of the addresses given below (please use only
one and not all or I'll wind up with two copies of your email).

If you are reporting a bug (or potential bug) in LOGTIME, please
read the next section about the information I will need to
help you. Please furnish the information even if you are
simply emailing me about some problems you face while running
or configuring LOGTIME. If in doubt, just furnish me the
information anyway. Otherwise you'll waste time because I'll
have to email you back for the information.

Internet email addresses:
	cyfheng@singnet.com.sg
	chrisheng@bigfoot.com

Home page:
	http://www.singnet.com.sg/~cyfheng/
	http://www.bigfoot.com/~chrisheng/

Please read the online manual and this file before emailing
me on anything. I get a lot of email from people who obviously
have not read the manual.

DISCLAIMER: Please note that while I generally would like to hear
from you if you are using the program, and I certainly would like
to know if you discover any bugs in the program, I am under no
obligation to fix any bugs. In fact, I make no promises about
even replying.

NOTE: If you would like to be informed about future versions of
LOGTIME, please join the Logtime Announcements mailing list.
Please complete the form found on my home page.



12. BUG REPORT CHECKLIST

Please furnish me the following information when emailing me
about bugs. In fact, it would be good if you provide the
information even if you are simply requesting new features. This
will enable me to answer your questions/problems/requests more
relevantly.

1.	The version of LOGTIME you are using, eg Version 2.0.
2.	A copy of your logtime.ini file, and if relevant a copy
	of your logtime.log.
3.	The platform (or platforms) on which you are running
	LOGTIME: ie whether Windows 95, Windows 98, Windows 3.1
	or Linux or all of the above.
4.	The dialer (Windows 95) or winsock package (Windows 3.1)
	or type of protocol (PPP or SLIP, etc) (Linux) that you
	are using, and the version number (if available).
5.	A description of the problem. Please do not email me a
	screen dump without stating what the problem is.
6.	Any other information that might be relevant.

Or you can simply complete the bug report form at my home
page listed in the section above (CONTACTING THE AUTHOR).
