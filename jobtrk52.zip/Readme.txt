
          JobTrack Work and Project Scheduling Software
                
[ A detailled operating manual, and the latest ]
[ Version of this program,  are posted at      ]
[       http://www.minuteman-systems.com/      ]

=======================================================================
! Note : This program requires that you first have the VBRUN400,      !
! 16-Bit, library installed on your system. The library is available  !
! for download at path                                                !
!                                                                     !
! http://www.simtel.net/pub/simtelnet/win3/dll/wb40016.zip            !
=======================================================================

Description
-----------
JobTrack provides an easy way to schedule people and resources, and 
to budget and track expenses. It makes the benefits of  Project 
Management Software available for the needs of offices, labs, and 
workplaces such as machine shops. 

Scheduling; via daily or monthly calendars. 

Budgeting and Resource Tracking;  Labor/headcount and fixed 
    expenditures may be assigned and tracked.

Progress Reporting ; A number of pre-formatted and 
     customized report styles are available.

While this program has comprehensive features, a primary goal 
to be easy to use. To achieve this, the basic scheduling functions 
are available as soon as you launch the program, while the more 
comprehensive functions such as budgeting can also be found when 
you need them. Seldom used and complex functions are avoided.

JobTrack reports can be generated in hardcopy as well as text- and
graphics- file formats, compatible with standard word-processor and
spreadsheet programs. This means you can easily distribute your
reports, even PERT Charts, via email to team members
and other interested parties.

JobTrack supports multiple, linked subprojects. This means you
can have any one project broken down into separate activities
("Engineering", "Sales") with links between critical "Program-Wide"
tasks. 

Installation
------------
This program will run on Windows 3.1 & 3.11, Windows 95, and up.

To install the program, run SETUP.EXE. When prompted for a 
destination directory, select any directory other than where you 
have placed these installation files.

When the program is running, select HELP and CONTENTS for 
instructions. 

If you encounter problems, see the troubleshooting tips at the 
end of this file.

Registration
------------
This is an evaluation copy of JobTrack Software. If you keep it 
and use it please send $99.95 US, for an upgrade to a registered 
version, to

MinuteMan Systems
PO Box 152
Belmont, MA 02478

NOTE - Checks drawn on a non-US bank, or issued in a non-US currency
require the additional poayment of a $20 US processing fee.

Please include your return address and telephone number or
email address.

Payment may also be made by credit card via the internet.
Please go to www.shareit.com and register program 102962.

For further information or assistance contact us at

Internet : info@minuteman-systems.com
WWW Site : http://www.minuteman-systems.com/ 
Telephone : (617) 489-5639

=======================================================================

                      TroubleShooting Tips

Usually the JobTrack Program installs and runs properly. 
In the event that a problem is encountered, following are 
some things to check for or change;

1.) Make sure you have the "full" version of the program. 
It is about 2.3MB (compressed). Some archives redistribute 
the program with certain libraries removed. Those cases are 
easily identifiable because the file size is then well under 
500KB. If you do have the small version, you can obtain the 
missing libraries from the archive, but better still it is
recommended that you download the entire copy of the latest 
version of the program from our website at; 

http://www.minuteman-systems.com/

Assuming you have the full program;

2.) Windows requires that all other programs be shut off prior 
to installing a new program. If not, the installation may not 
complete, and you will get an error message indicating a 
conflict with the application. 

In Windows '95, if you simultaneously press CTRL, ALT, and 
DEL a menu will come up showing you which programs are 
still running, and it allow you to select ones to shut off. 

In Windows 3.1 or 3.11, clicking the box in the upper left
corner of the Program Manager window will bring up a list of
active programs.

A common problem is if you ran a browser such as Netscape 
prior to doing the installation. Even if Netscape were shut 
off, it may have left other processes running. It is 
recommended to shut off Netscape, reboot your system, and
install JobTrack before doing anything else.

If you are using the version of this program for Windows 3.x, 
Windows itself may erroneously report that it has a conflict 
with some program competing for use of COMDLG16.OCX or some 
Filename.DLL. However, in that one instance it still allows 
you to complete the installation (by clicking IGNORE) and 
the program will install and run. 

3.) When installing the program, it should be installed to 
a directory different from where the installation kit has 
been placed. I.E. if you download/unzip the file to C:\JOBTRACK 
and then try to run the setup program and install the program 
in the default of C:\TRACK, there will probably be an error. 
Usually the installation will not complete but it is possible
that the program may fully install and then mis-operate somehow. 

4.) There have been cases reported of pc's running resource-intensive
applications, such as Networking software or Games, interfering 
with either the installation or the operation of the program. 
Often this has been remedied by rebooting the system, and 
doing the installation before starting up any other applications. 
Also, using a CD-ROM drive to play music while running the 
installation program or while running JobTrack could 
conceivably cause a problem. 

5.) If your machine has regional settings other than English 
(US-standard) there is a remote possibility of a problem. The 
program has been tested with many common regional settings and 
works fine. If by chance your machine is set for something other 
than English (US-standard), you might try configuring it as 
English (US-standard), rebooting, and seeing if the program works. 
(If that happens, please report your original regional setting 
to us and we will investigate modifying the program to eliminate
the problem.) 

6.) With the program running, some screens may not display properly. 
The most common problem is that thin lines or borders of objects 
disappear. This can usually be corrected by changing the Color Palette 
settings on your PC. Use the Windows Control Panel, and go to the 
Display settings. Most PCs support choices such as "256 Colors", 
"High Color (16-Bit)", and "True Color (16- and 32-bit)". Usually 
most if not all the Setting choices will result in proper operation.
The program also runs best when using display settings for "Small Fonts".

