JADE 2 Notes (README.TXT)
=====================================
Jade Version: 2.01
=====================================

This readme has the following sections:

* Introduction
* Installation
* Documentation
* Extra Information
* Further Distribution
* Revision History
* Contacting Ptolemy Services


INTRODUCTION
=====================================

What is Jade?
-------------------------------------

Jade 2 from Ptolemy Services is a software package for Microsoft Windows 95 and Windows 3.1x that turns your computer into a low-cost data logger for monitoring environmental noise. Jade 2 captures data direct from the CONDITIONED AC output of a sound level meter using a standard PC sound card (SoundBlaster 16 compatible or above). You can then analyze the results on a computer. 

First use Jade's capture facilities to record sound levels, mark noise events and note observations. Jade lets you see the data as it is captured both in a chart and in a large "sound level meter" type display. You can also view the running statistics during data capture (Leq, Lpk and up to five Lns of your choice).

Next use Jade's viewing facilities to view the resulting noise traces and observations. Zoom in and out of the charts to view the data at different levels of detail, edit your observations, and print both charts and notes. You can also view the statistics. 

Finally, use Jade's export facilities to export both charts and notes (for example for inclusion in a report). You can also export the data to a spreadsheet application and export the statistics as a text file. 

System Requirements
-------------------------------------

COMPUTER HARDWARE: IBM AT or compatible with a 486 DX 33 or above processor (a Pentium processor or higher is recommended). No co-processor is required. At least 8Mb RAM and at least 10Mb free hard disk space. 640 x 480 VGA or better display (800 x 600 SVGA preferred). A mouse or equivalent pointing device is essential when viewing data (keyboard alternatives provided during data capture). A printer of at least the same resolution as the screen, and capable of printing graphics under Microsoft Windows.

SOUND CARD: SoundBlaster 16, SoundBlaster AWE, or later compatible with 16-bit stereo recording capability. Volume control utility is essential, preferably software controllable using Windows Sound System (Windows 3.1x) or Windows 95.

SOUND LEVEL METER: Any sound level meter with a conditioned AC output (that is, the AC signal is drawn after the frequency weighting has been applied).

ACOUSTICAL CALIBRATOR: Single or dual level acoustical calibrator.

SOFTWARE: Microsoft Windows 95 or Windows 3.1 or later in enhanced mode (Windows 95 preferred).

CABLE: A cable is needed to connect your meter to the sound card. An ordinary audio cable can be used if the meter produces 0.7V RMS FS or less. Above this level, a cable with suitable attenuation must be used to avoid damaging the sound card. Ptolemy Services sells a range of suitable cables. Alternatively, you can make your own cable. Details on making your own cable are given in the "Getting Started" guide supplied with the software.

Program Status 
-------------------------------------
Jade is distributed as shareware and is fully functioning. You can try out Jade for 30 days, after which you must register your copy of Jade. When you register, you will be supplied with a registration key which will allow you to continue using Jade.

The registration key allows you to run Jade on a particular computer. If you wish to run Jade on more than one computer, you must order a registration key for each computer. If you replace your computer at a later date, please contact Ptolemy Services for help with transferring the registration key to the new computer.

The current price for Jade is US$395. Quantity discounts and educational discounts (for educational establishments and their members) are available. Ptolemy Services offers a range of payment methods in both US dollars and GB pounds: credit card (VISA, MasterCard, Eurocard, JCB and VISA Delta.), check, Eurocheque (GB pounds only), bank draft and wire/telegraphic/telex transfer. Payment in GP pounds is at the current monthly exchange rate used by UK Customs and Excise. Please email Ptolemy Services for the current rate at rates@ptolserv.com (please give your email a subject of "Exchange Rate" and an empty body). You will receive an automated reply quoting the current rate. Alternatively, fax Ptolemy Services on +44 (0) 1962 852644.

A registration utility is included in the software to make registering Jade quick and easy. The registration process lets you request quantity discounts and/or an educational discount (for educational establishments and their members). The registration process also asks you for your payment details and lets you request a proforma invoice if necessary.

Full details of how to register Jade are given in the on-line help.


INSTALLATION
=====================================

Before Installation
-------------------------------------

Before you install Jade, you may need to disable any anti-virus software as some anti-virus software can interfere with installation programs and so prevent Jade from installing.

Installation
-------------------------------------

To install Jade on Microsoft Windows 95:

1) Unzip the Jade archive file into a temporary directory.

2) Make sure that there are no other applications running.

3) Choose the Start button on the Task Bar and choose Run... from the pop-up menu.

4) Type: 

        c:\temp\setup

where c:\temp should be replaced by the location of the contents of the unzipped archive file.

5) Follow the instructions and prompts during the setup process. In particular, you will be asked to confirm your acceptance of the license terms and for a user and organization name.


To install Jade on Microsoft Windows 3.1x:

1) Unzip the Jade archive file into a temporary directory.

2) Make sure that you are running Windows in 386 enhanced mode (usually the default on 386 or better machines)

3) Make sure that there are no other applications running (note that this includes applications launched from the Startup group)

4) In Program Manager, select File|Run...

5) Type: 

        c:\temp\setup

where c:\temp should be replaced by the location of the downloaded archive file.

6) Follow the instructions and prompts during the setup process. In particular, you will be asked to confirm your acceptance of the license terms and for a user and organization name.

Making an Installation Disk Set
-------------------------------------

If you want to install Jade on another computer (e.g. a portable), you may need to make a set of installation disks first. To create a set of installation disks:

1) Unzip the Jade archive file into a temporary directory.

2) Copy the setup.exe file onto floppy disk 1.

3) Copy the setup.w02 file onto floppy disk 2.

To install from the floppy disks, insert the first disk in the disk drive and then follow the installation instructions from step 2 above. Remember to type the following command line when prompted:

        a:\setup


DOCUMENTATION
=====================================

The following documentation is available:

* Getting Started (j2intro.pdf, Adobe Acrobat 2.1 format) - tells you how to install Jade and also provides tutorials for Jade.

* User Guide (j2user.pdf, Adobe Acrobat 2.1 format) - tells you how to use Jade.

* Advanced Topics Guide (j2topic.pdf, Adobe Acrobat 2.1 format) provides information on the various entries in the jade.ini configuration file.

You will need Adobe Acrobat Reader 2.1 or later in order to read the manuals. This is available from a number of sources, both on the Web and on CD-ROM. You can also obtain Adobe Acrobat reader from Adobe's web site at:

	http://www.adobe.com/prodindex/acrobat/readstep.html

* On-line Help - Jade is provided with comprehensive on-line help.


EXTRA INFORMATION
=====================================

Date and Time Formats
-------------------------------------
The format of dates and times, and other region-specific preferences, are determined by your Windows settings, and not by Jade. These affect the format of dates and times, the use of a 12- or 24-hour clock and the scale of the ruler in a note window in Jade Viewer. You can change your regional settings by opening the International Settings (Windows 3.1x) or Regional Settings (Windows 95) in the Control Panel. Note for Windows 95 users: Remember to check the contents of all the property pages as the settings may not be updated automatically from the language setting on the Regional Settings Properties property page.

Tab Stops
-------------------------------------
Measurement note windows have default tab stops every 2cm and these are saved as part of the note. If you change the tab stops for a note, under certain circumstances you may lose tab formatting if you remove some of the default tabs. To avoid any loss of tab formatting, in any one paragraph, you should do one of the following:

* Leave all the default tabs unchanged (that is, at 2cm intervals) and use these.

* Set up your own tab stops, making sure that no tab stops are at multiples of 2cm.

Printing Charts
-------------------------------------
When you print charts in Jade, you will be warned if the number of pages generated for printing is ten or more. If you wish to change this limit, you need to add the following line (or edit the line if it already exists) to the [Options] section of the jade.ini file:

	Warn Print Pages=<page-limit>

where <page-limit> is the number of pages at which you wish to be warned about a "large" printout. The minimum value is 2. For example:

	Warn Print Pages=100

sets the limit to 100 pages.


FURTHER DISTRIBUTION
=====================================

You are encouraged to distribute unmodified copies of Jade (subject to you complying with all the relevant terms in the vendor.txt file), as follows:

* By creating installation disks (see above) for friends and colleagues.

* By distributing the complete, unmodified archive zip file for distribution on the Internet, bulletin boards, CD-ROM and other electronic distribution methods.

The above distribution methods are permitted, essentially subject to the condition that you do not make a charge for the distribution (other than a reasonable charge to cover the media and related costs). See the vendor.txt file for details.

If you are an acoustics professional, or a company involved in the distribution of acoustics equipment, and wish to distribute Jade commercially, please contact Ptolemy Services at:

Fax:   	+44 (0) 1962 852644
Email: 	sales@ptolserv.com


REVISION HISTORY
=====================================

VERSION 2.01
Minor updates to manuals. Added User Guide to product. 

VERSION 2.00
First Release Version. 


CONTACTING PTOLEMY HISTORY
=====================================

You can contact Ptolemy Services on:

Email:		sales@ptolserv.com
WWW:		http://www.ptolserv.com
Phone:		+44 (0) 1962 852644                                      
Fax:	      	+44 (0) 1962 852644                                      

Technical Support
-------------------------------------

Free technical support is available from:

* The documentation. Before contacting Ptolemy Services, please make sure that you have read the relevant help topics or sections of the manuals.

* On the Internet at http://www.ptolserv.com/support.htm.

* By emailing Ptolemy Services at support@ptolserv.com

* By fax to Ptolemy Services on +44 (0) 1962 852644

Note that if you are using an unregistered copy of Jade, free technical support is limited to 30 days from the date of installation.


-------------------------------------

THE JADE PRODUCT IS PROTECTED BY COPYRIGHT AND IS SUPPLIED ON THE CONDITION THAT THE USER AGREES TO THE TERMS OF THE LICENSE. IF YOU DO NOT ACCEPT THE TERMS OF THE LICENSE, YOU MUST IMMEDIATELY CEASE USING THE PRODUCT. IF YOU HAVE PAID FOR THE PRODUCT YOU SHOULD RETURN IT IN A RESALEABLE CONDITION WITHIN 7 DAYS OF PURCHASE TO YOUR DISTRIBUTOR FOR A REFUND.
    
Jade Copyright (C) Ptolemy Services 1995 - 1997

Acrobat(R) Reader Copyright (C) 1987-1996 Adobe Systems Incorporated. All rights reserved. Adobe and Acrobat are trademarks of Adobe Incoporated which may be registered in certain jurisdictions.

All trademarks acknowledged. 



