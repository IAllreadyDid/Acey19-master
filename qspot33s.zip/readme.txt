README.TXT
==========
For Quick Spot 3.0. and higher. READ THIS FIRST BEFORE INSTALLING
THE SOFTWARE !

PROGRAM OVERVIEW
----------------
QuickSpot is a utility that compares 2 text-files and highlights the 
differences found between them. It reports the differences on a line 
by line basis and highlights the lines that are not in synch. 
Discrepancies can be viewed or printed or saved to a file.

In QuickSpot, you can set unique comparison-criteria that find the 
needle in the haystack! You can compare specific lines or all lines, 
narrow down the comparison across specific positions per line, and 
filter out source-code comments. You can also skip a number of lines 
repeatedly, or compare different ranges in the files.

New with version 3: Compare any 2 directory-trees.
New with version 3.3: Run in batch-mode. See QuickSpot Help for details.

File- and Directory-editing features allow a quick fix of the 
discrepancies found by QuickSpot. In addition, there is a find/replace 
option and support for copying/merging text between the 2 files; files 
can also be saved and printed. In the directory-section, files can be 
deleted, renamed, moved or copied.

The graphical display has been improved substantially. It now includes 
a toolbar, and there are various options how to view the 2 files and 
the discrepancies. All color settings can be changed at any time.

QuickSpot is still a 16-bit application and therefore runs smoothly on 
all current Windows versions; Windows 3.1, Windows 95, Windows NT 3.5 
and 4.

The demo you downloaded is a fully functional version, except that it
only compares maximum 10 lines of 2 files opened for comparison.

INSTALLATION
------------
IMPORTANT: This program is written in Visual Basic. There should be no 
VB-applications running when you install this program. Best, close
all applications before you install the program.

To install, just start QSPOTnn.EXE (nn = version no.) and it will install 
the application for you. If you have downloaded the .ZIP file, start WinZip
and click INSTALL.

A few troubleshooting tips in case you have any problems with the 
installation:

 -- Do not use long directory-names, but the classical 8.3 names.
    QuickSpot is backward compatible all the way to Windows 3.1

 -- If the message "stkit416.dll not found" pops up during install,
    you can safely ignore that.

 -- Close down all running applications.

 -- Come to worst, reboot the PC, then run setup as the first thing
    when it comes back up.

STATUS
------
This is a limited-feature demo version.

DISTRIBUTION 
------------
Freely distributable; feel free to pass this program on to 
your friends.

CONTACT
-------
Contact the author:  matt@famtech.ca if you need any assistance or to
order the full version for only $ 29.

You can also order the full version on the web:
http://www.famtech.ca/noframes/quicks.html, then follow links.

