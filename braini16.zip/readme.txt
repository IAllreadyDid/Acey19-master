Brainiac! Neuroanatomy Atlas
**Demo Version 1.6**
----------------------------

To install the Brainiac Demo, run setup.exe and follow the on-screen
instructions.

This demo is contains several fully functioning screens from
Brainiac. The full retail version of Brainiac contains over 50 brain
sections including nearly 30 stained brainstem sections.

This program is compatible with Microsoft Windows 3.1/95/98/2000 PRO/ME/NT

If the quality of the pictures in the program is poor, you are probably
not running Windows in 256-color mode. A VGA adapter capable of
displaying at a minimum 640x480 resolution in 256 colors is required to
run Brainiac! Please check your video adapter manual or call your video
adapter manufacturer for video drivers and instructions on how to
install them.

Instructions describing how to use the program are provided on-line by
pressing the Help buttons on the screen.

To uninstall this demo, simply delete the /brainiac directory. No
changes are made in the Windows Registry.

Medical Multimedia Systems
Technical support: 856-321-9026
Hours: 9am-5pm Eastern time
WWW: http://www.webcom.com/medmult
E-Mail: Medmult@webcom.com
