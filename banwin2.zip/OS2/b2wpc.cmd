/* Banner/2 Installer! 21-8-97 */

Call rxfuncadd sysloadfuncs, rexxutil, sysloadfuncs
Call sysloadfuncs

say ""
say "__________________________________________"
say " Banner/2 v2.0 (c) 1997 Stellar-X Ptd Ltd"
say " Creating a Banner/2 desktop object..."
say "__________________________________________"

Exepath = Directory()'\Ban2.exe'
Hlppath = Directory()'\Ban2.inf'

Call SysCreateObject "WPFolder", "Banner/2", "<WP_DESKTOP>", "OBJECTID=<WP_Ban2>", "Update"
Call SysCreateObject "WPProgram", "Create banner", "<WP_Ban2>", "EXENAME="Exepath, "Update"
Call SysCreateObject "WPProgram", "Assistance", "<WP_Ban2>", "EXENAME=VIEW.EXE;PARAMETERS="Hlppath, "Update"

say "______________________________________________________________"
say "Complete. Please enjoy Banner/2 as much as we did creating it!"
say "______________________________________________________________"
pause
