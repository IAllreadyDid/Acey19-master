
------------------------------------------------------------

 *****     **    *    *  *    *  ******  *****        *   ****
 *    *   *  *   **   *  **   *  *       *    *      *   *    *
 *    *  *    *  * *  *  * *  *  *       *    *     *        *
 *****   ******  *  * *  *  * *  ***     *****     *       *
 *    *  *    *  *   **  *   **  *       *    *   *      *
 *****   *    *  *    *  *    *  ******  *    *  *       ******

 UNIX-style Banner command for OS/2, DOS, and Windows
 Version 2.0

 (C) 1995-97 Stellar-X Pty Ltd, August 13, 1995

------------------------------------------------------------

Description
___________

Banner/2 is a UNIX-style Banner command for OS/2.  It
prints the words input as arguments in big text letters
using asterisks.  Each expression is printed on one line.
Expressions longer than 9 characters are split.
It is fully-operational.

Each argument must be delimited in quotes (") if they
contain whitespaces (" "), circumflexes (^), or
relations; (<) and (>), or (|).  A quote can be printed
within the argument using \".  You may need to print a
\ using '\\'.

In this release, Banner/2 now supports European, Greek,
and some block characters. It has been revamped into
an OS/2 PM version. See BAN2.INF in the OS2
subdirectory for information specific to this version.

Command-line OS/2 and DOS versions are also provided,
as well as a Windows 3.1 port. Look in the CMDLINE
subdirectory.

Banner/2 is intended to be used by anyone who wants
to liven up any text. Some examples are -

  - A large email signature
  - Email messages; why SHOUT when you can SCREAM?
  - Designing printer/fax cover pages
  - Text file layout, like title pages
  - Web page text (by enclosing the banner in <PRE> .. </PRE> tags)
  - Incorporating banners into software
  - and generally, impressing your friends and family.

Stellar-X sincerely hopes that somebody benefits from 
Banner/2.

------------------------------------------------------------

Installation
____________

Place the executables of the version you desire,
into your path. For example copy to

  C:\DOS      - For the DOS version (BANDOS.EXE)
  C:\WINDOWS  - For the Windows version (BANWIN.EXE)
  x:\OS2\APPS - For the OS/2 version (BANNER.EXE)

The information files can be safely deleted (but not
when distributing; see License agreement section).

In Windows 3.1/95/NT, you may create a shortcut/icon
to WINBAN.EXE.

For the OS/2 PM version, see Ban2.inf for more specific
instructions.

------------------------------------------------------------

Usage
_____

Banner operates by using phrases, passed in as arguments.
To use Banner/2 for Windows, you will need to enter
the phrases as arguments to the shortcut/icon.
Each phrase appears on one line.

Some examples are -

  Banner "Hello, world!"	- Prints a 'Hello, world!' banner on one line
  Banner Hello, world!		- Prints a 'Hello, world!' banner on separate lines

To see the output one screen at a time, use 'more' -

  Banner This is a very long phrase | more

To redirect the output to a printer (or port),

  Banner Redirected printer output > prn

To redirect the output to the file 'outfile.txt',

  Banner Redirected text output > outfile.txt

------------------------------------------------------------

Limitations
___________


\ and " cannot be printed consecutively since they are interpreted
as a ". Use \" for a quote, and \\ for a backslash.

The <CTRL><J> character within an phrase stops ALL
characters following it from being read.

The default command shell resolution is the only one
supported (80 characters across).  Smaller resolutions may
result in distorted output.

The DOS and Windows versions are mere
ports of the OS/2 version. They may exhibit
problems; European characters don't seem to be detected,
and the Windows version uses a different font,
so some characters appear incorrect. These problems
will be solved in a future version.

------------------------------------------------------------

License agreement
_________________

Stellar-X Pty Ltd releases Banner/2 as FREEWARE,
for all personal and commercial use.
Technical support is provided.

The original archive must be distributed intact.
This includes all text files and versions.
The archive may be freely distributed electronically,
or on compilation CD-ROMs.

However, I do not
guarantee the software's reliability.  Any damage or loss
incurred as a result of this software is the
responsibility of Stellar-X.

For registration purposes, please take the time to contact
Stellar-X and inform them of how you are using Banner/2.
Include your name and contact details.
A postcard would be ideal.

------------------------------------------------------------

Contacting Stellar-X
____________________

You are encouraged to contact Stellar-X for registration,
further assistance, or any other reason.
For all software titles, visit the Stellar-X website.

Postal address:

Director
Stellar-X Pty Ltd
6 Bolingbroke Avenue
DEVON PARK SA 5008
AUSTRALIA

Email : antonino@usa.net
WWW   : http://members.tripod.com/~antonino
