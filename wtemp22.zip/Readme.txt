                             WTemp22

           Written&Copyright 1998,1999 by S.T.Dowkontt

About:
   WTemp2 is a simple temperature measurement program for motherboard
 with Winbond W83781D and full compatible control chips.  WTemp2 check
 frequentaly temperatures (processor and system). The current
 temperatures are printed, and last 255 measurements are drawed as
 chart. The chart could be printed on default printer.
   WTemp2 was written and tested with Win95, but should work with 
 Win3.x and Win98 too.
   WTemp2 communicate with W83781D directly across chip registers, and
 don't need to work any software driver from motherboard manufacturer. 
 WTemp2 was tested with Epox MVP3C-M motherboards.

OS:
   WTemp2 will work under MS Windows 3.x, 95 and 98. Becouse WTemp2 
 need direct access to ports, it will not work under MS Windows NT.

To Install:
 Unzip wtemp2.zip archive.

To Use:
 Right click on wtemp22.exe file in your filemanager.

Status:
 Freeware. 

Distribution:
 Freely distributable, but with all copyrights retained.

Warranty:
 This program have not any warranty.

The Author:
 Email: szdowk@ipbm.simr.pw.edu.pl