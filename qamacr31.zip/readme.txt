 Readme.txt for Question  &  Answer Numbering Macros for Word Perfect 6.1

     ************* This is Freeware! *************

The four macros are, question.wcm, qanswer.wcm, ques#off.wcm, quest#on.wcm.

Unzip and install the macros into the following directory,
C:\office\wpwin\macros\. If this is not the directory your macros are located, please put
them in that directory.

This set of four (4) macros for Word Perfect 6.1 is freeware.  One will insert a hard
break, tab over, insert a Q. and number  then tab over again, each  time the hotkey, 
(e.g. Q+Ctrl)  assigned are pressed. The other inserts a hard break, tabs over ,
 types in an  A.  then tabs over again  when the assigned hotkeys, (e.g. A+Ctrl) are pressed.
 
Two of the macros are editable, allowing for insertion at the point you may need or
required typing or so both can count.  
The other two macros turn the functioning macros on and off or can be used 
to reset the number count. Only qanswer.wcm & question.wcm can be edited. 
 
The file named, 'qainstal.wpd' can be added to your Word Perfect \wpdoc directory. 
This file contains one page of instructions to be printed for aid during installation.

If you should need help with installation that IS NOT solvable by referring to the 
'qainstal.wpd' visit our website at http://ebooks.webjump.com

Please feel free to contact the author, Howard Thompson by e-mail at 
write@foothills.net or software_revue@email.com

Visit Cyber Holler at http://ebooks.webjump.com
And The Software Revue at http://members.xoom.com/wareshouse/index.htm