Program    : Eye Spy
Programmer : Jason Wylie
Contact    : www.eye0.com

To install unzip the eyespy.zip file and run the setup executable
file. All files be be installed and icons will be installed into the
program manager.

--------------------------------------------

Want to protect your children?  Cut down employee surfing time?  This
program could be what you're looking for.

Eye Spy is designed to be more effective than any other internet
screening technology that currently exists.  Besides keeping stray
surfers from viewing unwanted or undesirable web content, it will also
limits the liabilities that could result from employees, clients or even
children surfing the net.

Limit access to web sites by using the site URL.  With this feature you
can block known pornography, gambling, auction, advertising or otherwise
unwanted sites from being viewed.

Limit access to web sites by identifying the context in which words are
used.  Many times sites are not known but will generally contain text
describing its contents.  With the "Fuzzy" text scanning, sites can be
identified and blocked by the text they use.

Block port usage.  Many "malicious programs" and games use obscure ports to do their data transfers.  This feature allows you to allocate which ports are allowed to be used by programs.

Choose any or all of: (a) the ability to immediatly kill any processes
or browsers that "break the rules" by surfing to specified sites or
using marked ports, (b) show an alternative web page, (c) display a very
attention grabbing warning message or (d) simply log the event.

Works with a direct connection or a connection via a proxy server.

The Completed product will also:

Contain multi-level security for the program so that screening features
cannot be easily disengaged.

Protect personal files from being tampered with while in Windows.

Auto-update, which will inform you and upgrade your software to address
new malicious methods to access your computer or disable the program.

Extended functionality for Windows NT/2000.
