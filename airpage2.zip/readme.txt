AirSOURCE Pro Evaluation Copy

airpage2.exe is a self installing program.  The defualt 
program directory is \airpro

To install the program in Windows 3.x
	1. In the program manager select "File" and then select "Run"
        2. Type the directory name that you downloaded airpage2.exe into
		followed by airpage2.exe (i.e. c:\download\airpage2.exe)
	3. Click "OK"

To install the program in Windows 95 / NT
	1. From the "Start" button select "Run"
        2. Type the directory name that you downloaded airpage2.exe into
		followed by airpage2.exe (i.e. c:\download\airpage2.exe)
	3. Click "OK"

This is program is shareware, and will work for 30 days from the date of 
installation.

AIRSOURCE PRO is a full featured wireless messaging program
to send messages to alphanumeric pagers.  Over 100,000 copies
sold world-wide.

In case of problems please contact:
	Tony Pappas at Silverlake Communications.
		Phone Number - (818) 224-5650
		e-mail - tony@silverlake2000.com

