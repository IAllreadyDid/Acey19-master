			PDF Plain Text Extractor(p2t) V2.3
Introduction:
	p2t is a tool extract plain text from pdf file directly, it supports single file, wildcards and can also walk through folders recursively. It's a green software, you do not need to install&uninstall it. The trial version can only process 5 pdf files per time, It can not process files bigger than 100k. If you want to get rid of these restriction, please contact sales@retsinasoftware.com or buy it online http://pdf.retsinasoftware.com

Usage: p2t [-vt] <pdf file> [output file]
           -v:   Output the detail processing information.
           -t:   Output how much time the processing used.
   <pdf file>:   Can be a specific pdf file, also can be a
                 folder or a set of files(wildcards were
                 supported)
[output file]:   where the text should be generated to, when
                 the <pdf file> is a folder or a set of files
                 this should be a folder, not a file
                 if you omit this parameter p2t will generate
                 a same name file in the same folder, but the
                 extension name is ".txt"

      Example:   p2t c:\test\test.pdf c:\test\text.txt
                 p2t c:\test\test.pdf
                 p2t c:\test\test*.pdf
                 p2t -vt c:\test\tes??.pdf c:\text
                 p2t -v c:\test c:\text

Notes: -If you want to process the pdf files in current folder, you need use
        "p2t .\*.pdf"   "p2t *.pdf" doesn't work.
       -Current version doesn't support encrypted pdf files

System Requirement:

	Windows95/98/NT/2000/ME/XP

Email support : 

	supports@retsinasoftware.com

Website : 

	http://pdf.retsinasoftware.com


-------- History -----------------------------------------

// History - Purged changes prior to v2.0

V2.3 Bugs Fixes
        -Add LZWDecode support for PDF 1.2
        -Fix octal numbers in text can't translated properly

V2.2 Bugs Fixes
        -Add batch files process functionality
        -Fix bug when deal with nested dictionary
	-Other minor fixes

V2.1 Bugs Fixes
        -Fix buffer overflow when deal with huge file
        -Other minor fixes
       
