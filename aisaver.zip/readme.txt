The Aesthetic I Screen Saver displays your images and text in a number
of different rippel/wave effects.

Program status : Freeware.

Distribution status : freely.

Setup :


INSTALLATION INSTRUCTIONS FOR  Aesthetic I screen Saver.

Windows 3.1 and Windows for Workgroups 3.11

  1  Insert diskette in drive A:
  2  In Program Manager click Run from the File menu
  3  Type A:\SETUP and press Enter

Windows 95,98,NT

  1  Insert diskette in drive A:
  2  Click Start
  3  Click Run
  4  Type A:\SETUP and click OK

To uninstall this screen saver do the following:

  1  Ensure that it is not the currently selected
     screen saver in Windows.
  2  Delete the file AWPSAVER.SCR,AWPSAVER.INI and Default.bmp files from 
     the C:\WINDOWS directory.
 

If you have any difficulty installing this software or
if you experience problems after installation, please
Email me at aesthetic.I@virgin.net

From aesthetic I web page www.aesthetic.org.uk            

You use this saver at your own risk, Aled evans cannot be held 
responsible for any losses, either direct  or indirect, of any 
party making use of this saver. 






