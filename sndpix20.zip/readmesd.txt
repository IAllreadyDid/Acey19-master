GALTWARE: SOUNDPIX v2.0
README & SOFTWARE LICENSE AGREEMENT
 - SHAREWARE EDITION
=========================

Registration: 
-------------
There are 2 different registration options.
The first is for $29, which includes the
full version of SoundPix with no 
shareware notices. You also get our Full
Motion video screen saver CD-ROM with 600MB
of incredible video clips. You also get our 
ScreenPix Bundle which features 5 other
screen savers, including the animated Venice, 
LogoSaver, ScreenPix, WorldSaver, and QuoteSaver.

The second option is the MEGA-CD for $39. The
MEGA-CD includes all the above, plus 375 color
pictures on CD, 11 additional screen savers 
(including Jurassic, Fish, Balloons, Space, and
more), 14 more great utilities (including Video 
Launch Pad, SlideShow Pro, AlarmMaster, and 
DialerPro) and 6 challenging games (incl. Vegas 
Poker and Blackjack and Hang-Em).
You get the entire library of GALT products --
39 programs in all, plus all the video clips and
photos. These are the full, registered versions.
An incredible value.

DISCOUNT: Corporate site licenses are also available
for up to 1000 users for only $399. Please call us.

TO REGISTER---
Compuserve members can register via SWREG using
the ID#7591 for option #1 and ID#9291 for option
#2.
You can also register online at our web site:
http://www.galttech.com
You can call us directly at (408)730-2467
or (800)580-0742 (orders only at this #)
You can fax us directly at (408)730-2467
You can e-mail orders to: order@galttech.com
You can mail orders to:
Galt Technology
14510 Big Basin Way, Suite #195
Saratoga, CA  95070


Installation:
---------------
To install SOUNDPIX, unzip the 
file you downloaded. Then run the 
SETUP.EXE program. Follow the on-screen 
prompts. This will load the program 
onto your system.


Description:
------------
SoundPix is a screen saver that will display
any graphics files that you choose (BMP/JPG/TIF/
PCX), along with your favorite sound files
(MIDI and WAV). Customize it to show just the 
pictures and sounds you want. Choose the duration 
that the pictures appear for. Decide if they 
should play in order or randomly, full screen
or normal size. Includes over 100 transition
effect. Also works great as a slide show 
program. Set it up and it will play through 
your list of pictures continuously. JPG files 
will take slightly longer to load since they
have to be decompressed.


Configuring Screen Saver:
==========================
(Windows 3.1)
To use the screen saver, double-click 
CONTROL PANEL, usually in the MAIN group 
on your desktop. When CONTROL PANEL opens, 
double-click on DESKTOP to go into the 
desktop configuration screen. About halfway 
down the window, select the Screen Saver Name 
drop-down box. You should find SOUNDPIX in the 
list. Select it. Now click on the SETUP button. 
In the screen saver setup, you can adjust the
settings to your preferences. Select the 
Main Picture List button; then you can select 
any graphic file on your hard drive, and see it in
the Thumbnail Window. Click 'Add Picture' near the 
bottom to add the picture to your playlist. The playlist 
will display the listed pictures when the screen
saver kicks in. Click 'Setup Complete' when
you are finished. That's it. Click EXIT and try 
the TEST button.

(Windows 95)
Right-click the desktop to bring up the 
display panel, or click the START button and
choose Settings/Control Panel; from there you 
can choose DISPLAY. With the Display Panel open,
click on the Screen Saver Tab. Select SOUNDPIX 
from the drop down list of screen savers, and click
Settings to setup. and Preview to test it.


Removing SoundPix:
To remove ScreenPix from your system,
delete the file SOUNDPX.SCR from your
\WINDOWS directory. 
Also, delete the directory you chose to install 
to (default C:\GALTWARE -- README & ORDER files
are stored here).


License:
-----------
BY USING THIS SOFTWARE, YOU AGREE TO THE
FOLLOWING TERMS AND CONDITIONS:

This version of SoundPix is shareware. 
You are granted a license to use SoundPix 
for a period of up to 30 days. After
that time, you are required to purchase the
product(s) through registration or else 
discontinue its use.

You are allowed to make copies of this 
software and distribute it to your friends 
and co-workers, on electronic bulletin
boards, over networks, and so on, as long 
as the product is not distributed for
profit (handling fees up to $5.00 ok). 
If you distribute this software, you agree 
to distribute this installation executable 
which contains the associated files together 
as a group. You are not allowed to bundle 
this software with other products without 
prior written permission from Galt Technology.

Ownership of software:
As licensee, you own the media upon which 
the software is recorded or distributed and 
are entitled to use the software, but Galt 
Technology retains title and ownership of 
the original software and all subsequent copies. 
This license is not a sale of the software or 
any copy. You are not allowed to make any 
modifications to, or to create derivative 
works from any of the files that are used 
in this software. This includes all the 
executable, help, installation, and readme 
files, as well as video files.

LIMITED WARRANTY:
THE SOFTWARE HEREIN ARE 
PROVIDED "AS IS" WITHOUT 
WARRANTY OF ANY KIND, EITHER 
EXPRESSED OR IMPLIED, BUT 
NOT LIMITED TO, THE IMPLIED 
WARRANTIES OF MERCHANTABILITY
AND FITNESS FOR A PARTICULAR 
PURPOSE. THE USER MUST ASSUME
THE ENTIRE RISK AS TO THE 
QUALITY AND PERFORMANCE OF 
THE SOFTWARE. SHOULD THE 
SOFTWARE PROVE DEFECTIVE, 
THE USER ASSUMES THE ENTIRE 
COST OF ALL NECESSARY 
SERVICING, REPAIR, OR 
CORRECTION. ANY LIABILITY 
OF THE SELLER WILL BE LIMITED 
EXCLUSIVELY TO PRODUCT 
REPLACEMENT OR REFUND OF 
PURCHASE PRICE. THIS WARRANTY 
GIVES YOU SPECIFIC LEGAL 
RIGHTS AND YOU MAY ALSO 
HAVE OTHER RIGHTS WHICH VARY 
FROM STATE TO STATE.

LIMITATION OF LIABILITY:
IN NO EVENT SHALL GALT 
TECHNOLOGY OR ANY OF IT'S 
AUTHORIZED DEALERS OR 
SUPPLIERS BE LIABLE TO YOU 
OR ANY OTHER PARTY FOR ANY 
DAMAGES WHATSOEVER (INCLUDING, 
WITHOUT LIMITATION, DAMAGES 
FOR LOSS OF BUSINESS PROFITS, 
LOSS OF SAVINGS, BUSINESS 
INTERRUPTION, LOSS OF BUSINESS 
INFORMATION, OR OTHER 
INCIDENTAL OR CONSEQUENTIAL 
DAMAGES) ARISING OUT OF THE 
USE OF OR INABILITY TO USE 
THIS SOFTWARE, EVEN IF GALT 
TECHNOLOGY HAS BEEN ADVISED 
OF THE POSSIBILITY OF SUCH 
DAMAGES. SOME STATES DO NOT ALLOW 
THE LIMITATION OR EXCLUSION OF 
LIABILITY FOR INCIDENTAL OR 
CONSEQUENTIAL DAMAGES SO THE 
ABOVE LIMITATION OR EXCLUSION MAY 
NOT APPLY TO YOU.

General:
You acknowledge that you have read this 
agreement, understand it, and that by opening
or using this software you agree to be bound 
by these terms and conditions. You further agree 
that this is the complete and exclusive 
statement of the agreement between you and 
Galt Technology, which supersedes any proposal 
or prior agreement. All rights in the software 
not specifically granted in this Agreement 
are reserved by Galt Technology.
If you have any questions about this agreement,
contact GALT TECHNOLOGY in writing or by fax.

Galt Technology
14510 Big Basin Way, Suite #195
Saratoga, CA  95070
Phone:  (408)730-2467
Fax:  (408)730-2467
e-mail: info@galttech.com

Thank you for using SoundPix and for supporting
the shareware conecpt.
