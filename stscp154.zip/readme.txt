StarScape for Windows ver 1.54     Copyright (c) 1992 - 1994 Skyline Software
=============================================================================

INSTRUCTIONS
------------

StarScape for Windows is a planetarium: it displays the positions of the
stars and planets in the night sky.

To install it, run the INSTALL.EXE and follow the on screen instructions.

If the install fails with an error, it is probably because of a file BWCC.DLL
in your Windows System directory. If this occurs, rename your BWCC.DLL, repeat
the install, and then copy your BWCC.DLL back over the one that was installed,
if it is a later version.

The program was originally released as shareware. It is now no longer sold,
supported or developed, and is placed in the public domain.

DISCLAIMER
----------

This program is supplied as-is. No warranty or support is offered, and no liability is
accepted for any loss, damage, consequential loss or damage that may be
caused by this software, whether provable or not.

=============================================================================

 J M Technical Services, 11a Cedar Lane, Cockermouth, Cumbria, CA13 9HN, UK.

 Tel: 01900 826514                               Email: jmtech@netlink.co.uk  

                 WWW: http://www.netlink.co.uk/users/jmtech

=============================================================================
