Repetitorium of Atom Physics 1.0
--------------------------------

1. Purpose
----------

The "repetitorium of atom physics" is a collection of three programs that illustrate atomic models of Rutherford, Bohr, Sommerfeld and Schroedinger.


2. Installation
---------------

No installation routine is required.


3. Status Of The Programs
-------------------------
Version 1.0


4. Distribution Status
----------------------

The programs may be copied freely to students and teachers on diskettes without further notes to the author. However distributing the "repetitorium of atom physics" on CD-ROM or other mass storages together with other software requires the acquiescence of the author! You are not allowed to claim money for copying or distributing this software!


5. Contact The Author
---------------------

e-mail: oliver-g@gmx.de


6. DISCLAIMER - AGREEMENT
-------------------------

Users of programs must accept this disclaimer of warranty:

The Author cannot and does not warrant that any functions contained in the Software will meet your requirements, or that its operations will be error free. The entire risk as to the Software performance or quality, or both, is solely with the user and not the Author. 
You assume responsibility for the selection of the component to achieve your intended results, and for the installation, use, and results obtained from the Software. 

The Author makes no warranty, either implied or expressed, including with- out limitation any warranty with respect to this Software documented here, its quality, performance, or fitness for a particular purpose. In no event shall the Author be liable to you for damages, whether direct or indirect, incidental, special, or consequential arising out the use of or any 
defect in the Software,  even if the Author has been advised of the possibility of such damages, or for any claim by any other party. 

All other warranties of any kind, either express or implied, including but not limited to the implied warranties of 
merchantability and fitness for a particular purpose, are expressly excluded. 

