                          VectorJockey 97.05
----------------------------------------------------------------
An Educational Physics Game of Space Travel involving Vector 
Addition of Velocity, and Acceleration.
----------------------------------------------------------------

---------------------------------------------------------------- 
PURPOSE / DESCRIPTION:
----------------------------------------------------------------

VectorJockey is an Educational Physics Game of Space Travel 
involving Vector Addition of Velocity, and Acceleration.
VectorJockey is NOT an arcade-type game. In VectorJockey, time only 
advances when the user commands it to. As a result, the user always 
has time to think, and the body's ability to DO physics by 
reflex (without reasoning) is interrupted.

VectorJockey is a fun way for students to gain some interactive
experience with these concepts, and helps the students to 
internalize them.

----------------------------------------------------------------
COPYRIGHT
----------------------------------------------------------------
VectorJockey is Shareware.  Copyright� Joel Castellanos 1996-1997
---------------------------------------------------------------- 


----------------------------------------------------------------
INSTALLATION 
----------------------------------------------------------------
Run SETUP.EXE

SETUP.EXE will ask you where to install VectorJockey. SETUP.EXE 
will also install any system files required by VectorJockey that 
are not already present in your system directory. Once you have 
installed VectorJockey, you can delete all of the VectorJockey 
setup files (files with names that end with "__"), and the 
VectorJockey zipfile archive.

VectorJockey program Files:
   README.TXT     (this file)
   VECTOR.HLP   (help file)
   VECTOR.EXE   (program executable - double-click on this to run VectorJockey)


VectorJockey System files for Windows 95 or Windows NT version:
   VB40032.DLL
   VEN2232.OLB
   OLEPRO32.DLL
   MSVCRT20.DLL
   MSVCRT40.DLL
   CT13D32.DLL
   COMDLG32.DLL
   MFC40.DLL

   SETUP.EXE program will also:
   1) add a "Shortcut" to NonEuclid.exe in the system "Start" menu.
   2) add system info for uninstall.



NonEuclid System files for Windows 3.x version:
   VB40016.DLL
   OC25.DLL
   OLE2.DLL
   TYPELIB.DLL
   OLE2DISP.DLL
   OLE2PROX.DLL
   OLE2CONV.DLL
   STORAGE.DLL
   COMPOBJ.DLL
   OLE2.REG
   OLE2NLS.DLL
   STDOLE.TLB
   SCP.DLL
   VAEN21.OLB
   CTL3DV2.DLL
   COMDLG16.OCX
   
----------------------------------------------------------------
DISTRIBUTION:
----------------------------------------------------------------
You are hereby licensed to make as many copies of the Shareware 
(unregistered) version of this software, and documentation as you 
wish; give exact copies of the original Shareware version to anyone; 
and distribute the Shareware version of the software and 
documentation in its unmodified form via electronic means.  
You are specifically prohibited from charging, or requesting 
donations, for any such copies, however made; and from distributing 
the software and/or documentation with other products (commercial 
or otherwise) without prior written permission, with one exception:
Disk Vendors approved by the Association of Shareware Professionals 
are permitted to redistribute VectorJockey, subject to the 
conditions in this license, without specific written permission.



----------------------------------------------------------------
EVALUATION AND REGISTRATION:
----------------------------------------------------------------
This is not free software.  You are hereby licensed to use this 
software for evaluation purposes without charge for a period of 21
days.  If you use this software after the 21 day evaluation period 
a registration fee is required.  Unregistered use of VectorJockey after the 21-day evaluation 
period is in violation of U.S. and international copyright laws.

----------------------------------------------------------------
DISCLAIMER OF WARRANTY:
----------------------------------------------------------------
THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SOLD 'AS IS' AND 
WITHOUT WARRANTIES AS TO PERFORMANCE OF MERCHANTABILITY OR ANY 
OTHER WARRANTIES WHETHER EXPRESSED OR IMPLIED.  Because of the 
various hardware and software environments into which NonEuclid 
may be put, NO WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE IS 
OFFERED.  Good data processing procedure dictates that any program 
be thoroughly tested with non-critical data before relying on it.  
The user must assume the entire risk of using the program.  
ANY LIABILITY OF THE SELLER WILL BE LIMITED EXCLUSIVELY TO PRODUCT 
REPLACEMENT OR REFUND OF PURCHASE PRICE.


----------------------------------------------------------------
AUTHOR / CONTACT INFORMATION:
----------------------------------------------------------------
VectorJockey was written by Joel Castellanos


Visit the VectorJockey Web site for more info and the latest 
version of VectorJockey:

http://riceinfo.rice.edu/projects/NonEuclid/vector

For more information, questions, ideas or suggestions - 
contact the author via e-mail:  

     joel@es.rice.edu

or via postal mail:

     8401 Spain Rd, NE, Apt# 18H,
     Albuquerque, NM, 87111



