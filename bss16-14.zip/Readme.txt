		BLACKBOARD SCREEN SAVER ACTIVATE FOR WINDOWS 3.x
		   	   BlackBoard Software
		      	      dalin@aol.com
			http://members.aol.com/dalin

Install -
To install in WinZip click the 'checkout' button and pick the directory you'd like to install
it to (such as c:\bb\ssact).  For group name pick 'startup'. When you exit WinZip tell it not 
to delete the temporary files since these will become your permanent files.  You can now drag 
the program icon (.exe) to the group you'd like to keep it in.

Changes -
1.1 added installation program, changed web and e-mail address.
1.2 added credit card registration information
1.3 better help/doumentation, temporarily disable screen saver option.                                                                                                                                                                                  
1.4 16-bit version for Windows 3.1

Features -
Easy to use.
Instant screen saver activate.
Provides security when using a locking screen saver.
Option to temporarily disable screen saver.         

Directions -
Set the current screen saver you want in the control panel - display icon.  Then run BB Screen 
Saver Activate, press ENTER or click on GO and the screen saver you picked is immediately 
activated.  Great for use with password screen savers when you go away from your desk.
You can temporarily disable the screen saver by clicking on the DISABLE box.
It's suggested that you put this program in your StartUp group so it runs automatically when you
run Windows.  

Register -

To register by credit card --

The Registered Version of this program can be purchased and received immediately on the Internet at Albert's Ambry.  Registration at Albert's also eliminates shipping and handling costs.  Please go to : http://www.alberts.com ,  Search on : bssact13.exe , Click on the "Buy It", Hotlink to register this software.  Thankyou for registering this program.

To register by check -

Make check payable to : BlackBoard Software

Mail to :
BlackBoard Software
PO Box 745494
Arvada CO 80006-5494

Your key code will be e-mailed to you within 3 weeks.


Registration Information -

Date   :__________

Program Name(s) : ssact16

Copies   _________	X   $19 EA  = $__________________Total

Name 	:__________________________________________

Address :__________________________________________

City	:__________________________________________

State	:_____________

Zip	:_____________

E-Mail  :__________________________________________

Comments:__________________________________________ 	                      
      	 

	___________________________________________

Where did you hear about BlackBoard Software? :__________________________

Where did you get the program you are registering? :______________________ 
