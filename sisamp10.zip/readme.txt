Fat, free sampler pack for Help authors.
Ten free custom functions, 350+ free images,
a free mini Help launcher, authoring tips,
point-and-shoot macro generator, much more.
Fully 16/32 bit compatible, unique and
powerful additions to any Help authoring
environment. No-strings free software from
Software Interphase, Inc, "the Help
Magician people". All non-redistributable
components are yours to keep as our gift.
(http://www.sinterphase.com)

SETUP.EXE starts installation of the software.
Includes uninstall utility. Does not add
registry or INI entries to your system.

This is a compact but fully functional
trial version archive. The latest versions of
all WinHelp Sorcerer tools and complete, ready-
to-unlock trial version archives (including
RTF/HPJ project source for the helpfiles, HLX
format project sources for Help Magician users,
and complete ready-to-print product manuals in
Word DOC format, are always available from:

http://www.sinterphase.com/sorcerer.htm

Shareware. 

Contact: sinterphas@aol.com
