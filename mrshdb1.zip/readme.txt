TITLE:

	MRSHDB1		Version 0.9.00	Beta 1


PURPOSE:

	MRSHD, by Molten Software, is a remote shell daemon for
	Windows 3.1X and Windows 95.

	It allows a user to login to a PC from a remote host in
	a similar manner to that of Telnet daemon.

	Once logged in, a user can issue commands as though they
	had a DOS prompt before them. 

	They will receive the output of these commands providing
	the output uses STDOUT/STDERR.


INSTALLATION:

	* Unzip MRSHDB1.ZIP into a directory (ie c:\mrshd)
 

	The following files should be contained in the archive:

		MRSHD.EXE
		MRSHD.INI
		MRSHD.VXD
		MRSHD.HLP

	* Create an icon in Program Manager group (or add a link
	to the Start menu in WIndows 95) pointing to MRSHD.EXE


	For Windows 3.1X users only -

	* Add a 'DEVICE=' entry into the [386Enh] section of your
	SYSTEM.INI file located in the Window directory.

	ie	[386Enh]
		device=c:\mrshd\mrshd.vxd


STATUS:

	This program is shareware - please see helpfile for
	additional information,
	
	It may also be freely distributed.


SUPPORT:
	Molten Software	Home Page:
		(http://ourworld.compuserve.com/homepages/molten)

	Molten Software email:
		100242.3151@compuserve.com