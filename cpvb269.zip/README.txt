===== Product Information ==============================
   Product:             Code.Print for Visual Basic VB Source Code Documentation Utility
   Version:             2.26
   Version Date:        14-Apr-1997
   Product Type:        Software
   Basic Distribution Policy (see License, below, for details):
      Shareware, subject to distribution restrictions

   Product Description: Code.Print for VB v2.269 The ORIGINAL VB 
                        source code documentation utility - printing 
                        code since 1992. Now with new Win'95 style 
                        interface. Full support for VB5. Based on the
                        award winning commercial version, Code.Print 
                        Pro, Code.Print has defined the VB shareware 
                        source code printing standard. Make a 
                        professional impression with your code. 
   Reason for version:  Full VB5.0 support

   Category:            Computer programming; Programming utilities
   Keywords:            PRINT SOURCE CODE CALADONIA VISUAL BASIC
   Required Packages:   CPVB269
   This Package:        CPVB269
   Registration Fee:    34.00-39.00 (US DOLLARS)

   Required Configuration
      Processor Family: Intel 80x86 (minimum 80386)
        Clock Speed: 25 MHz
      Minimum OS:       Windows 3.1
      Standard RAM:     640K
      Extended Memory:  3000K
      Hard Drive Space: 500K
      Won't Work With:
         Monochrome Display Adapter (MDA)
         Hercules Graphics Card
         Tandy Display Adapter
         Color Graphic Adapter (CGA)
         Plotter
      Req'd Software:   VBRUN300.DLL

   Orders:
      Address:          Caladonia Systems Inc.
                        PO Box 670
                        Lopez, WA 98261
      Toll-Free Phone:  1 (800) 650-4116
      Phone:            (360) 468-4700
      FAX:              (360) 468-4717
      AmOnLine:         CALADONIA
      CompuServe:       70711,3300
      Internet:         sales@caladonia.com
      Other E-mail:     http://www.caladonia.com

   Support:
      Address:          Caladonia Systems Inc.
                        PO Box 670
                        Lopez, WA 98261
      Phone:            (360) 468-4700
      FAX:              (360) 468-4717
      AmOnLine:         CALADONIA
      CompuServe:       70711,3300
      Internet:         http://www.caladonia.com


===== Information for Users ("READ-ME") ================

***************************************

           RELEASE NOTES

    Code.Print for Visual Basic

***************************************

Contents
========
Visual Basic 5.0 Support
Evaluation License
Installation
Un-Installation
Default Fonts
Creating a Default Configuration
Files Required by Code.Print
Networks
Documentation
Printer Drivers
History
How to Contact Caladonia

Visual Basic 5.0 Support
========================

Code.Print for Visual Basic now supports Visual Basic 5.0. Support
includes all new 5.0 file types and new language constructs.


Evaluation License
==================

This program is a shareware product.

To facilitate your evaluation, you have
full access to all features of this
program.

You can use this program 20 times after
first installation.  The program will
tell you when your evaluation period is
over.

At the end of the evaluation period you
must either buy this software or remove
it from your system.  You will be given
an opportunity to buy this program when
the evaluation period has expired.

The program will not display reminder
screens during the evaluation period.
For your convenience, the title bar will
display the number of runs remaining in
your evaluation period.

An evaluation copy notice does appear on
the bottom of all printed output.

At any time during the evaluation period
you may purchase this software. Select
the How to Buy! menu on the main program
dialog for more information about
purchasing and user benefits.


Installation
============

To install Code.Print, place the
distribution files onto a floppy disk or
into a temporary directory on your hard
disk.

From Windows, run SETUP.EXE included
with the distribution files.

Follow the installation instructions in
the setup program.

NOTE: Code.Print will not operate
without first being installed by the
provided setup program.  Code.Print will
not run if the files are manually
expanded from the SETUP.EXE file.


Un-Installation
===============

To uninstall Code.Print, execute the
program UNINSTAL.EXE that is installed
in the program directory or select
Add/Remove Programs in the c ontrol
panel in Win95.  The UNINSTALL program
will remove all program files, ini
settings and registry entries.  Shared
files are deleted on user approval.  The
uninstaller supports Win95 shared file
metering.

Default Fonts
=============
By default, Code.Print tries to print
everything in 10 point Courier. It
selects the Courier font by asking the
printer device context to give it the
first font name containing the letters
"Cour"; if no font matches the request,
Code.Print asks for the first font in
the list.

Whether or not your system has a font
named Courier, it is a good idea to
select some fonts that you know work
well with your printer and make them the
defaults for Code.Print.

For information on how to change the
default fonts, see "Creating a Default
Configuration" below.

---------------------------------------
    TIP
         If you will switch printers
         from time to time, it may be
         best to choose TrueType fonts
         as your defaults. Because
         TrueType fonts are device-
         independent, the fonts you
         choose will always be
         available, no matter what
         printer you use.

         To be sure that only TrueType
         fonts are reported to
         Code.Print when you select
         default fonts:

           1. Run the Windows Control
           Panel.
           2. Click the Fonts icon.
           3. Push the TrueType button.
           4. Check the box labeled
           "Show Only TrueType Fonts in
           Applications."
           5. Push the Ok button to
           confirm your choice.
           6. Push the Cancel button to
           dismiss the Fonts dialog.

         Then run Code.Print and follow
         the steps listed in "Creating a
         Default Configuration."
----------------------------------------



Creating a Default Configuration
================================
When you first install Code.Print, there
is no CPVB.INI file in the Code.Print
directory. We recommend that you create
one.

To create CPVB.INI
------------------

1. Run Code.Print.

2. Press the Properties button.

3. Choose the Fonts tab.

   The controls for selecting fonts will
   appear in the dialog. In a group
   labeled "Section" are four radio
   buttons labeled "Header," "Title,"
   "Code," and "Comment." These are the
   sections of a printout for which you
   can specify an individual font.

4. Select the font you prefer for each
   of the four sections.

5. If you wish to set any other property
   settings do so.  The Help system
   details each setting's function.

6. When you are satisfied with your
   selections, press the Set Default
   button near the bottom of the
   properties dialog.

   Code.Print will create the file
   CPVB.INI in your Code.Print
   directory. This file stores all
   property options you have selected,
   and Code.Print will initialize to
   these settings every time you run the
   program.

9. Push the Apply button if you want to
   apply them to the current session.
   Push the Close button to dismiss the
   dialog.




Files Required by Code.Print
============================

Code.Print for Visual Basic requires the
Visual Basic runtime dynamic link
library, CPVBSW.DLL, VBRUN300.DLL,
CMDIALOG.VBX, SS3D.VBX, CBK.VBX,
DWSPYDLL.DLL, CALL32.DLL.


Networks
========

Code.Print for Visual Basic maintains
the file CPVB.INI to store configuration
information.  If you are installing
Code.Print for Visual Basic onto a
network drive, be sure anyone using
Code.Print can write to that directory.
Printing to a network may require you to
set the Code.Print "Print While
Processing" check box to off.   This
makes Code.Print generate the output as
a single multi-page print job.  If
"Print While Processing" is checked,
each page is generated as a separate
document and thus will be treated by the
network as a separate print job.

You may need to adjust the timeout
setting on the print server.  The
Code.Print output stream is not
continuous and causes some networks to
believe the document is finished
prematurely.  If adjusting the timeout
has no effect, redirect the output to a
file or use a spooler program to collect
the output before sending it to the
network.

Although Code.Print can be installed on
a network, only one user at a time may
run Code.Print if you have a single user
license.  If you require more than one
user to be able to run Code.Print at the
same time then you will need to obtain a
license for each user.

Multiple licenses are dicounted
according to a sliding scale.  (See the
How to Buy menu in after selecting
Information on the Main Form.)

Documentation
=============

Code.Print for Visual Basic is an easy
to use program.  All of the functions
contained in Code.Print for Visual Basic
are documented in the Windows on-line
help system.  There is no user manual.


Printer Drivers
===============

Code.Print for Visual Basic is designed
to use the printer fonts and drivers
that are available in your current
Windows environment. Printing speed will
depend on what fonts and drivers you are
using. It is best to experiment.  Some
fonts can be slower than others.
Code.Print will display a message
"Waiting for Printer..." while the
printer driver is processing page and
font data.  Since processing has been
passed from the program to your printer
driver, Code.Print will not respond
immediately to a cancelation request
while the "Waiting for Printer..."
message is displayed.


NOTE!  Code.Print does not work with the
       Generic / Text Only Printer
       Driver. This driver does not
       respond to any font or style
       operations and generates an error
       condition on every attempt to
       change the printer object.
       Code.Print will try to gracefully
       back out of this situation but
       will probably crash and dump the
       program. This driver is
       guaranteed NOT TO WORK. If you
       are using a dot matrix printer
       and want fast output, use the
       high speed fonts available in
       many dot matrix drivers.


History
=======

        Code.Print for Visual Basic
        Revision History

        v1.00  -  Released March 20, 1992

        v1.6a  -  Released April 20, 1992

        v2.00  -  Released September 15, 1992
                  Added many user
                  requested features.

        v2.00a -  Released October 11, 1992
                  Maintanence Release
                  Fixed long string word
                  wrap bug.

        v2.10  -  Released October 19, 1992
                  Fixed "Illegal File Name" bug.

        v2.10a -  Released October 26, 1992
                  Fixed "Over Flow"
                  error and Title/File
                  Name overlap problem.

        v2.20   - Release December 12,
                  1992 (Feb 08, 1993)
                  Provided VB 2.0
                  compatibility.  Size
                  of EXE reduced by 50%.
                  Larger procedures list
                  box. Several
                  efficiency
                  improvements.  Added
                  auto VB version and
                  binary file detection.
                  Uses Windows help
                  system.  Fixed
                  overflow error.

        v2.21   - Release July 24, 1993
                  Fixed Code/Comment
                  font alignment
                  problem.  Added form
                  declaration omit
                  functionality.


        v2.22   - Release August 22, 1993
                  Added VB 3.0
                  compatibility

        v2.23   - Released June 15, 1995
                  Fixed print to File
                  Cancel error.
                  Overhauled and updated
                  user interface and
                  help system

        v2.24   - Released Sept 18, 1995
                  Added VB4 syntax and
                  project file support

        v2.25   - Released December 23, 1995
                  Added full long file
                  name support.  Fixed
                  Get/Set property
                  function parser bug.

        v2.26   - Released Jan 12, 1996
                  Fixed Fit Routines on
                  Page Bug Replaced
                  InstantBuy with
                  QuickBuy

        v2.267  - Released Jan 22, 1997
                  Minor tweeks. Added
                  improved InstantBuy
                  module.

        v2.269  - Release Apr 14, 1997
                  Full VB5 support added.

How to Contact Caladonia
========================

Code.Print for Visual Basic is a
Shareware product of Caladonia Systems,
Inc.  You can contact us via the methods
below:

        Mail:
        Caladonia Systems, Inc.
        P.O. Box 670
        Lopez, WA  98261

        Tech Support, Information, Voice
        Mail: (360) 468-4700

        FAX: (206) 727-8086

        email: info@caladonia.com

        web: www.caladonia.com




Commments, questions, and suggestions
are welcome and encouraged.


Code.Print is a Trademark of Caladonia
Systems, Inc. Code.Print for Visual
Basic (c) Copyright 1992-1995 All Rights
Reserved. Visual Basic is a Trademark of
Microsoft Corporation. Windows is a
Trademark of Microsoft Corporation.

****************************************
END OF NOTES
