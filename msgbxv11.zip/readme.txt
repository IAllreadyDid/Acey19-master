Message Box Creator Deluxe will help you, a Visual Basic programmer,
to create message boxes easier.  Message Box Creator Deluxe has an
easy to use point and click interface.

Message Box Creator Deluxe is shareware.  You may use this software
for a 30 day trial, after this time, you may choose to either
register or delete this file and all accompanying files from your
system.

You may freely distribute the original .ZIP file unmodifed without
restriction.

If you have any problems, feel free to email me at:
kubby1981@aol.com.

