SciTech DISPLAY DOCTOR is a suite of useful utilities that 
fix the most common problems associated with SVGA graphics 
cards. Contains a number of separate components including: 
graphics chip detection, display power management, display 
centering, refresh rate control and compatibility & performance testing. The popular UNIVBE is included in the suite. 21-day trial period. 

To install, simply run the sdd53a.exe file from Windows.

This product is shareware, for trial use only.

Also, don't forget to check out our WWW site for
more detailed information. Feel free to call or email with your questions and/or comments.

SciTech Software
505 Wall Street
Chico, CA 95928
916-894-8400 (Registered User Support Line)
916-894-9069 FAX

76710.2027@compuserve.com
www.scitechsoft.com
info@scitechsoft.com
sales@scitechsoft.com
support@scitechsoft.com
suggest@scitechsoft.com


Files: 
-----
readme.txt	This file
sdd53a.exe    SciTech Display Doctor 5.3a - the universal                graphics card utility
