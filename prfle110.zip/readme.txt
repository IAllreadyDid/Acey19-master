Profile Picker 1.1

Create and manage multiple configurations for any Windows 3.x program.
Installation is easy -- just unzip to any directory.  Then copy the
files to the directory of each program for which you need to create
multiple configurations.

Profile Picker is shareware.  See the file register.txt for more
information.

The end-user software license is in the file license.txt.

More information can be found by choosing Help once you have started
the program.



Directions for usage:


1.  Copy profile.exe and profile.hlp to the directory of each program for
    which you want to create multiple profile.
2.  Determine which file contains settings -- it is usually the program
    name followed by .INI (example: File Manager is WINFILE.INI).
3a. Start the program and modify the settings for one profile.
3b. Copy the configuration file (eg WINFILE.INI) to another (eg file1.ini).
3c. If there are more, go to 3a again.
4.  Start Profile.
5.  Click Options, and fill in the information (use full paths).  Example
    for File Manager:
       ID of Program: FileMan
       Program EXE:   c:\windows\winfile.exe
       Program INI:   c:\windows\winfile.ini
6.  Click OK.
7a. Click on Add.
7b. Fill in the information.  Example for File Manager:
       Name:          My profile
       INI File:      c:\windows\file1.ini
7c. Click OK.
7d. If there are more, go back to step 7a.
8.  Click on Exit.


9.  For Windows 3.1 or Windows 95 Program Manager:
      a. Go to the Program Manager entry for the program.
      b. Select File-Properties or press Alt+Enter.
      c. In the field "Command Line", replace it with the path of
         profile.exe (e.g. c:\netscape\profile.exe) --
         keep everything else.
      d. If you want to keep the icon, click "Change Icon" and type
         in the full path of the original program.
      e. Click OK to back out of the dialog box.
      f. Every time you start the program, a list will pop up.  Click
         on the one you want and click "Execute!"
    For Windows 95 Explorer interface:
      a. Right-click on the Start button and select Explore.
      b. Make your way to the entry that for the program.
      c. Right click on it and select Properties.
      d. Click on the Shortcut tab.
      e. In the field "Target", replace it with the path of
         profile.exe (e.g. c:\netscape\profile.exe) -- keep
         everything else.
      f. If you want to keep the icon, click "Change Icon" and type
         in the full path of the original program.
      g. Click OK to back out of the dialog box.
      h. Every time you start the program, a list will pop up.  Click
         on the one you want and click "Execute!"


If you find this utility useful, please register it by paying
a small fee.  See the file register.txt for details.  Registration
entitles you to free upgrades to any version 1.x, and technical
support via e-mail.
