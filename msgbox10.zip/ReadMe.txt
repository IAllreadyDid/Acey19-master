
DABSoft Solutions - MsgBoxer 1.0
Copyright (c) 2000 DABSoft Solutions

Create and implement Visual Basic MsgBox's quickly and easily.

http://www.dabsoft.com

Thank you for using this FREE developer's tool.

To install please extract the setup.exe file to a directory and execute it.
The installation wizard will guide you through the rest of the installation process.

This program is freely distributable and is freeware.

Should you have any questions please e-mail dbertram@dabsoft.com