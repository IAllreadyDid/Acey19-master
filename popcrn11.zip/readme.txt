Popcorn Screensaver v1.1
By David Koller

Popcorn Screensaver allows you to protect your monitor with images of this
snack food favorite.

Win95 users: Installation, Configuration, and previewing can all be 
accomplished by right clicking on popcorn.scr in windows explorer. 

Win 3.x users: Place popcorn.scr in your windows directory. It will then
show in your list of screensavers where it can be previewed and configured. 

Requirements: Vbrun300.dll, which is most likely already on your machine. I 
have a link to download this file on my homepage if you need it. The URL is 
below.

Miscellaneous: Using the maximum number of kernels is only recommended for 
those using a very high resolution, such as 1024*768. To keep animation 
smooth, fewer kernels should be used for lower resolutions.       

This program is shareware and may be freely distributed without serial
numbers.

Updates and other products will be posted at: http://www.uwm.edu/~dkoller
Questions and comments can be sent to: dkoller@csd.uwm.edu

___________________
�1997 David Koller
All Rights Reserved