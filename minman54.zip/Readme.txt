
          MinuteMan Project Management Software
                

Description
-----------
This program focuses on providing the basic functions needed to
effectively manage projects. With MinuteMan, in a few minutes you
can create an easy-to-understand project schedule to;

- Identify the dates of tasks and milestones
- Record useful notes on each task
- Assign people and define expenditures
- Print Gantt and Pert Charts and a handful of concise schedule and
  budget reports.

MinuteMan reports can be generated in hardcopy as well as text- and
graphics- file formats, compatible with standard word-processor and
spreadsheet programs. This means you can easily distribute your
reports, even PERT and Gantt Charts, via email to team members
and other interested parties.

MinuteMan supports multiple, linked subprojects. One project can be 
broken down into separate activities ("Engineering", "Sales") with 
links between critical "Program-Wide" tasks. 

Instruction Manual
------------------
A detailled operating manual is posted at;
      http://www.minuteman-systems.com/     


Installation
------------
This program will run on Windows 3.1 & 3.11, Windows 95, and up.

To install the program, run SETUP.EXE. When prompted for a 
destination directory, select any directory other than where you 
have placed these installation files.

When the program is running, select HELP and CONTENTS for 
instructions. 

If you encounter problems, see the troubleshooting tips at the 
end of this file.

Registration
------------
This is an evaluation copy of MinuteMan Project Management 
Software. To obtain a registration key for a permanent copy, a 
payment of $49.95 US is required. Payments may be made by credit 
card on the Internet, or by check via land mail.

To purchase the program by credit card, go to www.shareit.com 
and register program 100735.

Checks may be mailed to;

MinuteMan Systems
PO Box 152
Belmont, MA 02478

Please include your return address and telephone number or
email address. An order form may be printed from the program; 
use the menu entries for Help and Order Form.

For further information or assistance contact us at

Internet : info@minuteman-systems.com
WWW Site : http://www.minuteman-systems.com/ 
Telephone : (617) 489-5639

=======================================================================

                      TroubleShooting Tips

Usually the MinuteMan Program installs and runs properly. 
In the event that a problem is encountered, following are 
some things to check for or change;

1.) This program requires that you have the Visual Basic 4 run-time libraries 
installed on your system. If those files aren't present, when you run the 
program Windows will issue an error message indicating that some files 
are missing.

The VB4 runtime files needed for this program can be found at
this URL:  http://www.simtel.net/simtel.net/win3/dll.html

2.) Windows requires that all other programs be shut off prior 
to installing a new program. If not, the installation may not 
complete, and you will get an error message indicating a 
conflict with the application. 

A common problem is if you ran a browser such as Netscape, to 
download the program, prior to doing the installation. Even if 
Netscape were shut off, it may have left other processes running. 
It is recommended to shut off Netscape, reboot your system, and
install MinuteMan before doing anything else.

In Windows '95, if you simultaneously press CTRL, ALT, and 
DEL a menu will come up showing you which programs are 
still running, and it allow you to select ones to shut off. 

In Windows 3.1 or 3.11, clicking the box in the upper left
corner of the Program Manager window will bring up a list of
active programs.

Windows itself may erroneously report that it has a conflict 
with some program competing for use of COMDLG16.OCX or some 
Filename.DLL. However, in that one instance it still allows 
you to complete the installation (by clicking IGNORE) and 
the program will install and run. 

3.) When installing the program, it should be installed to 
a directory different from where the installation kit has 
been placed. In that case usually the installation will not 
complete but it is possible that the program may fully install 
and then mis-operate somehow. 

4.) There have been cases reported of pc's running 
resource-intensive applications, such as Networking software 
or Games, interfering with either the installation or the 
operation of the program. Often this has been remedied by 
rebooting the system, and doing the installation before 
starting up any other applications. Also, using a CD-ROM 
drive to play music while running the installation program 
or while running MinuteMan could conceivably cause a problem. 

5.) If your machine has regional settings other than English 
(US-standard) there is a remote possibility of a problem. The 
program has been tested with many common regional settings and 
works fine. If by chance your machine is set for something other 
than English (US-standard), you might try configuring it as 
English (US-standard), rebooting, and seeing if the program works. 
(If that happens, please report your original regional setting 
to us and we will investigate modifying the program to eliminate
the problem.) 

6.) With the program running, some screens may not display properly. 
The most common problem is that thin lines or borders of objects 
disappear. This can usually be corrected by changing the Color 
Palette settings on your PC. Use the Windows Control Panel, and 
go to the Display settings. Most PCs support choices such as 
"256 Colors", "High Color (16-Bit)", and "True Color (16- and 32-bit)". 
Usually most if not all the Setting choices will result in proper 
operation. The program also runs best when using display settings 
for "Small Fonts".

7.) Printing; The program attempts to do all graphics printing 
using colors. If you are using a non-color printer, such as a laser, 
some lines may disappear or the print may in other ways be wrong. 
This may be corrected to by using the Windows Control Panel to change 
your printer settings. The exact settings for doing this  will vary 
from printer to printer.

