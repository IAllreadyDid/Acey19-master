SocBase readme.txt file


Thanks for supporting SocBase!


          Subject                          Chapter
          ----------------------------------------

	  Shareware...........................1

	  Limited Warranty....................2

	  System Requirements.................3

	  Installing SocBase..................4

          Uninstalling SocBase................5

	  The User's Manual...................6

	  Technical Support...................7

	  Distributing........................8

	  Registering SocBase.................9

	
------------------------------------------------------------------------------

			Definition of Shareware

Shareware distribution gives users a chance to try software before buying it.
If you try a Shareware program and continue using it, you are required to
register it (or purchase the licensed version as in the case of SocBase).

Copyright laws apply to both Shareware and retail software, and the
copyright holder retains all rights, with a few specific exceptions as stated
below. Shareware authors are accomplished programmers, just like retail
authors, and the programs are of comparable quality. (In both cases, there are
good programs and bad ones!) The main difference is in the method of
distribution. The author specifically grants the right to copy and distribute
the software, either to all and sundry or to a specific group. For example,
some authors require written permission before a commercial disk vendor may
copy their Shareware.

Shareware is a distribution method, not a type of software. You should find
software that suits your needs and pocketbook, whether it's retail or
Shareware. The Shareware system makes fitting your needs easier, because you
can try before you buy. And because the overhead is lower, prices are lower
also. Shareware has the ultimate money-back guarantee -- if you don't use the
product, you don't pay for it.

------------------------------------------------------------------------------

		   LIMITED WARRANTY AND DISCLAIMER OF WARRANTY 
 
	THIS SOFTWARE AND ACCOMPANYING WRITTEN MATERIALS (INCLUDING INSTRUCTIONS 
FOR USE) ARE PROVIDES "AS IS" WITHOUT WARRANTY OF ANY KIND. Delite Software DOES NOT 
WARRANT, GUARANTEE, OR MAKE ANY REPRESENTATIONS REGARDING THE USE, OR THE RESULTS 
OF USE, OF THE SOFTWARE OR WRITTEN MATERIALS IN TERMS OF CORRECTNESS, ACCURACY, 
RELIABILITY,CURRENTNESS, OR OTHERWISE. THE ENTIRE RISK AS TO THE RESULTS AND 
PERFORMANCE OF THE SOFTWARE IS ASSUMED BY YOU. IF THE SOFTWARE OR WRITTEN 
MATERIALS ARE DEFECTIVE YOU, AND NOT Delite Software OR ITS DEALERS, DISTRIBUTORS, 
AGENTS, OR EMPLOYEES, ASSUME THE ENTIRE COST OF ALL NECESSARY SERVICING, REPAIR, OR 
CORRECTION.
 
	THE ABOVE IS THE ONLY WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, 
INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
FITNESS FOR A PARTICULAR PURPOSE, THAT IS MADE BY Delite Software, ON THIS 
Delite Software PRODUCT. NO ORAL OR WRITTEN INFORMATION OR ADVICE GIVEN BY 
Delite Software, ITS DEALERS, DISTRIBUTORS, AGENTS OR EMPLOYEES SHALL CREATE 
A WARRANTY OR IN ANY WAY INCREASE THE SCOPE OF THIS WARRANTY AND YOU MAY NOT 
RELY ON ANY SUCH INFORMATION OR ADVICE. YOU MAY HAVE OTHER RIGHTS WHICH VARY 
FROM STATE TO STATE, CONTRY TO COUNTRY.
 
	NEITHER Delite Software NOR ANYONE ELSE WHO HAS BEEN INVOLVED IN THE 
CREATION, PRODUCTION OR DELIVERY OF THIS PRODUCT SHALL BE LIABLE FOR ANY DIRECT,
INDIRECT, CONSEQUENTIAL OR INCIDENTAL DAMAGES (INCLUDING DAMAGES FOR LOSS OF
BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, AND
THE LIKE) ARISING OUT OF THE USE OR INABILITY TO USE SUCH PRODUCT EVEN IF
Delite Software HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 
 
			   ACKNOWLEDGMENT
 
BY USING THE SHAREWARE VERSION OF SocBase YOU ACKNOWLEDGE THAT YOU
HAVE READ THIS LIMITED WARRANTY, UNDERSTAND IT, AND AGREE TO BE BOUND BY ITS'
TERMS AND CONDITIONS. YOU ALSO AGREE THAT THE LIMITED WARRANTY IS THE
COMPLETE AND EXCLUSIVE STATEMENT OF AGREEMENT BETWEEN THE PARTIES AND
SUPERSEDE ALL PROPOSALS OR PRIOR AGREEMENTS, ORAL OR WRITTEN, AND ANY OTHER
COMMUNICATIONS BETWEEN THE PARTIES RELATING TO THE SUBJECT MATTER OF THE
LIMITED WARRANTY.



Use of this software is permitted only to the extent reasonably required to
determine whether to purchase the software.

After payment is made, use of this software is limited to use on only a
single personal computer or workstation which is not used as a server.  An
additional payment is required for each use on another personal computer or
workstation.

Only a single copy may be made of this software solely for backup or archival
purposes.  The software may also be transferred to a single hard disk.

Any use of this software in violation of the above is not licensed.

------------------------------------------------------------------------------

	      System Requirements

Hardware Requirements

Minimum system requirements is a 386 with 4 MB RAM. Recommended system is
a 486 with 8MB RAM. 

Harddisk space required: 

~5.0 MB (If no drivers are present..vbrun300.dll etc)
 1.5 MB (If you have all the drivers already)


Software Requirements

Windows 3.1X, Windows 95, Windows NT 3.51 or Windows NT 4.0 
(Has not been tested under OS/2 Warp....yet)


------------------------------------------------------------------------------

	      Installing SocBase

    If you have not installed SocBase before on the computer you
have to run the SocBase setup program from Windows so it will work 
properly on your computer. You cannot just copy the files from the 
SocBase disk to your hard disk.  The files on the distribution disk are 
packed in a special way to save space.  The setup program unpacks those 
files and builds them on your working disk.

************************************
Installing SocBase for the first time:
************************************

Windows 95 / Windows NT

    1. Start Windows. Close all applications.
    
    2. Insert the disk "SocBase Setup Disk 1(3) in the disk drive.

    3. Run the setup program:
	To open the File Run Dialog Box, select "Run" from the START Menu.

    4. Enter the Command Line
        Type in the dialog box the command that will run the
        SocBase setup program.

	type:

	    A:\SETUP32
	
	Click the "OK" command button.

    5. Follow the instructions and SocBase will be installed on your system.
        The setup program will notify you when the installation is complete.


Windows 3.1 / 3.11

    1. Start Windows. Close all applications.
    
    2. Activate Program Manager
	Make Program Manager the active window.

    3. Open the File Run Dialog Box
	To open the File Run Dialog Box, select "Run" from the Program
	Manager's File Menu.

    4. Enter the Command Line
        Type in the dialog box the command that will run the
        SocBase setup program.

	If your disk drive is A:, type:
	    A:\SETUP16
	
	Leave the "Run Minimized" box un-selected, and click the
	"OK" command button (or press "Enter").

    5. Follow the instructions and SocBase will be installed on your system.
        The setup program will notify you when the installation is complete.


****************************************************************************
If you are upgrading to a newer version of SocBase follow this instruction:
****************************************************************************	

	Unpack the upgrade file and copy the following files to your SocBase
	directory:

	readme.txt   (this file)
	bmp2gif.dll
	socbase.exe
	socbase.hlp

------------------------------------------------------------------------------

	      Uninstalling SocBase

Click on the "Unistall SocBase" icon in the SocBase folder. Follow the 
instructions and SocBase will be removed from your system.


------------------------------------------------------------------------------

			     The User's Manual

There's no printed Users Manual supplied in order to keep the cost down.
All information is available in the on-line Help file.


------------------------------------------------------------------------------

	     SocBase Technical Support

Technical support for SocBase can be obtained from:

Delite Software
Mats Fredriksson
Gundas Gata 81
431 51 Molndal
SWEDEN

Internet: mats.fredriksson@tripnet.se


------------------------------------------------------------------------------

			    Distributing

You are encouraged to pass a copy of the shareware version of SocBase
along to your friends for evaluation.

If you do so, you must provide them with the entire set of SocBase
shareware version files. These include:

bmp2gif.dl_
cmdialogvb_
commdlg.dl_
ctl3dv2.dl_
ddeml_dl_
field.bmp
graph.vb_
gsw.ex_
gswdll.dll_
gtlist.vb_
itgraph.vb_
lock.wa_
mmsystem.dl_
msafinx.dl_
msajt112.dl_
msajt200.dl_
msaes110.dl_
readme,txt      [This file]
setup.exe
socbase.exe
socbase.hlp
socbase.ini
setupkit.dl_
setup1.ex_
setup.lst
sys.dat
threed.vb_
vshare.38_
ver.dl_
vbrun300.dl_
vbdb300.dl_
unlock.wav




Do not simply copy the files off your hard drive. SocBase must be
installed using the SETUP program or it will not function correctly!

------------------------------------------------------------------------------

		       Registering SocBase

You may use the shareware version of SocBase for a 30 day trial
period.  If you would like to continue to use SocBase after the
30 day trial period, you are required to register SocBase.

When you register SocBase you will receive a codeword that unlocks
all limitations.

SocBase may be purchased from a number of sources. You are free to
purchase your copy from where ever you desire.

To print an order form:

1. Start SocBase.
2. Choose "Register" in the "Help"-menu.
3. Click the left mouse button on the "Print Register Form".

------------------------------------------------------------------------------
