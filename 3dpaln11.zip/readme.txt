3D Protein Alignment: README
----------------------------
----------------------------

Please read this file carefully (especially "Installation" 
chapter) before installing the program to your computer.


Contents
--------

Program information
Company information
Description
Installation
Registration
Copyright and license
Technical support
Ombudsman statement


Program information
-------------------

Program Archive Name:
  3dpaln.zip
Program Name:
  3D Protein Alignment 
Program Version:
  1.1
Program Release Date:
  December 10, 1999
Program Description:
  3D alignment (comparing) of proteins with known 3D structures.
Target OS:
  DOS, Windows 95, Windows 98, Windows NT 4.0
Software type:
  Shareware ($20 personal license)
  Shareware ($50 business license)

Company information
-------------------

Company Name:
  Elcom Ltd
Contact E-mail Address:
  3dpaln@elcomsoft.com
Contact WWW URL:
  http://www.elcomsoft.com/3dpaln.html


Description
-----------

If you don't have a Workstation (like Silicon Graphics) but have a
PC with DOS or Windows 95/98/NT and want to compare 3D structures 
of proteins (in PDB format), this program is for you. The quality
of our pare 3D alignment is comparable with the quality of 3D
alignment on Workstation.

The input files of program are two any Brookhaven files. 
The program performs the analysis of subunit contents in both 
files and enables to choose for alignment any two subunits from 
all subunits of both files. The program does not need any 
sequence gomology and any previous assumption about 3D structure 
similarities of starting proteins. The program can determine 
itself the degree of 3D similarity. 

The output of this program is 3D coordinates of second subunits 
(protein) rotated and shifted to the best fitting to the 
coordinates of the first subunit (protein) in PDB format with 
some additions that you can easily remove. 

You can see and manipulate stereoscopic image of starting 
structures and final result, both proteins, using mirror 
stereo-glasses. 

The second kind output of this program is the linear 
representation of 3D alignment and the list of structure 
conservative regions that fit to given Root Mean Square (RMS) 
deviations. 

It is possible to use this program for the purpose of computer 
modelling and 3D classification of protein 3D structures.

The output files will be available only in registered version of 
this program.



Installation.
-------------

To install 3D Protein Alignment program in any OS (DOS, 
Windows 95/98/NT) you should first unzip "3dpaln.zip" file to any 
folder. For example to "3DPAln" folder. 


DOS installation
----------------

If you're going to use the program from pure DOS (for example 
DOS 6.22), to get the program working properly with long (more 
than 400 amino acids) proteins you should have at the beginning 
of the file "config.sys" two strings: 

DEVICE=C:\DOS\HIMEM.SYS
DEVICE=C:\DOS\EMM386.EXE RAM

to emulate Expanded memory.

Then reload DOS and run "3dpaln.exe".


Installation for DOS Window inside Windows 95/98 
(In usual Multitasking Windows mode)
------------------------------------------------

If 3DPAln will be executed from DOS window inside 
Windows 95/98, you have to do the following:

First you should delete an old pif file "3dpaln.pif" 
(in Windows 95 Explorer you may see it as file with name simply 
"3dpaln" without extension and with MS-DOS icon), if it exists, 
because it may have wrong pathway to the file "3dpaln.exe".

To create a new pif file with right settings in Windows Explorer, 
click right mouse button on the file "3dpaln.exe".
In appeared Pop-Up Context Menu you should select item 
"Properties";
In appeared Property Sheet "3dpaln.exe Properties" you should 
select Tab "Program";
In this Tab push PushButton "Advanced";
In appeared Dialog Box "Advanced Program Settings" switch On 
CheckBox (Group Box) "MS-DOS mode";
Then in this Dialog Box select RadioButton "Specify a new MS-DOS 
configuration";
Then in this Dialog Box push PushButton "Configuration";
In appeared Dialog Box "Select MS-DOS Configuration Options" 
switch On CheckBox "Expanded Memory (EMS)";
Then in this Dialog Box "Select MS-DOS Configuration Options" 
push PushButton "OK";
Check that in Dialog Box "Advanced Program Settings" in ListBox 
"CONFIG.SYS for MS-DOS mode:" are the strings: 

DOS=HIGH,UMB
Device=C:\WINDOWS\Himem.Sys
DeviceHigh=C:\WINDOWS\EMM386.Exe 

Then in Dialog Box "Advanced Program Settings" push PushButton 
"OK";
Then in Property Sheet "3dpaln.exe Properties" push PushButton 
"OK".

Then In Windows Explorer, click right mouse button ones more on 
the file "3dpaln.exe".
In appeared Pop-Up Context Menu you should select item 
"Properties";
In appeared Property Sheet "3dpaln.exe Properties" you should 
select Tab "Program";
In this Tab push PushButton "Advanced";
In appeared Dialog Box "Advanced Program Settings" switch Off 
CheckBox (Group Box) "MS-DOS mode";
Then check that the CheckBox "Suggest MS-DOS mode as necessary" 
is On (If it is not so, switch it On);
Then in Dialog Box "Advanced Program Settings" push PushButton 
"OK";
Then in Property Sheet "3dpaln.exe Properties" push PushButton 
"OK".

Then run "3dpaln.exe".



Installation for MD-DOS mode of Windows 95/98 (One task mode).
--------------------------------------------------------------

If you want to align long proteins (more than 400 amino acids 
each) the previous mode (DOS Window inside Windows) will be not 
so convenient, because of time consuming. In this case the most 
convenient mode will be MS-DOS mode of Windows. It will be six 
times faster. It will take about only 30 minutes in this MS-DOS 
mode of Windows to align two proteins of 450 amino acids long on 
Pentium 100 instead of one hour and a half in DOS Window inside 
Windows.

First you should delete an old pif file "3dpaln.pif" 
(in Windows 95 Explorer you may see it as file with name simply 
"3dpaln" without extension and with MS-DOS icon), if it exists, 
because it may have wrong pathway to the file "3dpaln.exe".

To create a new pif file with right settings in Windows Explorer, 
click right mouse button on the file "3dpaln.exe".
In appeared Pop-Up Context Menu you should select item 
"Properties";
In appeared Property Sheet "3dpaln.exe Properties" you should 
select Tab "Program";
In this Tab push PushButton "Advanced";
In appeared Dialog Box "Advanced Program Settings" switch On 
CheckBox (Group Box) "MS-DOS mode";
Then in this Dialog Box select RadioButton "Specify a new MS-DOS 
configuration";
Then in this Dialog Box push PushButton "Configuration";
In appeared Dialog Box "Select MS-DOS Configuration Options" 
switch On CheckBox "Expanded Memory (EMS)";
Then in this Dialog Box "Select MS-DOS Configuration Options" 
push PushButton "OK";
Check that in Dialog Box "Advanced Program Settings" in ListBox 
"CONFIG.SYS for MS-DOS mode:" are the strings: 

DOS=HIGH,UMB
Device=C:\WINDOWS\Himem.Sys
DeviceHigh=C:\WINDOWS\EMM386.Exe 

Then in Dialog Box "Advanced Program Settings" push PushButton 
"OK";
Then in Property Sheet "3dpaln.exe Properties" push PushButton 
"OK".

Then run "3dpaln.exe".

The computer will restart Windows 95/98 in MS-DOS mode and begin 
to perform 3DPAln.



Installation for DOS Window inside Windows NT 4.0
-------------------------------------------------

At first you should delete an old pif file "3dpaln.pif" (in 
Windows NT Explorer you may see it as file with name simply 
"3dpaln" without extension and with MS-DOS icon), if it exists, 
because it may have wrong pathway to the file "3dpaln.exe".

To create a new pif file with properly settings in Windows NT 
Explorer, click right mouse button on the file "3dpaln.exe".
In appeared Pop-Up Context Menu you should select item 
"Properties";
In appeared Property Sheet "3dpaln.exe Properties" you should 
select Tab "Memory";
In this Tab "Memory" in Group Box "Expanded (EMS) memory" set 
maximum value of Total Expanded memory;
In this Tab "Memory" push PushButton "Apply";
Then push PushButton "OK";

Then run "3dpaln.exe".



Registration
------------

See "order.txt" file.


Copyright and license
---------------------

See "license.txt" file.


Technical support
-----------------

Before you contact us, please do the following:

- Be sure that you're doing everything right. We all make
  mistakes sometimes... Be attentive.
- Look at the manual.txt file: it may already contain an answer to
  your question. A lot of people ask us something like "how
  do I:", though the complete information is there.

But if you still have a problem with P3DAln and noting else helps,
please contact technical support at:

  3dpaln@elcomsoft.com (preferred)
    or
  N.Vtyurin@g23.relcom.ru

Please inform us about the following:

  - 3D Protein Alignment version (from title window of the program)
  - where did you get 3D Protein Alignment (http or ftp site).
  - Windows 95/98/NT or DOS version (including service packs and 
    other fixes installed), US or international, OEM or not.
  - computer information: CPU type and speed, installed memory.
  - description of your problem (as much information as possible
    to retrieve the problem).

Note: you may want to read the "How to Determine the Version of
Windows 95 in Use" article by Microsoft. Use the following URL:

http://support.microsoft.com/support/kb/articles/q158/2/38.asp

In order to get the complete computer information (working under
Windows 95), open the Control Panel, click on "System" applet and
press "Print" on "Device Manager" tab.

If you have any comments or suggestions for the next releases,
please don't hesitate to post them to us.


Ombudsman statement
-------------------

Elcom Ltd is a member of the Association of Shareware Professionals
(ASP). ASP wants to make sure that the shareware principle works
for you. If you are unable to resolve a shareware-related problem
with an ASP member by contacting the member directly, ASP may be
able to help. The ASP Ombudsman can help you resolve a dispute or
problem with an ASP member, but does not provide technical support
for members' products. Please write to the ASP Ombudsman at 157-F
Love Ave., Greenwood, IN 46142 USA, FAX 317-888-2195, or send email
to omb@asp-shareware.org.
