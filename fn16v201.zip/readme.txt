                       File Navigator For Windows
                    
Thanks for trying File Navigator For Windows.

ABSTRACT

File Navigator For Windows is a Microsoft Windows based file management
utility. It has been developed especially for those of you who spend a
great deal of time on-line, and download many files.

File Navigator For Windows provides for the management of such standard
file extensions as the Fidonet QWK/REP mail packets, archive files (ZIP,
ARJ, LHA, and EXE), TXT files, as well as GIF and JPG graphics files.

In addition, it provides for up to 9 user-defined file extensions.

File Navigator For Windows automates the task of placing your downloaded
files in their respective directory locations.

TESTING

File Navigator For Windows has been tested on the following platforms:

 - Windows For Workgroups 3.11
 - Windows 3.1 
 - Windows 95

I have not had the opportunity to have File Navigator For Windows
tested under Windows NT as of yet.

File Navigator For Windows has been tested using large and small fonts,
and the following video resolutions:

 - 640 X 480
 - 800 X 600
 - 1024 X 768

INSTALLATION

1. Unzip FN16V130.ZIP into a temporary directory.
2. Run FNAVW16.EXE.

REGISTRATIONS

File Navigator For Windows is distributed as shareware.
The registration price is $20.00 US.

Site licenses are available.

CONTACT POINTS

Brad Clarke 
WWW: http://www.cyberus.ca/~bclarke/filenavw.html
E-Mail: bclarke@kagi.com

